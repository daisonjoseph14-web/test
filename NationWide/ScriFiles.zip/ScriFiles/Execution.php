<?php
error_reporting(0);
require_once './pages/auth/pageHandler.php';

ob_start();
session_start();
// echo "Hello from PHP!";
$_SESSION['currentPage'] = 'Execution';

//$m = new MongoClient();
require '/var/www/html/vendor/autoload.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Decommission Analyzer - Execution Stats</title>
    <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/custom-style.css" rel="stylesheet">

    <style>
    .dpd-td {
        /* your existing styles already include padding, bg, radius, etc. */
    }

    @import url("https://fonts.googleapis.com/css2?family=Lato:wght@300;400&display=swap");

    :root {
        /* Primary dark blue palette */
        --blue: #1f3a8a;
        /* Deep professional blue */
        --blue-soft: #3b5fc4;
        /* Lighter accent blue */
        --dark: #0b1220;
        /* Very dark navy (shadows) */
        --light: #ffffff;
        /* White text */

        --deg: -86deg;
        --trans: all 0.4s ease 0s;
    }



    body *,
    body *:before,
    body *:after {
        box-sizing: border-box;
    }

    .content {
        width: 120vmin;
    }

    h2 {
        text-align: center;
    }

    .team {
        padding: 2em 0 2em 2.5em;
        margin: 0;
    }

    .member {
        margin: 1.5em 0 0.5em;
        padding: 0.73em;
        background: linear-gradient(83deg,
                var(--blue) 0 97%,
                #fff0 calc(97% + 1px) 100%);
        position: relative;
        list-style: none;
        display: inline-block;
        transform: scale(0.85);
        transition: var(--trans);
        color: var(--light);
        /* ✅ WHITE TEXT */
    }

    .member:nth-of-type(even) {
        text-align: right;
        background: linear-gradient(-83deg,
                var(--blue-soft) 0 97%,
                #fff0 calc(97% + 1px) 100%);
    }

    .thumb {
        width: 13vmin;
        height: 13vmin;
        float: left;
        margin-right: 1.25em;
        background: linear-gradient(var(--deg),
                var(--light) 0 70%,
                var(--blue) 0% 100%);
        transform: rotate(-4deg);
        transition: var(--trans);
        border-radius: 0.25em;
        overflow: hidden;
        margin-left: -3em;
        padding: 0.5em;
    }

    .member:nth-of-type(even) .thumb {
        --deg: 86deg;
        float: right;
        margin-left: 2em;
        margin-right: -3em;
        transform: rotate(4deg);
    }

    .thumb img {
        width: 100%;
        height: 100%;
        border-radius: 0.25em;
        filter: grayscale(1);
        background: var(--light);
    }

    .member:hover {
        transform: scale(1);
        transition: var(--trans);
        filter: drop-shadow(0px 20px 10px #0008);
    }

    .member:hover .thumb {
        padding: 0.1em;
        transition: var(--trans);
        transform: rotate(-1deg);
        --deg: -89deg;
    }

    .member:nth-of-type(even):hover .thumb {
        --deg: 91deg;
    }

    .member:hover .thumb img {
        filter: none;
        transition: var(--trans);
    }

    .description {
        padding-top: 1vmin;
    }

    .description p {
        padding: 0 2em;
        margin-bottom: 1em;
    }

    h3 {
        background: linear-gradient(182deg, #fff0 60%, var(--light) 0 100%);
        display: inline;
        transform: rotate(-2deg);
        position: absolute;
        margin: 0;
        margin-top: -2.25em;
        left: 9vmin;
        padding: 0.5em 0.75em;
        color: var(--blue);
        border-radius: 0.25em;
        font-size: 1.35em;
        transform-origin: left bottom;
    }

    .member:nth-of-type(even) h3 {
        left: inherit;
        right: 9vmin;
        transform: rotate(2deg);
        transform-origin: right bottom;
        background: linear-gradient(-182deg, #fff0 60%, var(--light) 0 100%);
    }

    .member:hover h3 {
        transition: var(--trans);
        transform: rotate(0deg);
        background: linear-gradient(180deg, #fff0 59%, var(--light) 0 100%);
    }

    .co-funder:after {
        content: "CLS Decom Lead";
        font-size: 0.75em;
        position: absolute;
        top: -1.5em;
        background: var(--blue);
        right: 4em;
        transform: rotate(3deg);
        padding: 0.35em 0.75em 0.5em;
        border-radius: 0.25em;
        color: var(--darlightk);
        font-weight: bold;
    }

    .co-funder:nth-of-type(even):after {
        right: inherit;
        left: 4em;
        transform: rotate(-3deg);
    }

    .description p a {
        display: inline-block;
        margin: 0.5em 0 0 0;
        background: var(--light);
        color: var(--blue);
        padding: 0.1em 0.5em 0.35em;
        border-radius: 0.5em;
        text-decoration: none;
        transition: var(--trans);
    }

    .description p a:hover {
        transition: var(--trans);
        color: var(--light);
        background: var(--blue);
        font-weight: bold;
    }

    .description p a img {
        float: left;
        width: 22px;
        filter: invert(1);
        border-radius: 0.15em;
        padding: 2px;
        background: #fff;
        margin-right: 2px;
    }

    /* ===== Compact Team Page Title ===== */

    .team-title-wrapper {
        */ display: flex;
        justify-content: center;
    }

    .team-title {
        font-size: clamp(1.8rem, 3.2vw, 2.8rem);
        /* MUCH smaller */
        font-weight: 800;
        letter-spacing: 0.06em;
        text-transform: uppercase;

        color: #ffffff;

        padding: 0.25em 0.7em;
        /* reduced height */
        background: linear-gradient(100deg,
                var(--blue) 0 96%,
                transparent 96% 100%);

        transform: rotate(-1.2deg);
        /* subtle tilt */
        box-shadow: 0 10px 8px rgba(0, 0, 0, 0.14);

        line-height: 1.25;
        white-space: nowrap;
    }

    .team-title span {
        font-weight: 400;
        font-style: italic;
        margin: 0 0.25em;
    }

    #chartdiv {
        width: 100%;
        max-width: 100%;
        height: 500px;
    }
    </style>
    <!-- Resources -->
    <script src="https://cdn.amcharts.com/lib/5/index.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/plugins/colorPicker.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/gantt.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include './pages/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include './pages/navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800 d-flex align-items-center">
                            Execution Dashboard - Timeline </h1>
                    </div>
					<div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4 pop">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Applications On-boarded to Decomm Factory</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                1</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fab fa-elementor fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4 pop" data-toggle="tooltip" data-placement="top"
                            title="Index greater than 0.8">
                            <div class="card border-left-danger shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                                Current Wave</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                1</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-sort-amount-up fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Pending Requests Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4 pop" data-toggle="tooltip" data-placement="top"
                            title="Index between 0.4 and 0.8">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Application Decommissioned</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                0</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-random fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-4 pop" data-toggle="tooltip" data-placement="top"
                            title="Index lesser than 0.4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Size of Data Archived</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                1.4 GB</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-sort-amount-down-alt fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="chartdiv"></div>



                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include './pages/footer.php'; ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <script>
    am5.ready(function() {

        // Create root element
        // https://www.amcharts.com/docs/v5/getting-started/#Root_element
        var root = am5.Root.new("chartdiv");

        // Set themes
        // https://www.amcharts.com/docs/v5/concepts/themes/
        root.setThemes([
            am5themes_Animated.new(root)
        ]);

        // Create Gantt chart
        // https://www.amcharts.com/docs/v5/charts/gantt/
        var gantt = root.container.children.push(am5gantt.Gantt.new(root, {}));

        // Set category data
        // https://www.amcharts.com/docs/v5/charts/gantt/#Category_data
        gantt.yAxis.data.setAll([{
            name: "Pre-Decom Readiness",
            id: "gantt_0"
        }, {
            name: "Data",
            id: "gantt_1"
        }, {
            name: "Data Archival",
            id: "gantt_2",
            parentId: "gantt_1"
        }, {
            name: "Data Purge",
            id: "gantt_3",
            parentId: "gantt_1"
        }, {
            name: "App Removal",
            id: "gantt_4"
        }, {
            name: "Disable SQL jobs / DB integrations",
            id: "gantt_5",
            parentId: "gantt_4"
        }, {
            name: "Application source code archival",
            id: "gantt_6",
            parentId: "gantt_4"
        }, {
            name: "Turn off automatic deployments",
            id: "gantt_7",
            parentId: "gantt_4"
        }, {
            name: "Remove website / disable URL",
            id: "gantt_8",
            parentId: "gantt_4"
        }, {
            name: "Source code decommission",
            id: "gantt_9",
            parentId: "gantt_4"
        }, {
            name: "App folders & server directories clean up",
            id: "gantt_10",
            parentId: "gantt_4"
        }, {
            name: "Retire Batch controls and jobs in SNOW",
            id: "gantt_11",
            parentId: "gantt_4"
        }, {
            name: "Closure",
            id: "gantt_12"
        }]);

        // Set series data
        // https://www.amcharts.com/docs/v5/charts/gantt/#Series_data
        gantt.series.data.setAll([{
            start: new Date(2026, 4, 2).getTime(), // Sept 17, 2025
            duration: 2,
            progress: 1,
            id: "gantt_0",
            linkTo: ["gantt_1"]
        }, {
            start: new Date(2026, 4, 6).getTime(), // Sept 17, 2025
            id: "gantt_1",
            linkTo: ["gantt_4"]
        }, {
            start: new Date(2026, 4, 8).getTime(), // Sept 17, 2025
            duration: 2,
            progress: 1,
            id: "gantt_2",
            linkTo: ["gantt_3"]
        }, {
            start: new Date(2026, 4, 10).getTime(), // Sept 17, 2025
            duration: 2,
            progress: 0.5,
            id: "gantt_3"
        }, {
            start: new Date(2026, 4, 12).getTime(), // Sept 17, 2025
            id: "gantt_4",
            linkTo: ["gantt_8"]
        }, {
            start: new Date(2026, 4, 15).getTime(), // Sept 17, 2025
            duration: 1,
            progress: 0,
            id: "gantt_5",
            linkTo: ["gantt_6"]
        }, {
            start: new Date(2026, 4, 18).getTime(), // Sept 17, 2025
            duration: 3,
            progress: 0,
            id: "gantt_6",
            linkTo: ["gantt_7"]
        }, {
            start: new Date(2026, 4, 22).getTime(), // Sept 17, 2025
            duration: 1,
            progress: 0,
            id: "gantt_7"
        }, {
            start: new Date(2026, 4, 25).getTime(), // Sept 17, 2025
            duration: 0,
            progress: 0,
            id: "gantt_8"
        }]);

        gantt.appear();


    }); // end am5.ready()
    </script>
    <!-- Scripts For download  -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>
    <script type="text/javascript" src="https://html2canvas.hertzen.com/dist/html2canvas.js"></script>


</body>

</html>
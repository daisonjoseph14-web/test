<?php
error_reporting(E_ALL);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
$_SESSION['currentPage'] = 'dependency'; // <-- set to this page’s key before including sidebar
?>

<?php
require '/var/www/html/vendor/autoload.php';

$m = new MongoDB\Client("mongodb://127.0.0.1/");
$db = $m->nationWide;

?>

<!-- Styles -->
<style>
#incomingChart,#outgoingChart {
    width: 100%;
    height: 2500%;

}

#applyFilter {
    max-width: 250px;
}
</style>

<!-- Resources -->
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/flow.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>

<script>
am5.ready(function() {

// Create root element
// https://www.amcharts.com/docs/v5/getting-started/#Root_element
var root = am5.Root.new("incomingChart");


// Set themes
// https://www.amcharts.com/docs/v5/concepts/themes/
root.setThemes([
  am5themes_Animated.new(root)
]);


// Create series
// https://www.amcharts.com/docs/v5/charts/flow-charts/
var series = root.container.children.push(am5flow.Sankey.new(root, {
  sourceIdField: "from",
  targetIdField: "to",
  valueField: "value",
  paddingRight: 50
}));

series.nodes.get("colors").set("step", 2);


// Set data
// https://www.amcharts.com/docs/v5/charts/flow-charts/#Setting_data
series.data.setAll([
 
]);


// Make stuff animate on load
series.appear(1000, 100);

}); // end am5.ready()
</script>
<script>
am5.ready(function() {

// Create root element
// https://www.amcharts.com/docs/v5/getting-started/#Root_element
var root = am5.Root.new("outgoingChart");


// Set themes
// https://www.amcharts.com/docs/v5/concepts/themes/
root.setThemes([
  am5themes_Animated.new(root)
]);


// Create series
// https://www.amcharts.com/docs/v5/charts/flow-charts/
var series = root.container.children.push(am5flow.Sankey.new(root, {
  sourceIdField: "from",
  targetIdField: "to",
  valueField: "value",
  paddingRight: 50
}));

series.nodes.get("colors").set("step", 2);


// Set data
// https://www.amcharts.com/docs/v5/charts/flow-charts/#Setting_data
series.data.setAll([
  { from: "Pathway (DSM)", to: "Mainframe Bonds", value: 1 },
 { from: "Pathway (DSM)", to: "Mainframe Commercial Property", value: 1 },
 { from: "Pathway (DSM)", to: "Mainframe Farm", value: 1 },
 { from: "Pathway (DSM)", to: "Mainframe General Liability (GLS)", value: 1 },
 { from: "Pathway (DSM)", to: "Foreign Assets-OFAC", value: 1 },
 { from: "Pathway (DSM)", to: "Mainframe Policy Entry", value: 1 },
 { from: "Pathway (DSM)", to: "Mainframe Package Control", value: 1 },
 { from: "Pathway (DSM)", to: "Mainframe Business Owners (SBO)", value: 1 },
 { from: "Pathway (DSM)", to: "DB2 - Base", value: 1 },
 { from: "Pathway (DSM)", to: "Mainframe Workers Comp", value: 1 },
 { from: "Mainframe Business Auto", to: "AG_AMI_AI_Download", value: 1 },
 { from: "Mainframe Business Auto", to: "Allied Endorsements", value: 1 },
 { from: "Mainframe Business Auto", to: "Mainframe Business Owners (SBO)", value: 1 },
 { from: "Mainframe Business Auto", to: "Mainframe Commercial Property", value: 1 },
 { from: "Mainframe Business Auto", to: "Mainframe Farm", value: 1 },
 { from: "Mainframe Business Auto", to: "Mainframe Package Control", value: 1 },
 { from: "Mainframe Business Auto", to: "Mainframe Policy Entry", value: 1 },
 { from: "Mainframe Business Auto", to: "Policy Expirations", value: 1 },
 { from: "Mainframe Business Auto", to: "Run Services Application DB2 Internal Activity", value: 1 },
 
 { from: "AG_AMI_AI_Download", to: "Pathway (DSM)", value: 1 },
 { from: "Mainframe Business Auto", to: "Unknown", value: 1 }

]);


// Make stuff animate on load
series.appear(1000, 100);

}); // end am5.ready()
</script>
<!-- HTML -->
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Decommission Analyzer - Dependency Chart</title>
    <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/custom-style.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- DataTables JS (place after jQuery) -->
    <link href="vendor/datatables/jquery.dataTables.min.js" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.js" rel="stylesheet">

    <style>
    #chartDiv,
    #chartdiv {
        height: 575px;
    }

    /* Smaller, tighter tables */
    .table.table-sm,
    .table-sm th,
    .table-sm td {
        font-size: 12px;
        /* 11–13px range works well */
        line-height: 1.1;
        /* reduce vertical spacing */
        padding: .35rem .5rem;
    }

    /* Optional: wrap long text and allow column width to adjust */
    table.dataTable tbody td {
        white-space: nowrap;
        /* set to normal to wrap; keep nowrap to reduce height */
        text-overflow: ellipsis;
        /* visually indicates truncation */
        overflow: hidden;
        max-width: 320px;
        /* keep huge names under control */
    }

    /* Make header a bit compact too */
    table.dataTable thead th {
        font-size: 12px;
    }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include './pages/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include './pages/navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <!-- <h1 class="h3 mb-0 text-gray-800">Dependency Chart</h1> -->
                    </div>

                    <!-- Content Row -->



                    <div class="row">
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Dependency Chart for all apps
                                    </h6> <!-- Suite Filter -->
                                    <div class="d-flex align-items-center">
                                        <label for="suiteFilter" class="mr-2 mb-0 text-muted"
                                            style="font-size:0.9rem;">App Suite</label>
                                        <select id="suiteFilter" class="form-control form-control-sm">
                                            <option value="Both" selected>Both</option>
                                            <?php foreach ($suiteOptions as $suite): ?>
                                            <option value="<?= htmlspecialchars($suite, ENT_QUOTES, 'UTF-8') ?>">
                                                <?= htmlspecialchars($suite, ENT_QUOTES, 'UTF-8') ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <label for="appFilter" class="mr-2 mb-0 text-muted"
                                            style="font-size:0.9rem;">Application</label>
                                        <select id="appFilter" class="form-control form-control-sm">
                                            <option value="All" selected>All</option>
                                            <?php foreach ($appOptions as $app): ?>
                                            <option><?= htmlspecialchars($app, ENT_QUOTES, 'UTF-8') ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <!-- Card Body -->
                            <div class="card-body">
                                <div id="chartDiv" class="chart-area">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <h6 class="text-primary font-weight-bold mb-2">Incoming Interfaces</h6>
                                            <div id="incomingChart" style="height:600px;"></div>
                                        </div>

                                        <div class="col-lg-6">
                                            <h6 class="text-primary font-weight-bold mb-2">Outgoing Interfaces</h6>
                                            <div id="outgoingChart" style="height:600px;"></div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <?php include './pages/footer.php'; ?>
</body>

</html>
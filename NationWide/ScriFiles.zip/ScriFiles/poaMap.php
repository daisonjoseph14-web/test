<?php
error_reporting(E_ALL);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
$_SESSION['currentPage'] = 'poaMap'; // <-- set to this page’s key before including sidebar
?>
<?php
require '/var/www/html/vendor/autoload.php';
$m= new MongoDB\Client("mongodb://127.0.0.1/");
$db = $m->nationWide;
$collection = $db->POA;

?>
<?php
$results = $collection->find();
$data = [];

foreach ($results as $r) {
    $data[] = [
        "from" => $r["application_name"],
        "to"   => $r["POA"],
        "suite" => $r["Suite"] ?? ""
    ];
}

echo "<script>var poaData = " . json_encode($data) . ";</script>";


$poaList = $collection->distinct('POA');
sort($poaList, SORT_NATURAL | SORT_FLAG_CASE);
?>


<!-- Styles -->
<style>
#chartdiv {
    width: 100%;
    height: 1200px !important;
}
</style>

<!-- Resources -->
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/flow.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>

<!-- Chart code -->
<script>
am5.ready(function() {
    // Create root
    var root = am5.Root.new("chartdiv");

    // Theme
    root.setThemes([am5themes_Animated.new(root)]);

    // Create series (Sankey)
    var series = root.container.children.push(
        am5flow.Sankey.new(root, {
            sourceIdField: "from",
            targetIdField: "to",
            valueField: "value",
            paddingRight: 122
        })
    );

    series.nodes.get("colors").set("step", 2);

    // ---- RENDER FUNCTION (define it as a function, not inside setAll) ----
    function renderChart(selectedSuite, selectedPOA) {

        if (typeof poaData === "undefined") {
            console.warn("poaData not found.");
            return;
        }

        var filtered = poaData.filter(function(item) {

            const suiteOk =
                selectedSuite === "Both" ||
                (item.suite || "") === selectedSuite;

            const poaOk =
                selectedPOA === "All" ||
                (item.to || "") === selectedPOA;

            return suiteOk && poaOk;
        });

        var tupleMap = {};
        filtered.forEach(function(item) {
            var key = item.from + "||" + item.to;
            tupleMap[key] = (tupleMap[key] || 0) + 1;
        });

        var sankeyData = Object.keys(tupleMap).map(function(key) {
            var parts = key.split("||");
            return {
                from: parts[0],
                to: parts[1],
                value: tupleMap[key]
            };
        });

        series.data.setAll(sankeyData);
    }

    // Initial render
    function applyFilters() {
        const suiteVal = document.getElementById("suiteFilter").value;
        const poaVal = document.getElementById("poaFilter").value;
        renderChart(suiteVal, poaVal);
    }

    // Initial render
    applyFilters();

    // Hook both dropdowns
    document.getElementById("suiteFilter")
        .addEventListener("change", applyFilters);

    document.getElementById("poaFilter")
        .addEventListener("change", applyFilters);


    // Animate on load
    series.appear(1000, 100);
}); // end am5.ready()
</script>

<!-- HTML -->
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Decommission Analyzer - Dependency Chart</title>
    <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/custom-style.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

    <style>
    #chartDiv,
    #chartdiv {
        height: 575px;
    }

    #balloon {
        position: absolute;
        top: 359px;
        left: 867px;
        border: 2px solid #ccc;
        background: rgba(255, 255, 255, 0.8);
        padding: 6px;
        font-size: 10px;
        color: #000;
        margin: 40px 0 0 20px;
    }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include './pages/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include './pages/navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <!-- <h1 class="h3 mb-0 text-gray-800">Point of Arrival Chart</h1> -->
                    </div>

                    <!-- Content Row -->



                    <div class="row">
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">

                                    <!-- Title -->
                                    <h6 class="m-0 font-weight-bold text-primary">
                                        Point of Arrival Chart
                                    </h6>

                                    <!-- Filters -->
                                    <div class="d-flex align-items-center">

                                        <!-- App Suite -->
                                        <label for="suiteFilter" class="mr-2 mb-0 text-muted" style="font-size:0.9rem;">
                                            App Suite
                                        </label>
                                        <select id="suiteFilter" class="form-control form-control-sm mr-3"
                                            style="width:150px;">
                                            <option value="Both" selected>All App Suites</option>
                                            <option value="HV">HV</option>
                                            <option value="PCIO">PCIO</option>
                                        </select>

                                        <!-- POA -->
                                        <label for="poaFilter" class="mr-2 mb-0 text-muted" style="font-size:0.9rem;">
                                            POA
                                        </label>
                                        <select id="poaFilter" class="form-control form-control-sm"
                                            style="width:220px;">
                                            <option value="All" selected>All POAs</option>
                                            <?php foreach ($poaList as $poa): ?>
                                            <?php if ($poa === '') continue; ?>
                                            <option value="<?= htmlspecialchars($poa, ENT_QUOTES) ?>">
                                                <?= htmlspecialchars($poa) ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>

                                    </div>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <div id="chartDiv" class="chart-area">
                                        <div id="chartdiv"></div>
                                        <div id="balloon"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
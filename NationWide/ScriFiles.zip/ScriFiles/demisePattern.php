<?php
error_reporting(E_ALL);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
$_SESSION['currentPage'] = 'demisePattern'; // <-- set to this page’s key before including sidebar

?>
<?php
require '/var/www/html/vendor/autoload.php';
$m= new MongoDB\Client("mongodb://127.0.0.1/");
$db = $m->nationWide;
$collection = $db->pattern;
// --- Load App Suite list and the selected value from the querystring ---
$suites = $collection->distinct('App_Suite');  // gets unique suites like ["PCIO", "HV", ...]
sort($suites, SORT_NATURAL | SORT_FLAG_CASE);

// Selected suite from dropdown (?suite=PCIO). Empty = "All App Suites"
$selectedSuite = isset($_GET['suite']) && $_GET['suite'] !== '' ? (string)$_GET['suite'] : '';

$selectedPattern = isset($_GET['pattern']) && $_GET['pattern'] !== ''
    ? (int)$_GET['pattern']
    : null;
// Reusable base match (Pattern filter + optional App_Suite filter)


$baseMatch = [];

if ($selectedSuite !== '') {
    $baseMatch['App_Suite'] = $selectedSuite;
}

if ($selectedPattern !== null) {
    // Single pattern selected
    $baseMatch['Pattern'] = $selectedPattern;
} else {
    // Default: all 16 patterns
    $baseMatch['Pattern'] = ['$in' => range(1, 16)];
}

$patternsToShow = range(1, 10); // [1,2,...,10]

// Prepare a map: patternNo => ['count' => 0, 'description' => null]
$patternStats = [];
foreach ($patternsToShow as $p) {
    $patternStats[$p] = ['count' => 0, 'description' => null];
}

try {
    // Aggregate counts and capture any descriptions seen for each pattern
   $pipeline = [
    // Apply both Pattern range and (optional) App_Suite filter
    ['$match' => $baseMatch],

    // Normalize description across possible field names
    [
        '$addFields' => [
            'Desc' => [
                '$ifNull' => [
                    '$Pattern_Description',
                    [
                        '$ifNull' => [
                            '$Patten_Description',
                            '$Pattern Description'
                        ]
                    ]
                ]
            ]
        ]
    ],

    // Group to get counts and capture descriptions
    [
        '$group' => [
            '_id'   => '$Pattern',
            'count' => ['$sum' => 1],
            'descs' => ['$addToSet' => '$Desc']
        ]
    ],

    ['$sort' => ['_id' => 1]]
];

    $cursor = $collection->aggregate($pipeline);

    foreach ($cursor as $doc) {
        $id    = isset($doc->_id)   ? (int)$doc->_id : null;
        $count = isset($doc->count) ? (int)$doc->count : 0;

        // Pick the first non-empty description if available
       $desc = null;
if (isset($doc->descs) && is_array($doc->descs)) {
    foreach ($doc->descs as $d) {
        $d = (string)$d;
        if (trim($d) !== '') { $desc = $d; break; }   // <- good
    }
}


        if ($id !== null && array_key_exists($id, $patternStats)) {
            $patternStats[$id]['count'] = $count;
            $patternStats[$id]['description'] = $desc;
        }
    }
} catch (Throwable $e) {
    // Fail gracefully; patternStats remains zeros
}

// If you still want a JSON for client-side use
$patternCountsJson = json_encode(
    array_map(
        fn($k, $v) => ['pattern' => $k, 'count' => $v['count'], 'description' => $v['description']],
        array_keys($patternStats),
        $patternStats
    ),
    JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
);
?>
<?php
  // >>> INSERT THIS BLOCK <<<
  $patternDescriptions = [];
  foreach ($patternStats as $num => $stat) {
      $patternDescriptions[(string)$num] = $stat['description'] ?? '';
  }
?>
<script>
// { "1": "desc...", "2": "desc...", ... }
var patternDescriptions = <?= json_encode($patternDescriptions, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
</script>

<!-- Styles -->
<style>
#chartdiv {
    width: 100%;
    height: 1200px !important;
}

.pattern-tile {
    background: #342668;
    /* aligns with your theme */
    color: #fff;
    border-radius: .5rem;
    padding: 12px 14px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    min-height: 86px;
}

.pattern-tile .pattern-name {
    font-size: 14px;
    line-height: 1.2;
    font-weight: 600;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.pattern-tile .pattern-count {
    font-size: 28px;
    font-weight: 700;
    margin-top: 4px;
}

@media (max-width: 575.98px) {
    .pattern-tile .pattern-count {
        font-size: 24px;
    }
}

/* Force exactly 8 tiles per row on large screens */
.pattern-grid {
    display: grid;
    grid-template-columns: repeat(8, 1fr);
    gap: 1rem;
}

/* Tablet */
@media (max-width: 1200px) {
    .pattern-grid {
        grid-template-columns: repeat(4, 1fr);
    }
}

/* Mobile */
@media (max-width: 768px) {
    .pattern-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}
</style>

<!-- Resources -->
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/flow.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="vendor/bootstrap/css/bootstrap.min.css"></script>

<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="js/sb-admin-2.min.js"></script>
<script>
// Delegate to body so any present/future tiles work
$(function() {
    $('body').tooltip({
        selector: '[data-toggle="tooltip"]',
        container: 'body', // render tooltips at <body> to avoid clipping
        html: false, // set to true only if you really need HTML in title
        boundary: 'window' // helps with clipping inside scrollable cards
    });
});
</script>
<script>
$(function() {
    $('[data-toggle="tooltip"]').tooltip();
});
</script>
<!-- Chart code -->
<script>
am5.ready(function() {

    // Create root element
    // https://www.amcharts.com/docs/v5/getting-started/#Root_element
    var root = am5.Root.new("chartdiv");


    // Set themes
    // https://www.amcharts.com/docs/v5/concepts/themes/
    root.setThemes([
        am5themes_Animated.new(root)
    ]);


    // Create series
    // https://www.amcharts.com/docs/v5/charts/flow-charts/
    var series = root.container.children.push(am5flow.Sankey.new(root, {
        sourceIdField: "from",
        targetIdField: "to",
        valueField: "value",
        paddingRight: 100
    }));

    series.nodes.get("colors").set("step", 2);


    // Set data
    // https://www.amcharts.com/docs/v5/charts/flow-charts/#Setting_data

    series.data.setAll([

        <?php
    // If a suite is selected, filter by it; otherwise show all suites
   $query = $baseMatch;

// ✅ Only remove Pattern filter when user selected "All Patterns"
if ($selectedPattern === null) {
    unset($query['Pattern']);
}
        // not needed for Sankey edges; we only need App_Suite filtering here
    $options = ['projection' => ['application_name' => 1, 'Pattern' => 1, 'App_Suite' => 1]];

    $results = $collection->find($query, $options);

    $items = [];
    foreach ($results as $r) {
        $from = isset($r['application_name']) ? addslashes((string)$r['application_name']) : '';
       $to = isset($r['Pattern']) ? 'Pattern ' . (string)$r['Pattern'] : '';
        if ($from === '' || $to === '') continue;
        $items[] = '{ from: "'.$from.'", to: "'.$to.'", value: 1 }';
    }
    echo implode(',', $items);
  ?>
    ]);

    // Make stuff animate on load
    series.appear(1000, 100);

}); // end am5.ready()
</script>

<!-- HTML -->
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Decommission Analyzer - Demise Pattern Chart</title>
    <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/custom-style.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">


    <style>
    #chartDiv,
    #chartdiv {
        height: 575px;
    }

    #balloon {
        position: absolute;
        top: 359px;
        left: 867px;
        border: 2px solid #ccc;
        background: rgba(255, 255, 255, 0.8);
        padding: 6px;
        font-size: 10px;
        color: #000;
        margin: 40px 0 0 20px;
    }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include './pages/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include './pages/navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Demise Pattern Charts</h1>
                    </div>
                    <?php
// Helper to create a compact one-line tooltip text and escape quotes safely
function tooltip_text($p, $desc) {
    $label = 'Pattern ' . (string)$p;
    $d = trim((string)$desc);
    if ($d === '') {
        return $label . ': No description on record';
    }
    // Collapse whitespace and convert " → " arrows if you want a single line
    $d = preg_replace('/\s+/', ' ', $d);
    return $label . ': ' . $d;
}
?>
                    <div id="patternTilesRow" class="pattern-grid">

                        <!-- Pattern 1 -->
                        <div class="pattern-tile shadow-sm" data-pattern="1" data-toggle="tooltip" data-placement="top"
                            title="Pattern 1 : Scream test -- Interface Removal -- Env Cleanup">
                            <div class="pattern-name">Pattern 1</div>
                            <div class="pattern-count" id="pattern-count-1">1</div>
                        </div>

                        <!-- Pattern 2 -->
                        <div class="pattern-tile shadow-sm" data-pattern="2" data-toggle="tooltip" data-placement="top"
                            title="Pattern 2 : Scream test -- Interface Removal -- Env Cleanup -- Infra Release">
                            <div class="pattern-name">Pattern 2</div>
                            <div class="pattern-count" id="pattern-count-2">1</div>
                        </div>
                        <div class="pattern-tile shadow-sm" data-pattern="3" data-toggle="tooltip" data-placement="top"
                            title="Pattern 3 : Scream test -- Interface Removal -- App Removal -- Env Cleanup">
                            <div class="pattern-name">Pattern 3</div>
                            <div class="pattern-count" id="pattern-count-3">4</div>
                        </div>

                        <div class="pattern-tile shadow-sm" data-pattern="4" data-toggle="tooltip" data-placement="top"
                            title="Pattern 4 : Scream test -- Interface Removal -- App Removal -- Env Cleanup -- Infra Release">
                            <div class="pattern-name">Pattern 4</div>
                            <div class="pattern-count" id="pattern-count-4">1</div>
                        </div>

                        <div class="pattern-tile shadow-sm" data-pattern="5" data-toggle="tooltip" data-placement="top"
                            title="Pattern 5 : Scream test -- Purge -- App Removal -- Env Cleanup">
                            <div class="pattern-name">Pattern 5</div>
                            <div class="pattern-count" id="pattern-count-5">1</div>
                        </div>

                        <div class="pattern-tile shadow-sm" data-pattern="6" data-toggle="tooltip" data-placement="top"
                            title="Pattern 6 : Scream test -- Purge -- Interface Removal -- App Removal">
                            <div class="pattern-name">Pattern 6</div>
                            <div class="pattern-count" id="pattern-count-6">1</div>
                        </div>

                        <div class="pattern-tile shadow-sm" data-pattern="7" data-toggle="tooltip" data-placement="top"
                            title="Pattern 7 : Scream test -- Purge -- Interface Removal -- App Removal -- Env Cleanup">
                            <div class="pattern-name">Pattern 7</div>
                            <div class="pattern-count" id="pattern-count-7">11</div>
                        </div>

                        <div class="pattern-tile shadow-sm" data-pattern="8" data-toggle="tooltip" data-placement="top"
                            title="Pattern 8 : Scream test -- Purge -- Interface Removal -- App Removal -- Env Cleanup -- Infra Release">
                            <div class="pattern-name">Pattern 8</div>
                            <div class="pattern-count" id="pattern-count-8">9</div>
                        </div>

                        <div class="pattern-tile shadow-sm" data-pattern="9" data-toggle="tooltip" data-placement="top"
                            title="Pattern 9 : Scream test -- Backup -- Purge -- App Removal -- Env Cleanup">
                            <div class="pattern-name">Pattern 9</div>
                            <div class="pattern-count" id="pattern-count-9">1</div>
                        </div>

                        <div class="pattern-tile shadow-sm" data-pattern="10" data-toggle="tooltip" data-placement="top"
                            title="Pattern 10 : Scream test -- Backup -- Purge -- Interface Removal -- App Removal -- Env Cleanup">
                            <div class="pattern-name">Pattern 10</div>
                            <div class="pattern-count" id="pattern-count-10">1</div>
                        </div>

                        <div class="pattern-tile shadow-sm" data-pattern="11" data-toggle="tooltip" data-placement="top"
                            title="Pattern 11 : Scream test -- Backup -- Purge -- Interface Removal -- App Removal -- Env Cleanup -- Infra Release">
                            <div class="pattern-name">Pattern 11</div>
                            <div class="pattern-count" id="pattern-count-11">19</div>
                        </div>

                        <div class="pattern-tile shadow-sm" data-pattern="12" data-toggle="tooltip" data-placement="top"
                            title="Pattern 12 : Scream test -- Archival -- Purge -- Interface Removal -- App Removal -- Env Cleanup -- Infra Release">
                            <div class="pattern-name">Pattern 12</div>
                            <div class="pattern-count" id="pattern-count-12">1</div>
                        </div>

                        <div class="pattern-tile shadow-sm" data-pattern="13" data-toggle="tooltip" data-placement="top"
                            title="Pattern 13 : Scream test -- Archival -- Backup -- Purge -- Interface Removal -- App Removal -- Env Cleanup">
                            <div class="pattern-name">Pattern 13</div>
                            <div class="pattern-count" id="pattern-count-13">5</div>
                        </div>

                        <div class="pattern-tile shadow-sm" data-pattern="14" data-toggle="tooltip" data-placement="top"
                            title="Pattern 14 : Scream test -- Archival -- Backup -- Purge -- Interface Removal -- App Removal -- Env Cleanup -- Infra Release">
                            <div class="pattern-name">Pattern 14</div>
                            <div class="pattern-count" id="pattern-count-14">4</div>
                        </div>

                        <div class="pattern-tile shadow-sm" data-pattern="15" data-toggle="tooltip" data-placement="top"
                            title="Pattern 15 : Scream test -- Archival -- Backup -- Purge -- Retain -- Interface Removal -- App Removal -- Env Cleanup">
                            <div class="pattern-name">Pattern 15</div>
                            <div class="pattern-count" id="pattern-count-15">3</div>
                        </div>


                        <!-- Pattern 16 -->
                        <div class="pattern-tile shadow-sm" data-pattern="16" data-toggle="tooltip" data-placement="top"
                            title="Pattern 16 : Scream test -- Archival -- Backup -- Purge -- Retain -- Interface Removal -- App Removal -- Env Cleanup -- Infra Release">
                            <div class="pattern-name">Pattern 16</div>
                            <div class="pattern-count" id="pattern-count-16">11</div>
                        </div><br>

                    </div>

                    <!-- Content Row -->



                    <div class="row">
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">
                                        Demise Pattern Data
                                        <?= $selectedSuite !== '' ? ' — ' . htmlspecialchars($selectedSuite) : '' ?>
                                    </h6>

                                    <form method="get" class="form-inline mb-0">

                                        <!-- App Suite -->
                                        <label for="selSuite" class="mr-2 mb-0 font-weight-bold text-secondary">
                                            App Suite
                                        </label>
                                        <select class="form-control mr-4" id="selSuite" name="suite"
                                            onchange="this.form.submit()">
                                            <option value="">All App Suites</option>
                                            <?php foreach ($suites as $suite): ?>
                                            <option value="<?= htmlspecialchars($suite) ?>"
                                                <?= $suite === $selectedSuite ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($suite) ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>

                                        <!-- Pattern -->
                                        <label for="selPattern" class="mr-2 mb-0 font-weight-bold text-secondary">
                                            Pattern
                                        </label>
                                        <select class="form-control" id="selPattern" name="pattern"
                                            onchange="this.form.submit()">
                                            <option value="">All Patterns</option>
                                            <?php for ($i = 1; $i <= 16; $i++): ?>
                                            <option value="<?= $i ?>"
                                                <?= (isset($_GET['pattern']) && $_GET['pattern'] == $i) ? 'selected' : '' ?>>
                                                Pattern <?= $i ?>
                                            </option>
                                            <?php endfor; ?>
                                        </select>

                                    </form>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <!-- Fixed 5 tiles (in the order you set in $patternsToShow) -->

                                    <div id="chartDiv" class="chart-area">
                                        <div id="chartdiv"></div>
                                        <div id="balloon"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <script>
                        // Delegate to body so any present/future tiles work
                        $(function() {
                            $('body').tooltip({
                                selector: '[data-toggle="tooltip"]',
                                container: 'body', // render tooltips at <body> to avoid clipping
                                html: false, // set to true only if you really need HTML in title
                                boundary: 'window' // helps with clipping inside scrollable cards
                            });
                        });
                        </script>


                        <script>
                        document.addEventListener('DOMContentLoaded', function() {

                            patternStats.forEach(p => {
                                const countEl = document.getElementById(`pattern-count-${p.pattern}`);
                                const tileEl = document.querySelector(
                                    `.pattern-tile[data-pattern="${p.pattern}"]`);

                                if (!countEl || !tileEl) return;

                                // Set count
                                countEl.textContent = p.count ?? 0;

                                // Tooltip text
                                let tooltipText = `Pattern ${p.pattern}: `;
                                if (p.description && p.description.trim() !== '') {
                                    tooltipText += p.description.replace(/\s+/g, ' ');
                                } else {
                                    tooltipText += 'No description on record';
                                }

                                tileEl.setAttribute('title', tooltipText);
                            });

                            // Re-initialize Bootstrap tooltips
                            $('[data-toggle="tooltip"]').tooltip();
                        });
                        </script>
</body>

</html>
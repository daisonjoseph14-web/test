<?php
error_reporting(E_ALL);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
$_SESSION['currentPage'] = 'dependency'; // <-- set to this page’s key before including sidebar
?>

<?php
require '/var/www/html/vendor/autoload.php';

$m = new MongoDB\Client("mongodb://127.0.0.1/");
$db = $m->nationWide;

$incomingCol = $db->Incoming;
$outgoingCol = $db->Outgoing;

$incomingLinks = [];
$outgoingLinks = [];
$seen = [];

$suiteSet = [];
$appSet = [];

/**
 * Prevent circular duplicates
 */
function safeAdd(&$arr, &$seen, $from, $to, $suite) {
    $from = trim((string)$from);
    $to   = trim((string)$to);
    $suite = trim((string)$suite);

    if ($from === '' || $to === '' || $from === $to) return;

    $key = "$from→$to";
    $reverse = "$to→$from";

    if (isset($seen[$key]) || isset($seen[$reverse])) return;
    $seen[$key] = true;

    $arr[] = [
        "from" => $from,
        "to" => $to,
        "value" => 1,
        "suite" => $suite
    ];
}

/* ✅ INCOMING */
foreach ($incomingCol->find() as $doc) {
    $suiteSet[$doc['Suite']] = true;
    $appSet[$doc['App_Name']] = true;

    safeAdd(
        $incomingLinks,
        $seen,
        $doc['Incoming_App_Name'] ?? '',
        $doc['App_Name'] ?? '',
        $doc['Suite'] ?? ''
    );
}

/* ✅ OUTGOING */
foreach ($outgoingCol->find() as $doc) {
    $suiteSet[$doc['Suite']] = true;
    $appSet[$doc['App_Name']] = true;

    safeAdd(
        $outgoingLinks,
        $seen,
        $doc['App_Name'] ?? '',
        $doc['Outgoing_App_Name'] ?? '',
        $doc['Suite'] ?? ''
    );
}

/* ✅ Dropdown options */
$suiteOptions = array_keys($suiteSet);
sort($suiteOptions, SORT_NATURAL | SORT_FLAG_CASE);

$appOptions = array_keys($appSet);
sort($appOptions, SORT_NATURAL | SORT_FLAG_CASE);

/* ✅ JSON for JS */
$jsonIncoming = json_encode($incomingLinks);
$jsonOutgoing = json_encode($outgoingLinks);
?>


<!-- Styles -->
<style>
#incomingChart,
#outgoingChart {
    width: 100%;
    height: 500px;
    /* ✅ stable height */
}


#applyFilter {
    max-width: 250px;
}
</style>

<!-- Resources -->
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/flow.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>

<script>
am5.ready(function() {

    // 1️⃣ Create root
    var root = am5.Root.new("incomingChart");
    root.setThemes([am5themes_Animated.new(root)]);

    // 2️⃣ Create Sankey series
    var series = root.container.children.push(
        am5flow.Sankey.new(root, {
            sourceIdField: "from",
            targetIdField: "to",
            valueField: "value",
            paddingRight: 50
        })
    );

    series.nodes.get("colors").set("step", 2);

    const incomingData = <?= $jsonIncoming ?>;
    series.data.setAll(incomingData);

    // 3️⃣ Animate
    series.appear(1000, 100);

});
</script>

<script>
am5.ready(function() {

    // 1️⃣ Create root
    var root = am5.Root.new("outgoingChart");
    root.setThemes([am5themes_Animated.new(root)]);

    // 2️⃣ Create Sankey series
    var series = root.container.children.push(
        am5flow.Sankey.new(root, {
            sourceIdField: "from",
            targetIdField: "to",
            valueField: "value",
            paddingRight: 50
        })
    );

    series.nodes.get("colors").set("step", 2);

    const outgoingData = <?= $jsonOutgoing ?>;

    series.data.setAll(outgoingData);


    // 3️⃣ Animate
    series.appear(1000, 100);

});
</script>
<!-- HTML -->
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Decommission Analyzer - Dependency Chart</title>
    <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/custom-style.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- DataTables JS (place after jQuery) -->
    <link href="vendor/datatables/jquery.dataTables.min.js" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.js" rel="stylesheet">

    <style>
    .card-body {
        overflow: visible;
    }

    /* Smaller, tighter tables */
    .table.table-sm,
    .table-sm th,
    .table-sm td {
        font-size: 12px;
        /* 11–13px range works well */
        line-height: 1.1;
        /* reduce vertical spacing */
        padding: .35rem .5rem;
    }

    /* Optional: wrap long text and allow column width to adjust */
    table.dataTable tbody td {
        white-space: nowrap;
        /* set to normal to wrap; keep nowrap to reduce height */
        text-overflow: ellipsis;
        /* visually indicates truncation */
        overflow: hidden;
        max-width: 320px;
        /* keep huge names under control */
    }

    /* Make header a bit compact too s*/
    table.dataTable thead th {
        font-size: 12px;
    }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include './pages/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include './pages/navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <!-- <h1 class="h3 mb-0 text-gray-800">Dependency Chart</h1> -->
                    </div>

                    <!-- Content Row -->



                    <div class="row">
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Dependency Chart for all apps
                                    </h6> <!-- Suite Filter -->
                                    <div class="d-flex align-items-center">
                                        <label for="suiteFilter" class="mr-2 mb-0 text-muted"
                                            style="font-size:0.9rem;">App Suite</label>
                                        <select id="suiteFilter" class="form-control form-control-sm">
                                            <option value="Both" selected>Both</option>
                                            <?php foreach ($suiteOptions as $suite): ?>
                                            <option value="<?= htmlspecialchars($suite, ENT_QUOTES, 'UTF-8') ?>">
                                                <?= htmlspecialchars($suite, ENT_QUOTES, 'UTF-8') ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <label for="appFilter" class="mr-2 mb-0 text-muted"
                                            style="font-size:0.9rem;">Application</label>
                                        <select id="appFilter" class="form-control form-control-sm">
                                            <option value="All" selected>All</option>
                                            <?php foreach ($appOptions as $app): ?>
                                            <option><?= htmlspecialchars($app, ENT_QUOTES, 'UTF-8') ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <!-- Card Body -->
                            <div class="card-body">
                                <div class="chart-area">

                                    <div class="row mb-4">
                                        <div class="col-lg-12">
                                            <h6 class="text-primary font-weight-bold mb-2">Incoming Interfaces</h6>
                                            <div id="incomingChart"></div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-12">
                                            <h6 class="text-primary font-weight-bold mb-2">Outgoing Interfaces</h6>
                                            <div id="outgoingChart"></div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <?php include './pages/footer.php'; ?>
</body>

</html>
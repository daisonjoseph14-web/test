<?php
error_reporting(0);
require_once './pages/auth/pageHandler.php';

ob_start();
session_start();
// echo "Hello from PHP!";
$_SESSION['currentPage'] = 'Team';

//$m = new MongoClient();
require '/var/www/html/vendor/autoload.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Decommission Analyzer - Meet the Team</title>
    <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/custom-style.css" rel="stylesheet">

    <style>
    .job-card-row {
        margin-top: 2px !important;

    }

    .job-card-content {
        background-color: #342668;
        color: white;
        padding: 4px;
        margin-bottom: 10px;
        border-radius: .35rem;
        font-size: 12px !important;
    }

    .job-card-header {
        margin-bottom: 10px;
        font-weight: bold;
    }

    .green {

        background-color: #11af11f3;
        /* light green */

    }

    .dpd-td {
        background-color: #342668;
        color: #FFFFFF;
        padding: 7px !important;
        border-radius: .35rem;
        font-size: 12px !important;
    }

    .circle {
        background: #342668;
        border-radius: 50%;
        width: 60px;
        height: 60px;
        color: white;
        padding: 1px;
        margin-bottom: 5px;
        margin-top: 5px;
        margin-left: 5px;
        display: flex;
        align-items: center;
        align-content: center;
        justify-content: center;
    }

    /* Circle utility */
    .circle {

        border-radius: 50%;
        /* Makes it a circle */



        /* Center the content */
        display: grid;
        place-items: center;
        text-align: center;
        padding: 12px;
        /* for some breathing room */
        margin-inline: auto;
        /* center horizontally in the column */

        /* If content overflows, keep it tidy */
        overflow: hidden;
    }

    /* Strong override to defeat margin-inline:auto and display:grid */
    .circle-left {
        margin-left: 5px !important;
        margin-right: 0 !important;
        margin-inline: 0 !important;
        /* cancels previous centering */
        display: flex !important;
        /* if you prefer flex */
        align-items: center !important;
        justify-content: center !important;
    }


    /* Optional: make the header align nicely */
    #decomSeq .job-card-header {
        margin-bottom: 12px;
        font-weight: 600;
    }

    /* Fixed-size box + centered text for Application Name */
    .appname-box {
        width: 100%;
        /* keep the Bootstrap column width */
        min-height: 33px;
        /* choose the height you want */
        max-height: 33px;
        /* same as min to keep height fixed */

        display: grid;
        place-items: center;
        /* vertical + horizontal centering */
        text-align: center;

        line-height: 1.2;
        overflow: hidden;
        /* hide spillover while we shrink text */
        word-break: break-word;
        /* break very long ids/names */
        hyphens: auto;

        /* starting font size; JS will shrink from here if needed */
        font-size: 20px;
    }

    .appfunctionality-box {
        width: 100%;
        /* keep the Bootstrap column width */
        min-height: 33px;
        /* choose the height you want */
        max-height: 33px;
        /* same as min to keep height fixed */

        display: grid;
        place-items: center;
        /* vertical + horizontal centering */
        text-align: center;

        line-height: 1.2;
        overflow: hidden;
        /* hide spillover while we shrink text */
        word-break: break-word;
        /* break very long ids/names */
        hyphens: auto;

        /* starting font size; JS will shrink from here if needed */
        font-size: 20px;
    }

    /* Control the minimum height both pattern tables should share */
    :root {
        --pattern-min-height: 175px;
        /* adjust as needed to match your design */
    }

    .pattern {
        width: 100%;
        table-layout: fixed;
        /* safer column sizing */
        border-collapse: separate;
        /* your existing pill look relies on spacing/shadows */
    }

    .pattern tbody {
        display: grid;
        /* turn tbody into a grid container */
        align-content: stretch;
        /* fill available height */
        min-height: var(--pattern-min-height);
        height: 100%;
        /* optional: vertical gap between rows */
    }

    /* Left: 4 equal rows; Right: 5 equal rows */
    .pattern-4 tbody {
        grid-template-rows: repeat(4, 1fr);
    }

    .pattern-5 tbody {
        grid-template-rows: repeat(5, 1fr);
    }

    /* Each row becomes a 2-column grid (label | value) */
    .pattern tbody tr {
        display: grid;
        grid-template-columns: 1fr 60px;
        /* left label grows, right status fits */
        align-items: stretch;
        /* cells stretch the row height */
    }

    /* Cells fill the row height and keep your pill style centered vertically */
    .pattern tbody td {
        display: flex;
        align-items: center;
        /* center content vertically in the pill */
        justify-content: space-between;
        /* keeps label/value clean if needed */
    }

    .pattern tbody td:last-child {
        justify-content: center;
        /* center Yes/No horizontally */
        text-align: center;
        font-weight: 600;
    }


    /* Keep your existing .dpd-td pill visuals intact */
    .dpd-td {
        /* your existing styles already include padding, bg, radius, etc. */
    }
    @import url("https://fonts.googleapis.com/css2?family=Lato:wght@300;400&display=swap");

    :root {
    /* Primary dark blue palette */
    --blue: #1f3a8a;        /* Deep professional blue */
    --blue-soft: #3b5fc4;  /* Lighter accent blue */
    --dark: #0b1220;       /* Very dark navy (shadows) */
    --light: #ffffff;     /* White text */

    --deg: -86deg;
    --trans: all 0.4s ease 0s;
}

/* body {
	margin: 0;
	padding: 0;
	overflow-x: hidden;
	display: flex;
	justify-content: center;
	font-family: "Lato", Arial, Helvetica, serif;
	background: linear-gradient(90deg, #131417, var(--dark) 35% 65%, #131417);
	font-size: 1em;
} */

body *,
body *:before,
body *:after {
	box-sizing: border-box;
}

.content {
	width: 120vmin;
}

h2 {
	text-align: center;
}

.team {
	padding: 2em 0 2em 2.5em;
	margin: 0;
}

.member {
    margin: 1.5em 0 0.5em;
    padding: 0.73em;
    background: linear-gradient(
        83deg,
        var(--blue) 0 97%,
        #fff0 calc(97% + 1px) 100%
    );
    position: relative;
    list-style: none;
    display: inline-block;
    transform: scale(0.85);
    transition: var(--trans);
    color: var(--light); /* ✅ WHITE TEXT */
}

.member:nth-of-type(even) {
	text-align: right;
	background: linear-gradient(
		-83deg,
		var(--blue-soft) 0 97%,
		#fff0 calc(97% + 1px) 100%
	);
}

.thumb {
	width: 13vmin;
	height: 13vmin;
	float: left;
	margin-right: 1.25em;
	background: linear-gradient(
		var(--deg),
		var(--light) 0 70%,
		var(--blue) 0% 100%
	);
	transform: rotate(-4deg);
	transition: var(--trans);
	border-radius: 0.25em;
	overflow: hidden;
	margin-left: -3em;
	padding: 0.5em;
}

.member:nth-of-type(even) .thumb {
	--deg: 86deg;
	float: right;
	margin-left: 2em;
	margin-right: -3em;
	transform: rotate(4deg);
}

.thumb img {
	width: 100%;
	height: 100%;
	border-radius: 0.25em;
	filter: grayscale(1);
	background: var(--light);
}

.member:hover {
	transform: scale(1);
	transition: var(--trans);
	filter: drop-shadow(0px 20px 10px #0008);
}

.member:hover .thumb {
	padding: 0.1em;
	transition: var(--trans);
	transform: rotate(-1deg);
	--deg: -89deg;
}

.member:nth-of-type(even):hover .thumb {
	--deg: 91deg;
}

.member:hover .thumb img {
	filter: none;
	transition: var(--trans);
}

.description {
	padding-top: 1vmin;
}

.description p {
	padding: 0 2em;
	margin-bottom: 1em;
}

h3 {
	background: linear-gradient(182deg, #fff0 60%, var(--light) 0 100%);
	display: inline;
	transform: rotate(-2deg);
	position: absolute;
	margin: 0;
	margin-top: -2.25em;
	left: 9vmin;
	padding: 0.5em 0.75em;
	color: var(--blue);
	border-radius: 0.25em;
	font-size: 1.35em;
	transform-origin: left bottom;
}

.member:nth-of-type(even) h3 {
	left: inherit;
	right: 9vmin;
	transform: rotate(2deg);
	transform-origin: right bottom;
	background: linear-gradient(-182deg, #fff0 60%, var(--light) 0 100%);
}

.member:hover h3 {
	transition: var(--trans);
	transform: rotate(0deg);
	background: linear-gradient(180deg, #fff0 59%, var(--light) 0 100%);
}

.co-funder:after {
	content: "CLS Decom Lead";
	font-size: 0.75em;
	position: absolute;
	top: -1.5em;
	background: var(--blue);
	right: 4em;
	transform: rotate(3deg);
	padding: 0.35em 0.75em 0.5em;
	border-radius: 0.25em;
	color: var(--darlightk);
	font-weight: bold;
}

.co-funder:nth-of-type(even):after {
	right: inherit;
	left: 4em;
	transform: rotate(-3deg);
}

.description p a {
	display: inline-block;
	margin: 0.5em 0 0 0;
	background: var(--light);
	color: var(--blue);
	padding: 0.1em 0.5em 0.35em;
	border-radius: 0.5em;
	text-decoration: none;
	transition: var(--trans);
}
.description p a:hover {
	transition: var(--trans);
	color: var(--light);
	background: var(--blue);
	font-weight: bold;
}

.description p a img {
	float: left;
	width: 22px;
	filter: invert(1);
	border-radius: 0.15em;
	padding: 2px;
	background: #fff;
	margin-right: 2px;
}
/* ===== Compact Team Page Title ===== */

.team-title-wrapper {
    */
    display: flex;
    justify-content: center;
}

.team-title {
    font-size: clamp(1.8rem, 3.2vw, 2.8rem); /* MUCH smaller */
    font-weight: 800;
    letter-spacing: 0.06em;
    text-transform: uppercase;

    color: #ffffff;

    padding: 0.25em 0.7em; /* reduced height */
    background: linear-gradient(
        100deg,
        var(--blue) 0 96%,
        transparent 96% 100%
    );

    transform: rotate(-1.2deg); /* subtle tilt */
    box-shadow: 0 10px 8px rgba(0, 0, 0, 0.14);

    line-height: 1.25;
    white-space: nowrap;
}

.team-title span {
    font-weight: 400;
    font-style: italic;
    margin: 0 0.25em;
}

    </style>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include './pages/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include './pages/navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
<div class="team-title-wrapper">
    <h1 class="team-title">
        TEAM WORK <span>is a</span> DREAM WORK
    </h1>
</div>

                  <div class="content">

	<ul class="team">
		<li class="member co-funder">
			<div class="thumb"><img src="./data/Images/Colleen.jpg"></div>
			<div class="description">
				<h3>Colleen Espasito</h3>
				<p>Colleen heads the CLS Decommissioning Project from NationWide. Her Immense knowledge on the Business side and her insights has helped immensely in the Assessment Phase<br><a href="mailto:colleen.esposito@nationwide.com">@Colleen</a></p>
			</div>
		</li>
		<li class="member co-funder">
			<div class="thumb"><img src="./data/Images/Karina.jpg"></div>
			<div class="description">
				<h3>Karina Huckel</h3>
				<p>Karina was heading the CLS Decom earlier and is currently shifting to a new role. She ensures all the approvals in her queue and approved at the earliest which fastens the delivery work. We will surely miss her Charisma and valuable insights<br><a href="mailto:colleen.esposito@nationwide.com">@Karina</a></p>
			</div>
		</li>
		<li class="member">
			<div class="thumb"><img src="./data/Images/Kalyani.jpg"></div>
			<div class="description">
				<h3>Saikalyani Bulusu</h3>
				<p>Kalyani wears a lot of hats in Nationwide as she oversees multiple domains. Her faith and trust in Capgemini has resulted in us working together as a team.<br><a href="mailto:colleen.esposito@nationwide.com">@Kalyani</a></p>
			</div>
		</li>
		<li class="member">
			<div class="thumb"><img src="./data/Images/Frank.jpg"></div>
			<div class="description">
				<h3>Frank Unger</h3>
				<p>Frank leads the HV set of applications and helps in actively collaborating with the Capgemini team to decommission a huge set of Applications<br><a href="mailto:colleen.esposito@nationwide.com">@Frank</a></p>
			</div>
		</li>
		<li class="member">
			<div class="thumb"><img src="./data/Images/Prasad.jpg"></div>
			<div class="description">
				<h3>Penchala Prasad</h3>
				<p>Prasad is the Legacy head of all the Mainframe applications that are being decommissioned. His reviews and feedbacks helps Capgemin folks to on-board the apps to the Decomm Factory.<br><a href="mailto:colleen.esposito@nationwide.com">@Prasad</a></p>
			</div>
		</li>
        
		<li class="member">
			<div class="thumb"><img src="./data/Images/Angela.jpg"></div>
			<div class="description">
				<h3>Angela Pike</h3>
				<p> Angie - Our Business Partner who helps in securing the approvals and plays a key role in sending the communications to the application team<br><a href="mailto:colleen.esposito@nationwide.com">@Angela</a></p>
			</div>
		</li>
		<li class="member">
			<div class="thumb"><img src="./data/Images/Samar.png"></div>
			<div class="description">
				<h3>Samar Dave</h3>
				<p>The vital thread that helped in connecting NationWide and Capgemini folks for this decommission Project<br><a href="mailto:colleen.esposito@nationwide.com">@Samar</a></p>
			</div>
		</li>
		<li class="member">
			<div class="thumb"><img src="./data/Images/Dhinakar.jpg"></div>
			<div class="description">
				<h3>Dhinakar Selwyn</h3>
				<p>Dhinakar heads the Core Tech CoE from Capgemini and his Guidance has been crucial for the success of the First Milestone<br><a href="mailto:colleen.esposito@nationwide.com">@Dhinakar</a></p>
			</div>
		</li>
        
		<li class="member">
			<div class="thumb"><img src="./data/Images/Sandeep.jpg"></div>
			<div class="description">
				<h3>Sandeep</h3>
				<p>Our Decom Governance Lead who provided his valuabe time and insights thorughtout this journey to fast-track the Assessment Phase<br><a href="mailto:colleen.esposito@nationwide.com">@Sandeep</a></p>
			</div>
		</li>
		<li class="member">
			<div class="thumb"><img src="./data/Images/Hari.jpg"></div>
			<div class="description">
				<h3>Hari Prasad</h3>
				<p>Hari is the fore-runner in this project as his thoughts and plans from the SOW phase helped in securing this Decommissioning Project<br><a href="mailto:colleen.esposito@nationwide.com">@Hari</a></p>
			</div>
		</li>
		<li class="member">
			<div class="thumb"><img src="./data/Images/Senthil2.jpg"></div>
			<div class="description">
				<h3>Senthilnathan</h3>
				<p>Our Decom Factory Lead who orchestrates and delivers all the reports on time to ensure Capgemini reaches every Milestone<br><a href="mailto:colleen.esposito@nationwide.com">@Senthil</a></p>
			</div>
		</li>
		<li class="member">
			<div class="thumb"><img src="./data/Images/Sumithra.jpg"></div>
			<div class="description">
				<h3>Sumithra</h3>
				<p>Sumi has been Leading this Decomm Assessment phase and her immense experience has helped in fast-tracking the deliveries<br><a href="mailto:colleen.esposito@nationwide.com">@Sumithra</a></p>
			</div>
		</li>
		<li class="member">
			<div class="thumb"><img src="./data/Images/Daison.jpg"></div>
			<div class="description">
				<h3>Daison</h3>
				<p>Daison has helped in developing and customising the Dashboard<br><a href="mailto:colleen.esposito@nationwide.com">@Daison</a></p>
			</div>
		</li>
        
		<li class="member">
			<div class="thumb"><img src="./data/Images/Sridevi.jfif"></div>
			<div class="description">
				<h3>Sridevi</h3>
				<p>Sridevi is the Data Archival SME who will be helping us in the crucial Archival Process.<br><a href="mailto:colleen.esposito@nationwide.com">@Sridevi</a></p>
			</div>
		</li>
		<li class="member">
			<div class="thumb"><img src="./data/Images/Kuladeepa.jpg"></div>
			<div class="description">
				<h3>Kuladeepa</h3>
				<p>Kuladeepa's Experience in the past has helped us generate the CAP360 reports to identify the interfaces<br><a href="mailto:colleen.esposito@nationwide.com">@Kuladeepa</a></p>
			</div>
		</li>
		<li class="member">
			<div class="thumb"><img src="./data/Images/Sailza.jpg"></div>
			<div class="description">
				<h3>Sailza</h3>
				<p>Her Hardwork and Perseverance has helped us complete most of the Handbooks and reports on time<br><a href="mailto:colleen.esposito@nationwide.com">@Sailza</a></p>
			</div>
		</li>
	</ul>

</div>


                    <!-- Content Row -->
                    <div class="row">
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">

                                
                            </div>
                        </div>
                    </div>


                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include './pages/footer.php'; ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    
    <!-- Scripts For download  -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>
    <script type="text/javascript" src="https://html2canvas.hertzen.com/dist/html2canvas.js"></script>


</body>

</html>
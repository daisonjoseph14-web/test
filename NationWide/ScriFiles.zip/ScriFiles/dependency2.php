<?php
error_reporting(E_ALL);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
$_SESSION['currentPage'] = 'dependency'; // <-- set to this page’s key before including sidebar
?>

<?php
require '/var/www/html/vendor/autoload.php';
$m= new MongoDB\Client("mongodb://127.0.0.1/");
$db = $m->nationWide;
$collection = $db->dependency;
$collection1 = $db->Incoming;
$collection2 = $db->Outgoing;
// Pull everything you need and encode safely as JSON
$cursor = $collection->find(
    [],
    ['projection' => ['Source' => 1, 'Target' => 1, 'Suite' => 1, 'Weight' => 1]]
);

$data = [];
foreach ($cursor as $doc) {
    $data[] = [
        'from'  => isset($doc['Source']) ? (string)$doc['Source'] : '',
        'to'    => isset($doc['Target']) ? (string)$doc['Target'] : '',
        'suite' => isset($doc['Suite'])  ? (string)$doc['Suite']  : '',
        // Node size driver (numeric weight). Fallback = 1
        'value' => (isset($doc['Weight']) && is_numeric($doc['Weight']))
                    ? (float)$doc['Weight']
                    : 1
    ];
}
$jsonData = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
?>
<?php
// --- Incoming table data ---
$incomingRows = [];
try {
    $incomingCursor = $collection1->find(
        [],
        [
            'projection' => [
                'From Application ID'   => 1,
                'From Application Name( AH Column from Questionnaire )' => 1,
                'Interface Type( AJ Column from Questionnaire)'        => 1,
                'To Application Name'   => 1
            ],
            'sort' => ['From Application Name( AH Column from Questionnaire )' => 1] // optional: sort nicely
        ]
    );
    foreach ($incomingCursor as $doc) {
        $incomingRows[] = [
            'id'         => isset($doc['From Application ID'])   ? (string)$doc['From Application ID']   : '',
            'name'       => isset($doc['From Application Name( AH Column from Questionnaire )']) ? (string)$doc['From Application Name( AH Column from Questionnaire )'] : '',
            'type'       => isset($doc['Interface Type( AJ Column from Questionnaire)'])        ? (string)$doc['Interface Type( AJ Column from Questionnaire)']        : '',
            'targetName' => isset($doc['To Application Name'])   ? (string)$doc['To Application Name']   : '',
        ];
    }
} catch (Throwable $e) {
    // Log if you want, but keep UI running
    $incomingRows = [];
}

// --- Outgoing table data ---
$outgoingRows = [];
try {
    $outgoingCursor = $collection2->find(
        [],
        [
            'projection' => [
                'From Application ID'   => 1,
                'From Application Name' => 1,
                'Interface Type'        => 1,
                'Outgoing App Name'   => 1
            ],
            'sort' => ['From Application Name' => 1]
        ]
    );
    foreach ($outgoingCursor as $doc) {
        $outgoingRows[] = [
            'id'         => isset($doc['From Application ID'])   ? (string)$doc['From Application ID']   : '',
            'name'       => isset($doc['From Application Name']) ? (string)$doc['From Application Name'] : '',
            'type'       => isset($doc['Interface Type'])        ? (string)$doc['Interface Type']        : '',
            'targetName' => isset($doc['Outgoing App Name'])   ? (string)$doc['Outgoing App Name']   : '',
        ];
    }
} catch (Throwable $e) {
    $outgoingRows = [];
}
?>

<!-- Styles -->
<style>
#chartdiv {
    width: 100%;
    height: 600px;
}
</style>

<!-- Resources -->
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/hierarchy.js"></script>
<script src="https://cdn.amcharts.com/lib/5/percent.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
<!-- Resources -->
<script>
am5.ready(function () {
  // 1) Bring in the PHP data (includes Suite + value)
  const rawLinks = <?php echo $jsonData ?: '[]'; ?>;

  // Colors
  const COLORS = {
    incoming: am5.color(0x4e79a7), // blue
    outgoing: am5.color(0x59a14f), // green
    rest:     am5.color(0x999999)  // grey remainder for rings
  };
  const BAD_NAMES = new Set(["", "tbd", "na", "unknown"]);

  // 2) Create root and theme
  const root = am5.Root.new("chartdiv");
  root.setThemes([am5themes_Animated.new(root)]);

  // 3) Force-Directed series
  const series = root.container.children.push(
    am5hierarchy.ForceDirected.new(root, {
      nameField: "name",
      valueField: "value",
      childDataField: "children",
      minRadius: 18,
      maxRadius: 66,
      manyBodyStrength: -22,
      centerStrength: 0.6,
      velocityDecay: 0.32
    })
  );

  // Make nodes clickable on all browsers
  series.nodes.template.setAll({
    draggable: true,
    interactive: true,                     // <-- important
    tooltipText:
      "{name}\nIncoming (blue): {incomingWeight}\nOutgoing (green): {outgoingWeight}\nTotal weight: {value}",
    cursorOverStyle: "pointer"
  });
  series.circles.template.setAll({
    fill: am5.color(0xf3f3f3),
    fillOpacity: 1,
    stroke: am5.color(0xcccccc),
    strokeOpacity: 0.85,
    strokeWidth: 1
  });
  series.labels.template.setAll({
    interactive: true,                     // <-- important (label clicks)
    fontSize: 11,
    centerX: am5.p50,
    centerY: am5.p50,
    oversizedBehavior: "truncate",
    text: "{name}"
  });

  // --- Helpers ---------------------------------------------------------------

  function isBad(name) {
    return !name || BAD_NAMES.has(String(name).trim().toLowerCase());
  }

  // Deduplicate edges, remove Unknown/TBD, filter Suite
  function cleanAndDedupe(links, suite) {
    const seen = new Set();
    const out = [];
    for (const d of links) {
      const s = (d.from || "").trim();
      const t = (d.to || "").trim();
      const w = Number(d.value || 1);
      const su = (d.suite || "").trim();

      if (suite && suite !== "Both" && su.toUpperCase() !== suite.toUpperCase()) continue;
      if (isBad(s) || isBad(t)) continue;

      const key = `${s}__${t}__${su}`;     // dedupe (do NOT sum)
      if (seen.has(key)) continue;
      seen.add(key);

      out.push({ from: s, to: t, suite: su, value: isFinite(w) ? w : 1 });
    }
    return out;
  }

  function buildGraph(links) {
    const nodeStats = new Map(); // name -> {incomingWeight, outgoingWeight}
    const edges = [];

    for (const e of links) {
      const { from, to, value } = e;
      if (!nodeStats.has(from)) nodeStats.set(from, { name: from, incomingWeight: 0, outgoingWeight: 0 });
      if (!nodeStats.has(to))   nodeStats.set(to,   { name: to,   incomingWeight: 0, outgoingWeight: 0 });

      nodeStats.get(from).outgoingWeight += value;
      nodeStats.get(to).incomingWeight   += value;

      edges.push({ source: from, target: to, value });
    }

    const children = Array.from(nodeStats.values()).map(n => ({
      name: n.name,
      incomingWeight: n.incomingWeight,
      outgoingWeight: n.outgoingWeight,
      value: n.incomingWeight + n.outgoingWeight
    }));

    return { rootData: { name: "Applications", children }, edges };
  }

  // Build neighbor map for click-highlighting
  function buildNeighborMap(edges) {
    const nbr = new Map();
    function add(a, b) { if (!nbr.has(a)) nbr.set(a, new Set()); nbr.get(a).add(b); }
    edges.forEach(e => { add(e.source, e.target); add(e.target, e.source); });
    return nbr;
  }

  // Create links after nodes exist
  function linkAfterValidate(edges) {
    const index = new Map();
    series.dataItems.forEach(di => {
      const ctx = di.dataContext;
      if (ctx && ctx.name && ctx.name !== "Applications") index.set(ctx.name, di);
    });

    // Remove old links
    series.links.each(l => l.dispose());

    for (const e of edges) {
      const a = index.get(e.source);
      const b = index.get(e.target);
      if (a && b) {
        const link = series.linkDataItems(a, b);
        link.setAll({
          tooltipText: `${e.source} → ${e.target}${e.value ? ` (w=${e.value})` : ""}`,
          strokeOpacity: 0.35
        });
      }
    }

    series.setPrivate("neighborMap", buildNeighborMap(edges));
  }

  // Two thin rings: Inner = Incoming (blue), Outer = Outgoing (green)
  function ensureRings(nodeContainer, di) {
    const ctx = di?.dataContext || {};
    if (!ctx || ctx.name === "Applications") return;

    // Guard: if percent module missing, log once and bail
    if (typeof am5percent === "undefined" || !am5percent.PieChart) {
      if (!root.getPrivate("percentWarned")) {
        console.warn("amCharts 5 percent.js not loaded; ring overlays disabled");
        root.setPrivate("percentWarned", true);
      }
      return;
    }

    let pie = nodeContainer.getPrivate("pieChart");
    if (!pie) {
      pie = nodeContainer.children.push(
        am5percent.PieChart.new(root, { centerX: am5.p50, centerY: am5.p50 })
      );
      nodeContainer.setPrivate("pieChart", pie);

      const inner = pie.series.push(
        am5percent.PieSeries.new(root, {
          valueField: "value",
          categoryField: "category",
          alignLabels: false
        })
      );
      inner.setAll({ innerRadius: am5.percent(66), radius: am5.percent(74) });
      inner.get("colors").set("colors", [COLORS.incoming, COLORS.rest]);
      inner.slices.template.setAll({ strokeOpacity: 0, tooltipText: "{category}: {value}" });

      const outer = pie.series.push(
        am5percent.PieSeries.new(root, {
          valueField: "value",
          categoryField: "category",
          alignLabels: false
        })
      );
      outer.setAll({ innerRadius: am5.percent(78), radius: am5.percent(86) });
      outer.get("colors").set("colors", [COLORS.outgoing, COLORS.rest]);
      outer.slices.template.setAll({ strokeOpacity: 0, tooltipText: "{category}: {value}" });

      nodeContainer.setPrivate("ringInner", inner);
      nodeContainer.setPrivate("ringOuter", outer);
    }

    const inner = nodeContainer.getPrivate("ringInner");
    const outer = nodeContainer.getPrivate("ringOuter");

    const incoming = Number(ctx.incomingWeight || 0);
    const outgoing = Number(ctx.outgoingWeight || 0);
    const total    = Math.max(incoming + outgoing, 0.0001);

    inner.data.setAll([
      { category: "Incoming", value: incoming },
      { category: "_rest",    value: Math.max(total - incoming, 0) }
    ]);
    outer.data.setAll([
      { category: "Outgoing", value: outgoing },
      { category: "_rest",    value: Math.max(total - outgoing, 0) }
    ]);

    // Size ring to node circle
    const r = di.get("circle") ? di.get("circle").get("radius") : 30;
    nodeContainer.getPrivate("pieChart").setAll({ width: r * 2, height: r * 2 });
  }

  // Build rings for ALL nodes after data is ready; keep them synced on resize
  function rebuildRingsForAllNodes() {
    series.nodes.each(node => {
      const di = node.dataItem;
      if (di) ensureRings(node, di);
    });
  }

  // --- Click-to-focus --------------------------------------------------------
  let focusedDI = null;

  function resetFocus() {
    focusedDI = null;
    series.nodes.each(node => {
      node.setAll({ fillOpacity: 1 });
      node.children.each(ch => ch.setAll({ opacity: 1 }));
    });
    series.links.each(link => link.setAll({ strokeOpacity: 0.35 }));
  }

  function handleNodeClick(di) {
    const ctx = di?.dataContext;
    if (!ctx || ctx.name === "Applications") return;

    if (focusedDI === di) { resetFocus(); return; }
    focusedDI = di;

    const name = ctx.name;
    const nbr = series.getPrivate("neighborMap") || new Map();
    const neighbors = nbr.get(name) || new Set();

    series.nodes.each(node => {
      const n = node.dataItem?.dataContext?.name;
      const isFocus = n === name || neighbors.has(n);
      node.setAll({ fillOpacity: isFocus ? 1 : 0.15 });
      node.children.each(ch => ch.setAll({ opacity: isFocus ? 1 : 0.15 }));
    });

    series.links.each(link => {
      const s = link.get("source")?.dataItem?.dataContext?.name;
      const t = link.get("target")?.dataItem?.dataContext?.name;
      const show = s === name || t === name || neighbors.has(s) || neighbors.has(t);
      link.setAll({ strokeOpacity: show ? 0.7 : 0.05 });
    });
  }

  // Click on circles or labels
  series.circles.template.events.on("click", ev => handleNodeClick(ev.target.dataItem));
  series.labels.template.events.on("click",  ev => handleNodeClick(ev.target.dataItem));

  // Click background to reset
  root.container.events.on("click", ev => { if (ev.target === root.container) resetFocus(); });

  // 4) Filtering (Suite dropdown). Use a persistent handler so we don't miss the event.
  let lastEdges = [];
  series.events.on("datavalidated", () => {
    // Build links and neighbors once nodes are created
    linkAfterValidate(lastEdges);
    // Build rings for all nodes now that they exist
    rebuildRingsForAllNodes();
  });

  function applyFilter(suite) {
    const links = cleanAndDedupe(rawLinks, suite);
    const { rootData, edges } = buildGraph(links);
    lastEdges = edges;                    // keep for datavalidated handler

    series.data.setAll([rootData]);
  }

  // 5) Initial load (Both) + dropdown wire-up
  applyFilter("Both");
  series.appear(800, 100);

  const sel = document.getElementById("suiteFilter");
  if (sel) {
    sel.addEventListener("change", function () {
      resetFocus();
      applyFilter(sel.value);
    });
  }

  // Keep rings synced on size/layout changes
  series.nodes.events.on("boundschanged", ev => {
    const di = ev.target.dataItem;
    if (di) ensureRings(ev.target, di);
  });

  window.addEventListener("resize", () => root.resize());

  // --- Quick sanity logs (you can remove later) ------------------------------
  console.log("rawLinks:", rawLinks.length, "records");
  if (typeof am5percent === "undefined") {
    console.warn("am5percent is undefined — check that https://cdn.amcharts.com/lib/5/percent.js is reachable.");
  }
});
</script>

<!-- HTML -->
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Decommission Analyzer - Dependency Chart</title>
    <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/custom-style.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

    <style>
    #chartDiv,
    #chartdiv {
        height: 575px;
    }

    #balloon {
        position: absolute;
        top: 359px;
        left: 867px;
        border: 2px solid #ccc;
        background: rgba(255, 255, 255, 0.8);
        padding: 6px;
        font-size: 10px;
        color: #000;
        margin: 40px 0 0 20px;
    }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include './pages/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include './pages/navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dependency Chart</h1>
                    </div>

                    <!-- Content Row -->



                    <div class="row">
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Dependency Chart for all apps.
                                    </h6> <!-- Suite Filter -->
                                    <div class="d-flex align-items-center">
                                        <label for="suiteFilter" class="mr-2 mb-0 text-muted"
                                            style="font-size:0.9rem;">Suite</label>
                                        <select id="suiteFilter" class="form-control form-control-sm">
                                            <option value="Both" selected>Both</option>
                                            <option value="HV">HV</option>
                                            <option value="PCIO">PCIO</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <div id="chartDiv" class="chart-area">
                                        <div id="chartdiv"></div>
                                        <div id="balloon"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <!-- Area Chart -->
                            <div class="col-xl-6 col-lg-6">
                                <div class="card shadow mb-4">
                                    <!-- Card Header - Dropdown -->
                                    <div
                                        class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                        <h6 class="m-0 font-weight-bold text-primary">Incoming Interfaces
                                        </h6>

                                    </div>
                                    <!-- Card Body -->

                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-striped" id="incomingTable"
                                                width="100%" cellspacing="0">
                                                <thead>
                                                    <tr>
                                                        <th>App ID</th>
                                                        <th>App Name</th>
                                                        <th>Interface Type</th>
                                                        <th>Target App</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php if (!empty($incomingRows)): ?>
                                                    <?php foreach ($incomingRows as $r): ?>
                                                    <tr>
                                                        <td><?= htmlspecialchars($r['id'], ENT_QUOTES, 'UTF-8') ?></td>
                                                        <td><?= htmlspecialchars($r['name'], ENT_QUOTES, 'UTF-8') ?>
                                                        </td>
                                                        <td><?= htmlspecialchars($r['type'], ENT_QUOTES, 'UTF-8') ?>
                                                        </td>
                                                        <td><?= htmlspecialchars($r['targetName'], ENT_QUOTES, 'UTF-8') ?>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                    <?php else: ?>
                                                    <tr>
                                                        <td colspan="4" class="text-center text-muted">No incoming
                                                            interfaces found.</td>
                                                    </tr>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>


                                </div>
                            </div>
                            <!-- Area Chart -->
                            <div class="col-xl-6 col-lg-6">
                                <div class="card shadow mb-4">
                                    <!-- Card Header - Dropdown -->
                                    <div
                                        class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                        <h6 class="m-0 font-weight-bold text-primary">Outgoing Interfaces
                                        </h6>

                                    </div>
                                    <!-- Card Body -->

                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-striped" id="outgoingTable" width="100%" cellspacing="0">
                                                <thead>
                                                    <tr>
                                                        <th>App ID</th>
                                                        <th>App Name</th>
                                                        <th>Interface Type</th>
                                                        <th>Target App</th>
                                                    </tr>
                                                </thead>
                                               <tbody>
    <?php if (!empty($outgoingRows)): ?>
      <?php foreach ($outgoingRows as $r): ?>
        <tr>
          <td><?= htmlspecialchars($r['id'], ENT_QUOTES, 'UTF-8') ?></td>
          <td><?= htmlspecialchars($r['name'], ENT_QUOTES, 'UTF-8') ?></td>
          <td><?= htmlspecialchars($r['type'], ENT_QUOTES, 'UTF-8') ?></td>
          <td><?= htmlspecialchars($r['targetName'], ENT_QUOTES, 'UTF-8') ?></td>
        </tr>
      <?php endforeach; ?>
    <?php else: ?>
      <tr>
        <td colspan="4" class="text-center text-muted">No outgoing interfaces found.</td>
      </tr>
    <?php endif; ?>
  </tbody>
                                            </table>
                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
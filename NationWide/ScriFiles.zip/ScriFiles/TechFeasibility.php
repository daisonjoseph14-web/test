<?php
error_reporting(E_ALL);
//require_once './pages/auth/pageHandler.php';
//session_start();
$_SESSION['currentPage'] = 'technologyfeasibility';

require_once 'global.php';
array_multisort(array_column($chart_data, 'riskcriticalityscore'), SORT_DESC, $chart_data);
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Decommission Analyzer - Technical Feasibility</title>
    <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/custom-style.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

    <style>
        /* Chart wrappers */
#chartDiv,
#chartdiv {
  height: 1400px;               /* your existing height */
}

/* Make the container positioned so absolute children use it as the origin */
#chartDiv {
  position: relative;
}

/* Floating HTML tooltip that follows the mouse */
#balloon {
  position: absolute;           /* relative to #chartDiv */
  display: none;                /* hidden by default */
  pointer-events: none;         /* don’t block mouseover on bars */
  border: 1px solid #ddd;
  background: rgba(255,255,255,.95);
  padding: 8px 10px;
  font-size: 12px;
  color: #000;
  border-radius: 4px;
  box-shadow: 0 1px 8px rgba(0,0,0,.08);
  z-index: 9999;
  /* IMPORTANT: remove any hard-coded top/left you had earlier */
}

    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include './pages/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include './pages/navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Risk & Criticality Metrics by Applications</h1>
                    </div>

                    <!-- Content Row -->
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4 pop">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Applications</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?php echo $totalApplications; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fab fa-elementor fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4 pop" data-toggle="tooltip" data-placement="top" title="Index greater than 0.8">
                            <div class="card border-left-danger shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                                High Risk Applications</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?php echo $highRisk; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-sort-amount-up fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Pending Requests Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4 pop" data-toggle="tooltip" data-placement="top" title="Index between 0.4 and 0.8">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Medium Risk Applications</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?php echo $mediumRisk; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-random fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-4 pop" data-toggle="tooltip" data-placement="top" title="Index lesser than 0.4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Low Risk Applications</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?php echo $lowRisk; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-sort-amount-down-alt fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Application With Risk / Criticality
                                    </h6>
                                    <!-- LOB Select Dropdown -->
                                    <!--   <div class="dropdown no-arrow">
                                        <!-- <select class="form-control" name="lob" id="selLob">
                                            <option selected disabled>Choose LOB</option>
                                            <?php
                                            //sort($lobs);
                                           // foreach ($lobs as $lob) {
                                             //   if ($lob == "") continue;
                                            //?>
                                                <option><?php //echo $lob; ?></option>
                                            <?php
                                            //}
                                            ?>
                                        </select> 
                                    </div>-->
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <div id="chartDiv" class="chart-area">
                                        <div id="chartdiv"></div>
                                        <div id="balloon"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Risk and Criticality Index Table</h6>

                                </div>
                                <!-- Card Body -->
                                
<div class="card-body">
    <div class="table-responsive">
        <table class="table table-bordered table-striped" id="riskAndCriticalityTable" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th>App ID</th>
                    <th>App Name</th>
                    <th>Risk & Criticality Index</th>
                    <th>App Revenue Impact</th>
                    <th>App Criticality</th>
                    <th>App Data Gateway Value</th>
                </tr>
            </thead>
            <tbody>
                <?php
               

                foreach ($chart_data as $doc) {
                    $appid = htmlspecialchars($doc['application_id'] ?? '', ENT_QUOTES, 'UTF-8');
                    $buisness_name = htmlspecialchars($doc['application_name'] ?? '', ENT_QUOTES, 'UTF-8');
                    // Safely read values; default to empty string if missing
                    $revImpact = htmlspecialchars($doc['apprevenueimpact'] ?? '', ENT_QUOTES, 'UTF-8');
                    // Your field list shows "Appcriticality" (capital A). Use that, fallback to lowercase if needed.
                    $criticality = htmlspecialchars($doc['Appcriticality'] ?? ($doc['appcriticality'] ?? ''), ENT_QUOTES, 'UTF-8');
                    $dataGateway = htmlspecialchars($doc['appdatagatewayvalue'] ?? '', ENT_QUOTES, 'UTF-8');

                    echo '<tr>'; 
                    echo '<td>' . $appid . '</td>';
                    echo '<td>' . $buisness_name . '</td>';
echo '<td>' . htmlspecialchars($doc['riskcriticalityscore'] ?? '', ENT_QUOTES, 'UTF-8') . '</td>';
                    echo '<td>' . $revImpact . '</td>';
                    echo '<td>' . $criticality . '</td>';
                    echo '<td>' . $dataGateway . '</td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
``

                            </div>
                        </div>

                    </div>



                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include './pages/footer.php'; ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

    </div>
    <!-- End of Page Wrapper -->

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

    <!-- Buttons Scripts -->
    <script src="js/dataTables.buttons.min.js"></script>
    <script src="js/buttons.flash.min.js"></script>
    <script src="js/buttons.html5.min.js"></script>
    <script src="js/buttons.print.min.js"></script>

    <!-- Resources -->
    <script src="js/3/amcharts.js"></script>
    <script src="js/3/serial.js"></script>
    <script src="js/3/export.min.js"></script>
    <link rel="stylesheet" href="css/3/export.css" type="text/css" media="all" />
    <script src="js/3/light.js"></script>

    <script type="text/javascript" src="js/3/loader.js"></script>

    <!-- Chart code -->
    <script>
        function initializeChart() {
            var dataProvider = chart.dataProvider;
            var colorRanges = chart.colorRanges;

            // Based on https://www.sitepoint.com/javascript-generate-lighter-darker-color/
            function ColorLuminance(hex, lum) {

                // validate hex string
                hex = String(hex).replace(/[^0-9a-f]/gi, '');
                if (hex.length < 6) {
                    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
                }
                lum = lum || 0;

                // convert to decimal and change luminosity
                var rgb = "#",
                    c, i;
                for (i = 0; i < 3; i++) {
                    c = parseInt(hex.substr(i * 2, 2), 16);
                    c = Math.round(Math.min(Math.max(0, c + (c * lum)), 255)).toString(16);
                    rgb += ("00" + c).substr(c.length);
                }

                return rgb;
            }

            if (colorRanges) {

                var item;
                var range;
                var valueProperty;
                var value;
                var average;
                var variation;
                for (var i = 0, iLen = dataProvider.length; i < iLen; i++) {

                    item = dataProvider[i];

                    for (var x = 0, xLen = colorRanges.length; x < xLen; x++) {

                        range = colorRanges[x];
                        valueProperty = range.valueProperty;
                        value = item[valueProperty];

                        if (value >= range.start && value <= range.end) {
                            average = (range.start - range.end) / 2;

                            if (value <= average)
                                variation = (range.variation * -1) / value * average;
                            else if (value > average)
                                variation = range.variation / value * average;

                            item[range.colorProperty] = ColorLuminance(range.color, variation.toFixed(2));
                        }
                    }
                }
            }
        }
        AmCharts.addInitHandler(function(chart) {
            initializeChart();

        }, ["serial"]);



        var chart = AmCharts.makeChart("chartdiv", {
            "hideCredits": true,
            "type": "serial",
            "theme": "light",
            "colorRanges": [{
                "start": 0,
                "end": 0.4,
                "color": "#1CC88A",
                "variation": 0,
                "valueProperty": "Risk Criticality Index",
                "colorProperty": "color"
            }, {
                "start": 0.4,
                "end": 0.8,
                "color": "#F6C23E",
                "variation": 0,
                "valueProperty": "Risk Criticality Index",
                "colorProperty": "color"
            }, {
                "start": 0.8,
                "end": 1,
                "color": "#E74A3B",
                "variation": 0,
                "valueProperty": "Risk Criticality Index",
                "colorProperty": "color"
            }],

            "dataProvider": [
                <?php
               
                foreach ($chart_data as $result) {
                    echo "{";
                    echo '"Application":"' . $result["App"] . '",';
                    echo '"Risk Criticality Index":' . $result["riskcriticalityscore"] . ',';
                    echo '"App Revenue Impact":"' . $result["apprevenueimpact"] . '",';
                    echo '"App Criticality":"' . $result["Appcriticality"] . '",';
                    echo '"App Data Gateway":"' . $result["appdatagatewayvalue"] . '",';
                    echo '"App Legal":"' . $result["applegalvalue"] . '",';
                    echo '"App interface":"' . $result["appinterface"] . '"';
                    echo "},";
                }
                ?>
            ],

            "valueAxes": [{
                "gridColor": "#FFFFFF",
                "gridAlpha": 0.2,
                "dashLength": 0,
                "title": "Risk Criticality Index",
                "position": "top"
            }],
            "gridAboveGraphs": true,
            "startDuration": 1,
            "graphs": [{
                // "balloonText": "[[Application]]:<br/>Risk Criticality Index:[[Risk Criticality Index]]<br/>Cyclomatic Complexity:[[cyclomatic]]<br/>Maintainability Index:[[maintainabilityindex]]<br/>Application Size:[[appsizevalue]]<br/>Outbound Interfaces:[[outbound]]<br/>Inbound Interfaces:[[inbound]]<br/>Application Criticality:[[appcriticality]]<br/>Language Comlexity:[[languagecomplexityscore]]<br/>Stability:[[Stability]]<br/> ",
                "labelText": "[[Risk Criticality Index]]",
                "fillAlphas": 0.8,
                "lineAlpha": 0.2,
                "type": "column",
                "valueField": "Risk Criticality Index",
                "colorField": "color",
                "balloon": {
                    "adjustBorderColor": true,
                    "color": "#000000",
                    "cornerRadius": 5,
                    "fillColor": "#FFFFFF",
                    "fillAlpha": 20
                }
            }],
            "chartCursor": {
                "categoryBalloonEnabled": true,
                "cursorAlpha": 0,
                "zoomable": false
            },
            "categoryField": "Application",
            "rotate": true,
            "categoryAxis": {
                "gridPosition": "start",
                "labelRotation": 25,
                "gridAlpha": 0,
                "title": "Applications",
                "fontSize": 8
            }
            // ,
            // "export": {
            //     "enabled": true,
            //     "fileName": "portability_metrics"
            // }

        });
        <?php
       // print_r($uniquelobs);
        $lobSet = array();
        $dataSet = array();

        foreach ($lobs as $lob) {
            foreach ($dataByLob[$lob] as $data) {
                $data["application_name"] = str_replace("'", "", $data["application_name"]);
                $dataSet[] = array(
                    "Application" => $data["application_name"],
                    "Risk Criticality Index" => $data["riskcriticalityscore"],
                    "App Revenue Impact" => $data["apprevenueimpact"],
                    "App Criticality" => $data["Appcriticality"],
                    "App Data Gateway" => $data["appdatagatewayvalue"],
                    "App Legal" => $data["applegalvalue"],
                    "App Interface" => $data["appinterface"]
                );
            }
            $lobSet[] = array($lob => $dataSet);
            $dataSet = array();
        }
        ?>

        var lobData = '<?php echo json_encode($lobSet); ?>';
        lobData = JSON.parse(lobData);
        console.log(lobData);

        var lob = $("#selLob").prop("selectedIndex", 0).val();
        $('#selLob').change(function() {
            lob = $("#selLob").val();
            // console.log(lob);
            $.each(lobData, function() {
                $.each(this, function(k, v) {
                    if (k == lob) {
                        chart.dataProvider = v;
                        initializeChart();
                        chart.validateData();
                        // $('#chartDiv').height(chart.dataProvider.length * 150);
                        // $('#chartdiv').height(chart.dataProvider.length * 150);
                        console.log(chart.dataProvider);
                        return;
                    }

                });
            });
        });

  // ... your existing chart creation code above ...

  var chartDiv   = document.getElementById("chartDiv");
  var balloonEl  = document.getElementById("balloon");
  var MARGIN_X   = 14;   // small offset from the cursor
  var MARGIN_Y   = 14;

  function showBalloonAtContainer(x, y) {
    balloonEl.style.left = (x + MARGIN_X) + "px";
    balloonEl.style.top  = (y + MARGIN_Y) + "px";
    balloonEl.style.display = "block";
  }

  function hideBalloon() {
    balloonEl.style.display = "none";
  }

  // Build the HTML once on roll over; position using container-relative coords
  chart.addListener("rollOverGraphItem", function (event) {
    var d = event.item.dataContext;

    balloonEl.innerHTML =
      "Application: <b>" + d["Application"] + "</b><br>" +
      "Risk Criticality Index: <b>" + d["Risk Criticality Index"] + "</b><br>" +
      "App Revenue Impact: <b>" + d["App Revenue Impact"] + "</b><br>" +
      "App Criticality: <b>" + d["App Criticality"] + "</b><br>" +
      "App Data Gateway: <b>" + d["App Data Gateway"] + "</b><br>" +
      "App Legal: <b>" + d["App Legal"] + "</b><br>" +
      "App Interface: <b>" + d["App Interface"] + "</b>";

    // event.x / event.y are relative to the chart container in v3 serial charts
    var x = (typeof event.x === "number") ? event.x : 0;
    var y = (typeof event.y === "number") ? event.y : 0;

    showBalloonAtContainer(x, y);
  });

  // Keep following the mouse while staying inside the same container
  chartDiv.addEventListener("mousemove", function (e) {
    if (balloonEl.style.display === "block") {
      var rect = chartDiv.getBoundingClientRect();
      var relX = e.clientX - rect.left;
      var relY = e.clientY - rect.top;
      showBalloonAtContainer(relX, relY);
    }
  });

  // Hide on roll out (leaving a bar) and when cursor leaves the chart area
  chart.addListener("rollOutGraphItem", function () {
    hideBalloon();
  });
  chartDiv.addEventListener("mouseleave", hideBalloon);
</script>

</body>



</html>
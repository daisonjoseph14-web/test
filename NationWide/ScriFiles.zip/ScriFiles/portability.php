<?php
error_reporting(E_ALL);
// session_start(); // (re-enable if you need it)
$_SESSION['currentPage'] = 'portabilityMetrics';

require '/var/www/html/vendor/autoload.php';

$m  = new MongoDB\Client("mongodb://127.0.0.1/");
$db = $m->nationWide;
$collection = $db->Portability;

$totalApplications = 0;
$lowPortable = 0;
$mediumPortable = 0;
$highPortable = 0;

/**
 * 1) Pull documents already sorted by the portability score you want to plot.
 *    -1 => DESC (highest at the top of your rotated bar chart)
 *    Swap 'portabilityindex' with 'portabilityindex_v2' if you prefer the normalized scale 0.10–1.00.
 */
$cursor = $collection->find([], [
    'sort' => [ 'portabilityindex' => -1 ]
]);

$chart_data = [];

foreach ($cursor as $doc) {
    $totalApplications++;

    $appName = isset($doc['Application Name']) ? (string)$doc['Application Name'] : '(Unknown)';
    $pi = isset($doc['portabilityindex']) ? (float)$doc['portabilityindex']
         : (isset($doc['portabilityindex_v2']) ? (float)$doc['portabilityindex_v2'] : 0.0);

    $cyclo   = isset($doc['cyclomaticcomplexity'])    ? (float)$doc['cyclomaticcomplexity']    : 0.0;
    $mi      = isset($doc['maintainabilityindex'])    ? (float)$doc['maintainabilityindex']    : 0.0;
    $iface   = isset($doc['interfaces_score'])        ? (float)$doc['interfaces_score']        : 0.0;
    $lang    = isset($doc['languagecomplexityscore']) ? (float)$doc['languagecomplexityscore'] : 0.0;
    $sizev   = isset($doc['appsizevalue'])            ? (float)$doc['appsizevalue']            : 0.0;
    $out     = isset($doc['outbound_total'])          ? (int)$doc['outbound_total']            : 0;
    $in      = isset($doc['inbound_total'])           ? (int)$doc['inbound_total']             : 0;
    $crit    = isset($doc['appcriticality(1-5)'])     ? (float)$doc['appcriticality(1-5)']     : 0.0;
    $stab    = isset($doc['appstability'])            ? (float)$doc['appstability']            : 0.0;
$color = '#F6C23E'; // default orange
if ($pi >= 0.8) {
    $color = '#1CC88A'; // green
} elseif ($pi < 0.4) {
    $color = '#E74A3B'; // red
}
    // Chart record (in sorted order already)
    $chart_data[] = [
        "Application"              => str_replace("'", "", $appName),
        "Portability Index"        => round($pi, 4),
        "technical"                => round($cyclo, 2),
        "maintainabilityindex"     => round($mi, 2),
        "interfaces_score"         => round($iface, 2),
        "languagecomplexityscore"  => round($lang, 2),
        "appsizevalue"             => round($sizev, 2),
        "outbound"                 => $out,
        "inbound"                  => $in,
        "appcriticality"           => round($crit, 2),
        "Stability"                => round($stab, 2),
         "color"                    => $color,
    ];

    // Cards
    if ($pi > 0.8)      $highPortable++;
    elseif ($pi < 0.4)  $lowPortable++;
    else                $mediumPortable++;
}
?>
<?php
$pipeline = [
    [
        '$project' => [
            // safely convert portability index to number
            'pi' => [
                '$convert' => [
                    'input' => '$portabilityindex',
                    'to' => 'double',
                    'onError' => 0,
                    'onNull' => 0
                ]
            ]
        ]
    ],
    [
        '$group' => [
            '_id' => null,
            'highRisk' => [
                '$sum' => [
                    '$cond' => [
                        [ '$gte' => [ '$pi', 0.8 ] ], 1, 0
                    ]
                ]
            ],
            'mediumRisk' => [
                '$sum' => [
                    '$cond' => [
                        [
                            '$and' => [
                                [ '$gte' => [ '$pi', 0.4 ] ],
                                [ '$lt'  => [ '$pi', 0.8 ] ]
                            ]
                        ],
                        1,
                        0
                    ]
                ]
            ],
            'lowRisk' => [
                '$sum' => [
                    '$cond' => [
                        [ '$lt' => [ '$pi', 0.4 ] ], 1, 0
                    ]
                ]
            ],
            'total' => [ '$sum' => 1 ]
        ]
    ]
];

$result = $collection->aggregate($pipeline)->toArray()[0];

$highRisk          = (int)$result['highRisk'];
$mediumRisk        = (int)$result['mediumRisk'];
$lowRisk           = (int)$result['lowRisk'];
$totalApplications = (int)$result['total'];
?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Decommission Analyzer - Portability Matrix</title>
    <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/custom-style.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

    <style>
        /* Chart wrappers */
#chartDiv,
#chartdiv {
  height: 1400px;               /* your existing height */
}

/* Make the container positioned so absolute children use it as the origin */
#chartDiv {
  position: relative;
}

/* Floating HTML tooltip that follows the mouse */
#balloon {
  position: absolute;           /* relative to #chartDiv */
  display: none;                /* hidden by default */
  pointer-events: none;         /* don’t block mouseover on bars */
  border: 1px solid #ddd;
  background: rgba(255,255,255,.95);
  padding: 8px 10px;
  font-size: 12px;
  color: #000;
  border-radius: 4px;
  box-shadow: 0 1px 8px rgba(0,0,0,.08);
  z-index: 9999;
  /* IMPORTANT: remove any hard-coded top/left you had earlier */
}

    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include './pages/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include './pages/navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Portability Metrics by Applications</h1>
                    </div>

                    <!-- Content Row -->
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4 pop">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Applications</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?php echo $totalApplications; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fab fa-elementor fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4 pop" data-toggle="tooltip" data-placement="top" title="Index greater than 0.8">
                            <div class="card border-left-danger shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                High Portable Applications</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?php echo $highRisk; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-sort-amount-up fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Pending Requests Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4 pop" data-toggle="tooltip" data-placement="top" title="Index between 0.4 and 0.8">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Medium Risk Applications</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?php echo $mediumRisk; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-random fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-4 pop" data-toggle="tooltip" data-placement="top" title="Index lesser than 0.4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                                Low Portable Applications</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <?php echo $lowRisk; ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-sort-amount-down-alt fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Application With Portability Index
                                    </h6>
                                    <!-- LOB Select Dropdown -->
                                    <!--   <div class="dropdown no-arrow">
                                        <select class="form-control" name="lob" id="selLob">
                                            <option selected disabled>Choose LOB</option>
                                            <?php
                                            //sort($lobs);
                                           // foreach ($lobs as $lob) {
                                             //   if ($lob == "") continue;
                                            //?>
                                                <option><?php //echo $lob; ?></option>
                                            <?php
                                            //}
                                            ?>
                                        </select> 
                                    </div>-->
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <div id="chartDiv" class="chart-area">
                                        <div id="chartdiv"></div>
                                        <div id="balloon"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Risk and Criticality Index Table</h6>

                                </div>
                                <!-- Card Body -->
                                
<div class="card-body">
    <div class="table-responsive">
        <table class="table table-bordered table-striped" id="riskAndCriticalityTable" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th>App ID</th>
                    <th>App Name</th>
                    <th>Risk & Criticality Index</th>
                    <th>App Revenue Impact</th>
                    <th>App Criticality</th>
                    <th>App Data Gateway Value</th>
                </tr>
            </thead>
            <tbody>
                <?php
               

                foreach ($chart_data as $doc) {
                    $appid = htmlspecialchars($doc['application_id'] ?? '', ENT_QUOTES, 'UTF-8');
                    $buisness_name = htmlspecialchars($doc['application_name'] ?? '', ENT_QUOTES, 'UTF-8');
                    // Safely read values; default to empty string if missing
                    $revImpact = htmlspecialchars($doc['apprevenueimpact'] ?? '', ENT_QUOTES, 'UTF-8');
                    // Your field list shows "Appcriticality" (capital A). Use that, fallback to lowercase if needed.
                    $criticality = htmlspecialchars($doc['Appcriticality'] ?? ($doc['appcriticality'] ?? ''), ENT_QUOTES, 'UTF-8');
                    $dataGateway = htmlspecialchars($doc['appdatagatewayvalue'] ?? '', ENT_QUOTES, 'UTF-8');

                    echo '<tr>'; 
                    echo '<td>' . $appid . '</td>';
                    echo '<td>' . $buisness_name . '</td>';
echo '<td>' . htmlspecialchars($doc['riskcriticalityscore'] ?? '', ENT_QUOTES, 'UTF-8') . '</td>';
                    echo '<td>' . $revImpact . '</td>';
                    echo '<td>' . $criticality . '</td>';
                    echo '<td>' . $dataGateway . '</td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
``

                            </div>
                        </div>

                    </div>



                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include './pages/footer.php'; ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

    </div>
    <!-- End of Page Wrapper -->

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

    <!-- Buttons Scripts -->
    <script src="js/dataTables.buttons.min.js"></script>
    <script src="js/buttons.flash.min.js"></script>
    <script src="js/buttons.html5.min.js"></script>
    <script src="js/buttons.print.min.js"></script>

    <!-- Resources -->
    <script src="js/3/amcharts.js"></script>
    <script src="js/3/serial.js"></script>
    <script src="js/3/export.min.js"></script>
    <link rel="stylesheet" href="css/3/export.css" type="text/css" media="all" />
    <script src="js/3/light.js"></script>

    <script type="text/javascript" src="js/3/loader.js"></script>

    <!-- Chart code -->
    <script>
  // Build the dataProvider once from PHP (already sorted)
  var chartData = [
    <?php
    $last = count($chart_data) - 1;
    $i = 0;
    foreach ($chart_data as $row) {
        echo '{';
        echo '"Application":"'             . addslashes($row["Application"]) . '",';
        echo '"Portability Index":'       . $row["Portability Index"] . ',';
        echo '"technical":'               . $row["technical"] . ',';
        echo '"maintainabilityindex":'    . $row["maintainabilityindex"] . ',';
        echo '"interfaces_score":'        . $row["interfaces_score"] . ',';
        echo '"languagecomplexityscore":' . $row["languagecomplexityscore"] . ',';
        echo '"appsizevalue":'            . $row["appsizevalue"] . ',';
        echo '"outbound":'                . $row["outbound"] . ',';
        echo '"inbound":'                 . $row["inbound"] . ',';
        echo '"appcriticality":'          . $row["appcriticality"] . ',';
        echo '"Stability":'               . $row["Stability"] . ',';
           echo '"color":"'                  . $row["color"] . '"';
        echo '}';
        if ($i !== $last) echo ',';
        $i++;
    }
    ?>
  ];

  // Optional: If you ever need to sort client-side (you already sorted on server)
  // chartData.sort(function(a, b){ return (b["Portability Index"] || 0) - (a["Portability Index"] || 0); });

  // Make the chart once
  var chart = AmCharts.makeChart("chartdiv", {
    "hideCredits": true,
    "type": "serial",
    "theme": "light",
    "rotate": true,
    "dataProvider": chartData,
    "categoryField": "Application",

    "valueAxes": [{
      "title": "Portability Index",
      "gridAlpha": 0.2,
      "position": "top"
    }],

    "gridAboveGraphs": true,
    "startDuration": 1,

    "graphs": [{
      "type": "column",
      "valueField": "Portability Index",
      "labelText": "[[Portability Index]]",
      "fillAlphas": 0.8,
      "lineAlpha": 0.2,   
      "fillColorsField": "color",   // <- fills the column
    "lineColorField": "color",    // <- outlines the column (optional)
   
      "balloon": {
        "adjustBorderColor": true,
        "color": "#000000",
        "cornerRadius": 5,
        "fillColor": "#FFFFFF",
        "fillAlpha": 20
      }
    }],

    "categoryAxis": {
      "gridPosition": "start",
      "labelRotation": 25,
      "gridAlpha": 0,
      "title": "Applications",
      "fontSize": 8
    }
  });

  // === Your existing tooltip balloon behavior (unchanged) ===
  var chartDiv  = document.getElementById("chartDiv");
  var balloonEl = document.getElementById("balloon");
  var MARGIN_X  = 14, MARGIN_Y = 14;

  function showBalloonAtContainer(x, y) {
    balloonEl.style.left = (x + MARGIN_X) + "px";
    balloonEl.style.top  = (y + MARGIN_Y) + "px";
    balloonEl.style.display = "block";
  }
  function hideBalloon(){ balloonEl.style.display = "none"; }

  chart.addListener("rollOverGraphItem", function (event) {
    var d = event.item.dataContext;
    balloonEl.innerHTML =
        "Application: <b>" + d["Application"] + "</b><br>" +
        "Portability Index: <b>" + d["Portability Index"] + "</b><br>" +
        "Cyclomatic: <b>" + d["technical"] + "</b><br>" +
        "Maintainability: <b>" + d["maintainabilityindex"] + "</b><br>" +
        "Interfaces Score: <b>" + d["interfaces_score"] + "</b><br>" +
        "Language Complexity: <b>" + d["languagecomplexityscore"] + "</b><br>" +
        "App Size: <b>" + d["appsizevalue"] + "</b><br>" +
        "Outbound: <b>" + d["outbound"] + "</b><br>" +
        "Inbound: <b>" + d["inbound"] + "</b><br>" +
        "App Criticality: <b>" + d["appcriticality"] + "</b><br>" +
        "Stability: <b>" + d["Stability"] + "</b>";

    var x = (typeof event.x === "number") ? event.x : 0;
    var y = (typeof event.y === "number") ? event.y : 0;
    showBalloonAtContainer(x, y);
  });

  chart.addListener("rollOutGraphItem", function(){ hideBalloon(); });

  chartDiv.addEventListener("mouseleave", hideBalloon);
  chartDiv.addEventListener("mousemove", function(e){
    if (balloonEl.style.display === "block") {
      var rect = chartDiv.getBoundingClientRect();
      var relX = e.clientX - rect.left, relY = e.clientY - rect.top;
      showBalloonAtContainer(relX, relY);
    }
  });
</script>

</body>



</html>
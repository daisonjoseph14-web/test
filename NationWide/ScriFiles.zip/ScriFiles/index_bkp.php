<?php
error_reporting(E_ALL);
// ini_set('display_errors', TRUE);
// ini_set('display_startup_errors', TRUE);
require_once './pages/auth/pageHandler.php';

ob_start();
session_start();
// echo "Hello from PHP!";
$_SESSION['currentPage'] = 'dashboard';

// ini_set('display_errors',0);
require '/var/www/html/vendor/autoload.php';
$m = new MongoDB\Client("mongodb://localhost:27017");
//$m = new MongoClient();
$db = $m->nationWide;
$collection = $db->Questionnaire;
$lobs = $collection->distinct("line_of_business");
$totalcount = count($collection->find()->toArray());
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="karthick">

    <title>Decommission Analyzer - Dashboard</title>
    <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/custom-style.css" rel="stylesheet">
    <script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/percent.js"></script>
<script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
<script src="https://cdn.amcharts.com/lib/5/radar.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>

    <!-- Styles -->
    <style>
        #angularGauge,
        #pieChart,
        #actionPie,
        #appCriticality,
        #application_count,
        #smeChart,
        #application_pie,
        #appComplex,
        #targetPie {
            width: 100%;
            height: 100%;
        }

        .list-group-item:hover {
            transform: scale(1.02);
            cursor: default !important;
        }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include './pages/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include './pages/navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                    </div>

                    <!-- Content Row -->
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-6 col-md-12 mb-4 pop">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Lines Of Business Covered </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
											<?php echo count($lobs);?>
											</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-city fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-6 col-md-12 mb-4 pop">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Number of Applications ready for Analysis</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
											<?php echo $totalcount;?>
											</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-building fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">

                        <div class="col-lg-6 mb-4">
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Total No. Of Applications Per Line Of Buisness</h6>
                                </div>
                                <div class="card-body" style="height: 350px;overflow-x: hidden;">
								<?php
									// $colorcode = array("bg-danger","bg-warning","","bg-info","bg-success");
									// foreach($lobs as $distinct_lob)
									// {
									// 	$appcount = count($collection->find(array("LOB" => $distinct_lob))->toArray());
									// 	echo '<h4 class="small font-weight-bold">',$distinct_lob,'<span class="float-right">';
									// 	echo $appcount,'</span></h4>';
									// 	echo '<div class="progress mb-4">';
									// 	echo '<div class="progress-bar ',array_shift($colorcode),'" role="progressbar" style="width: ';
									// 	if(count($colorcode) == 0)
									// 		$colorcode = array("bg-danger","bg-warning","","bg-info","bg-success");
									// 	echo round(($appcount/$totalcount)*100),'%" ','aria-valuenow="',$appcount;
									// 	echo ' aria-valuemin="0" aria-valuemax="',$totalcount,'"></div></div>';
									// }
								?>
                                <div id="application_count"></div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-6 mb-4">
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Summary of Business Criticality</h6>
                                </div>
                                <div class="card-body" style="height: 350px;overflow-x: hidden;">
                                    <?php
                                      // $colorcode = array("bg-danger","bg-warning","","bg-info","bg-success");
                                      // foreach($lobs as $distinct_lob)
                                      // {
                                      // 	$appcount = count($collection->find(array("LOB" => $distinct_lob))->toArray());
                                      // 	echo '<h4 class="small font-weight-bold">',$distinct_lob,'<span class="float-right">';
                                      // 	echo $appcount,'</span></h4>';
                                      // 	echo '<div class="progress mb-4">';
                                      // 	echo '<div class="progress-bar ',array_shift($colorcode),'" role="progressbar" style="width: ';
                                      // 	if(count($colorcode) == 0)
                                      // 		$colorcode = array("bg-danger","bg-warning","","bg-info","bg-success");
                                      // 	echo round(($appcount/$totalcount)*100),'%" ','aria-valuenow="',$appcount;
                                      // 	echo ' aria-valuemin="0" aria-valuemax="',$totalcount,'"></div></div>';
                                      // }
                                    ?>
                                <div id="appCriticality"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Content Row -->

                    <div class="row">
						<div class="col-xl-6 col-lg-6">
								<div class="card shadow mb-4">
									<!-- Card Header -->
									<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
										<h6 class="m-0 font-weight-bold text-primary">Summary of Application Complexity</h6>
									</div>
									<!-- Card Body -->
									<div class="card-body">
										<!--div class="chart-area">
											<div id="appComplex"></div>
										</div-->
									</div>
								</div>
							</div>
							<div class="col-xl-6 col-lg-6">
                            <div class="card shadow mb-4">
                                <!-- Card Header -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Summary of Application Category</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <!--div class="chart-area">
                                        <div id="actionPie"></div>
                                    </div-->
                                </div>
                            </div>
                        </div>
                    </div>

                        <!-- Assumptions -->
                        <!-- <div class="col-xl-6 col-lg-6">
                            <div class="card shadow mb-4">
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Assumptions</h6>
                                </div>
                                <div class="card-body">
                                    <ul class="custom-white">
                                        <li>The current decommissioning sequence is based on
                                            inputs received from interviews in June 2020. Any major change to
                                            applications post the given interview ,will impact the decommissioning
                                            roadmap & plan accordingly.</li>
                                        <li>Sequence and Demise pattern for Applications
                                            which do not have source code are on basis of Inputs provided during
                                            interviews & dependencies information only</li>
                                        <li>Decommissioning sequence for certain applications
                                            with action to lead as "Decommission" needs discussion with Allianz
                                            Italy as the dependent applications either have action to lead as
                                            "Integrate" or "Remains”</li>
                                        <li>Action to Lead changed for 12 Applications</li>
                                    </ul>
                                </div>
                            </div>
                        </div> -->
                    

                    <div class="row">
                        <div class="col-xl-6 col-lg-6">
                            <div class="card shadow mb-4">
                                <!-- Card Header -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Overall Analysis Status</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <div class="chart-area">
                                        <div id="angularGauge"></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-6 col-lg-6">
                            <div class="card shadow mb-4">
                                <!-- Card Header -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Data Gathered from SME</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <div class="chart-area">
                                        <div id="smeChart"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">

                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Define Phase Highlights</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <!-- <div class="chart-area"> -->
                                    <div class="list-group">
                                        <button type="button" class="list-group-item list-group-item-action">
                                        Planning for data gethering & setting up the workshops
                                        </button>
                                        <button type="button" class="list-group-item list-group-item-action">
                                        Data gathering workshops with Application SMEs
                                    	</button>
                                        <button type="button" class="list-group-item list-group-item-action">Data
                                        Information gathered during workshop compiled & baselined as Inventory</button>
                                        <button type="button" class="list-group-item list-group-item-action">Analysis - Risk & Criticality, Portability, Point of Arrival, Dependency

                                        </button>
                                        <button type="button" class="list-group-item list-group-item-action">Derivation of decommission pattern, sequence </button>
                                        <button type="button" class="list-group-item list-group-item-action">Review & Feedback session with Customer stakeholders</button>
                                        <button type="button" class="list-group-item list-group-item-action">Decommission Roadmap presentation</button>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>



                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include './pages/footer.php'; ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

    <!-- Chart Scripts -->
    <script src="js/4/core.js"></script>
    <script src="js/4/charts.js"></script>
    <script src="js/4/animated.js"></script>
    <script src="js/4/kelly.js"></script>

    <script>
        $(document).ready(function() {
            $("body").tooltip({
                selector: '[data-toggle=tooltip]'
            });
        });
    </script>

    <!-- Chart code -->
    <script>
        am4core.ready(function() {

            // Themes begin
            am4core.useTheme(am4themes_animated);
            am4core.options.commercialLicense = true;
            // Themes end

            // create chart
            var chart = am4core.create("angularGauge", am4charts.GaugeChart);
            
            chart.innerRadius = -15;

            var axis = chart.xAxes.push(new am4charts.ValueAxis());
            axis.min = 0;
            axis.max = 100;
            axis.strictMinMax = true;
            
            // Format axis labels to show percentage
            axis.renderer.labels.template.adapter.add("text", function(text) {
                return text + "%";
            });
             
            var colorSet = new am4core.ColorSet();

            var gradient = new am4core.LinearGradient();
            gradient.stops.push({
                color: am4core.color("red")
            })
            gradient.stops.push({
                color: am4core.color("yellow")
            })
            gradient.stops.push({
                color: am4core.color("green")
            })

            axis.renderer.line.stroke = gradient;
            axis.renderer.line.strokeWidth = 15;
            axis.renderer.line.strokeOpacity = 1;

            axis.renderer.grid.template.disabled = true;

            var hand = chart.hands.push(new am4charts.ClockHand());
            hand.radius = am4core.percent(100);

            setInterval(function() {
                hand.showValue(100, 1000, am4core.ease.cubicOut);
            }, 2000);


        }); // end am4core.ready()
    </script>

<!-- Chart code -->
<script>
am5.ready(function() {

// Create root element
// https://www.amcharts.com/docs/v5/getting-started/#Root_element
var root = am5.Root.new("smeChart");

// Set themes
// https://www.amcharts.com/docs/v5/concepts/themes/
root.setThemes([
  am5themes_Animated.new(root)
]);

// Create chart
// https://www.amcharts.com/docs/v5/charts/radar-chart/
var chart = root.container.children.push(
  am5radar.RadarChart.new(root, {
    panX: false,
    panY: false,
    startAngle: 180,
    endAngle: 360
  })
);

chart.getNumberFormatter().set("numberFormat", "#'%'");

// Create axis and its renderer
// https://www.amcharts.com/docs/v5/charts/radar-chart/gauge-charts/#Axes
var axisRenderer = am5radar.AxisRendererCircular.new(root, {
  innerRadius: -40
});

axisRenderer.grid.template.setAll({
  stroke: root.interfaceColors.get("background"),
  visible: true,
  strokeOpacity: 0.8
});

var xAxis = chart.xAxes.push(
  am5xy.ValueAxis.new(root, {
    maxDeviation: 0,
    min: 0,
    max: 100,
    strictMinMax: true,
    renderer: axisRenderer
  })
);

// Add clock hand
// https://www.amcharts.com/docs/v5/charts/radar-chart/gauge-charts/#Clock_hands
var axisDataItem = xAxis.makeDataItem({});

var clockHand = am5radar.ClockHand.new(root, {
  pinRadius: 50,
  radius: am5.percent(100),
  innerRadius: 50,
  bottomWidth: 0,
  topWidth: 0
});

clockHand.pin.setAll({
  fillOpacity: 0,
  strokeOpacity: 0.5,
  stroke: am5.color(0x000000),
  strokeWidth: 1,
  strokeDasharray: [2, 2]
});
clockHand.hand.setAll({
  fillOpacity: 0,
  strokeOpacity: 0.5,
  stroke: am5.color(0x000000),
  strokeWidth: 0.5
});

var bullet = axisDataItem.set(
  "bullet",
  am5xy.AxisBullet.new(root, {
    sprite: clockHand
  })
);

xAxis.createAxisRange(axisDataItem);

var label = chart.radarContainer.children.push(
  am5.Label.new(root, {
    centerX: am5.percent(50),
    textAlign: "center",
    centerY: am5.percent(50),
    fontSize: "1.5em"
  })
);

axisDataItem.set("value", 100);
bullet.get("sprite").on("rotation", function () {
  var value = axisDataItem.get("value");
  label.set("text", "100%");
});

// setInterval(function () {
//   var value = Math.round(Math.random() * 100);

//   axisDataItem.animate({
//     key: "value",
//     to: value,
//     duration: 500,
//     easing: am5.ease.out(am5.ease.cubic)
//   });

//   axisRange0.animate({
//     key: "endValue",
//     to: value,
//     duration: 500,
//     easing: am5.ease.out(am5.ease.cubic)
//   });

//   axisRange1.animate({
//     key: "value",
//     to: value,
//     duration: 500,
//     easing: am5.ease.out(am5.ease.cubic)
//   });
// }, 2000);

chart.bulletsContainer.set("mask", undefined);

var colorSet = am5.ColorSet.new(root, {});

var axisRange0 = xAxis.createAxisRange(
  xAxis.makeDataItem({
    above: true,
    value: 0,
    endValue: 100
  })
);

axisRange0.get("axisFill").setAll({
  visible: true,
  fill: colorSet.getIndex(0)
});

axisRange0.get("label").setAll({
  forceHidden: true
});

var axisRange1 = xAxis.createAxisRange(
  xAxis.makeDataItem({
    above: true,
    value: 100,
    endValue: 100
  })
);

axisRange1.get("axisFill").setAll({
  visible: true,
  fill: colorSet.getIndex(4)
});

axisRange1.get("label").setAll({
  forceHidden: true
});

// Make stuff animate on load
chart.appear(1000, 100);

}); // end am5.ready()
</script>

    <script>
        am4core.ready(function() {

            // Themes begin
            am4core.useTheme(am4themes_animated);
            // Themes end

            // Create chart instance
            var chart = am4core.create("pieChart", am4charts.PieChart);

            // Add data
            chart.data = [{
                "country": "Data Gathered from workshops",
                "litres": 31,
            },{
                "country": "SME Unavailable",
                "litres": 4,
            }];

            // Add and configure Series
            var pieSeries = chart.series.push(new am4charts.PieSeries());
            pieSeries.dataFields.value = "litres";
            pieSeries.dataFields.category = "country";
            pieSeries.slices.template.stroke = am4core.color("#fff");
            pieSeries.slices.template.strokeWidth = 2;
            pieSeries.slices.template.strokeOpacity = 1;
            pieSeries.labels.template.wrap = true;
            pieSeries.labels.template.maxWidth = 90;
            pieSeries.labels.template.fontSize = 11;

            // This creates initial animation
            pieSeries.hiddenState.properties.opacity = 1;
            pieSeries.hiddenState.properties.endAngle = -90;
            pieSeries.hiddenState.properties.startAngle = -90;

        }); // end am4core.ready()
    </script>

    <!-- Chart code -->
    `<script>
        am4core.ready(function() {

            // Themes begin
            am4core.useTheme(am4themes_animated);
            // Themes end

            // Create chart instance
            var chart = am4core.create("actionPie", am4charts.PieChart);

            // Add data
            chart.data = [ 
			<?php
			// $collection1 = $db->Application;
			$distinct_action = $collection->distinct("Application Category");
			$dataset = array();
			foreach($distinct_action as $one_action)
			{
				$string = '{"country": "'.trim($one_action).'",';
				$string = $string.'"litres": '.count($collection->find(array("Application Category" => $one_action))->toArray()).'}';
				$dataset[] = $string;
			}
			echo implode(",",$dataset);
			?>
			];

            // Add and configure Series
            var pieSeries = chart.series.push(new am4charts.PieSeries());
            pieSeries.dataFields.value = "litres";
            pieSeries.dataFields.category = "country";
            pieSeries.slices.template.stroke = am4core.color("#fff");
            pieSeries.slices.template.strokeWidth = 2;
            pieSeries.slices.template.strokeOpacity = 1;
            // pieSeries.labels.template.wrap = true;
            // pieSeries.labels.template.maxWidth = 90;
            pieSeries.labels.template.fontSize = 11;

            // This creates initial animation
            pieSeries.hiddenState.properties.opacity = 1;
            pieSeries.hiddenState.properties.endAngle = -90;
            pieSeries.hiddenState.properties.startAngle = -90;

        }); // end am4core.ready()
    </script>`
    `<script>
        am4core.ready(function() {

            // Themes begin
            am4core.useTheme(am4themes_animated);
            // Themes end

            // Create chart instance
            var chart = am4core.create("appComplex", am4charts.PieChart);

            // Add data
            chart.data = [ 
			<?php
			// $collection1 = $db->Application;
			$distinct_action = $collection->distinct("AppComplexity");
			$dataset = array();
			foreach($distinct_action as $one_action)
			{
				$string = '{"country": "'.trim($one_action).'",';
				$string = $string.'"litres": '.count($collection->find(array("AppComplexity" => $one_action))->toArray()).'}';
				$dataset[] = $string;
			}
			echo implode(",",$dataset);
			?>
			];

            // Add and configure Series
            var pieSeries = chart.series.push(new am4charts.PieSeries());
            pieSeries.dataFields.value = "litres";
            pieSeries.dataFields.category = "country";
            pieSeries.slices.template.stroke = am4core.color("#fff");
            pieSeries.slices.template.strokeWidth = 2;
            pieSeries.slices.template.strokeOpacity = 1;
            // pieSeries.labels.template.wrap = true;
            // pieSeries.labels.template.maxWidth = 90;
            pieSeries.labels.template.fontSize = 11;

            // This creates initial animation
            pieSeries.hiddenState.properties.opacity = 1;
            pieSeries.hiddenState.properties.endAngle = -90;
            pieSeries.hiddenState.properties.startAngle = -90;

        }); // end am4core.ready()
    </script>
<script>
am5.ready(function() {

// Create root element
// https://www.amcharts.com/docs/v5/getting-started/#Root_element
var root = am5.Root.new("application_counts");

// Set themes
// https://www.amcharts.com/docs/v5/concepts/themes/
root.setThemes([
  am5themes_Animated.new(root)
]);

// Create chart
// https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/
var chart = root.container.children.push(am5percent.PieChart.new(root, {
  radius: am5.percent(90),
  innerRadius: am5.percent(50),
  layout: root.horizontalLayout
}));

// Create series
// https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Series
var series = chart.series.push(am5percent.PieSeries.new(root, {
  name: "Series",
  valueField: "sales",
  categoryField: "country"
}));

series.slices.template.set("tooltipText", "{category}: {value}");
// Set data
// https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Setting_data
series.data.setAll([{
  country: "Bonds & Surity",
  sales: 1
}, {
  country: "BOP & FAP",
  sales: 4
}, {
  country: "Commercial Auto",
  sales: 1
}, {
  country: "Hurricane   ( Access )",
  sales: 1
}, {
  country: "Multiple's (Commercial Auto, Homeowner, Dwelling Fire,\n Hurricane, First Select Polices (FSP), Workers Comp)",
  sales: 2
}, {
  country: "Personal & Commercial",
  sales: 4
}, {
  country: "Personal & Commercial  (Includes BOP & FAP )",
  sales: 2
}, {
  country: "Personal & Commercial ( Does not include BOP & FAP )",
  sales: 17
}, {
  country: "Personal & Commercial Auto",
  sales: 1
},{
  country: "Personal Lines & FAP from SPI",
  sales: 1
},{
  country: "WorkComp/ BOP/ FAP/ TDI/ JUP/ Bond & Surity",
  sales: 4
},{
  country: "Worker Comp",
  sales: 3
},{
  country: "Worker Comp & Medical",
  sales: 1
},{
  country: "Worker Comp & Medical",
  sales: 1
},{
  country: "Workers Comp & Commercial",
  sales: 1
}]);

// Disabling labels and ticks
series.labels.template.set("visible", false);
series.ticks.template.set("visible", false);


// Adding gradients
series.slices.template.set("strokeOpacity", 0);
series.slices.template.set("fillGradient", am5.RadialGradient.new(root, {
  stops: [{
    brighten: -0.8
  }, {
    brighten: -0.8
  }, {
    brighten: -0.5
  }, {
    brighten: 0
  }, {
    brighten: -0.5
  }]
}));

// Create legend
// https://www.amcharts.com/docs/v5/charts/percent-charts/legend-percent-series/
// var legend = chart.children.push(am5.Legend.new(root, {
//   centerY: am5.percent(50),
//   y: am5.percent(50),
//   layout: root.verticalLayout
// }));
// // set value labels align to right
// legend.valueLabels.template.setAll({ textAlign: "right" })
// // set width and max width of labels
// legend.labels.template.setAll({ 
//   maxWidth: 140,
//   width: 140,
//   oversizedBehavior: "wrap"
// });

legend.data.setAll(series.dataItems);


// Play initial series animation
// https://www.amcharts.com/docs/v5/concepts/animations/#Animation_of_series
series.appear(1000, 100);

}); // end am5.ready()
</script>

    <script>
        $(".list-group-item").hover(
            function() {
                $(this).toggleClass("active");
            }
        );

        $("#totalApps").hover(
            function() {
                $(this).toggleClass("border-primary");
            }
        );
    </script>

    <script>
        am4core.ready(function() {

            // Themes begin
            am4core.useTheme(am4themes_kelly);
            am4core.useTheme(am4themes_animated);
            // Themes end

            // Create chart instance
            var chart = am4core.create("targetPie", am4charts.PieChart);

            // Add data
            chart.data = [{
                "country": "CFE",
                "litres": 37
            }, {
                "country": "Target not required",
                "litres": 27
            }, {
                "country": "CFE + ENGAGE1/DOC1",
                "litres": 19
            }, {
                "country": "COMPASS",
                "litres": 14
            }, {
                "country": "Cash Manager Replacement",
                "litres": 11
            }, {
                "country": "ENGAGE1, DOC1",
                "litres": 7
            }, {
                "country": "GIS, C:OZ",
                "litres": 5
            }, {
                "country": "Others",
                "litres": 26
            }];

            // Add and configure Series
            var pieSeries = chart.series.push(new am4charts.PieSeries());
            pieSeries.dataFields.value = "litres";
            pieSeries.dataFields.category = "country";
            pieSeries.slices.template.stroke = am4core.color("#fff");
            pieSeries.slices.template.strokeWidth = 2;
            pieSeries.slices.template.strokeOpacity = 1;
            pieSeries.labels.template.wrap = true;
            pieSeries.labels.template.maxWidth = 95;
            pieSeries.labels.template.fontSize = 11;

            // This creates initial animation
            pieSeries.hiddenState.properties.opacity = 1;
            pieSeries.hiddenState.properties.endAngle = -90;
            pieSeries.hiddenState.properties.startAngle = -90;

        }); // end am4core.ready()
    </script>
    <script>
am5.ready(function() {

// Create root element
// https://www.amcharts.com/docs/v5/getting-started/#Root_element
var root = am5.Root.new("application_pie");

// Set themes
// https://www.amcharts.com/docs/v5/concepts/themes/
root.setThemes([am5themes_Animated.new(root)]);

var container = root.container.children.push(
  am5.Container.new(root, {
    width: am5.p100,
    height: am5.p100,
    layout: root.horizontalLayout
  })
);

// Create main chart
// https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/
var chart = container.children.push(
  am5percent.PieChart.new(root, {
    tooltip: am5.Tooltip.new(root, {})
  })
);

// Create series
// https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Series
var series = chart.series.push(
  am5percent.PieSeries.new(root, {
    valueField: "value",
    categoryField: "category",
    alignLabels: false
  })
);
series.labels.template.setAll({
  text: "{category}: {value}",
  textType: "circular",
  radius: 4
});

series.labels.template.setAll({
  textType: "adjusted",
  radius: 10,
  inside: false
});
series.ticks.template.set("visible", false);
series.slices.template.set("toggleKey", "none");

// add events
series.slices.template.events.on("click", function(e) {
  selectSlice(e.target);
});

// Create sub chart
// https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/
var subChart = container.children.push(
  am5percent.PieChart.new(root, {
    radius: am5.percent(50),
    tooltip: am5.Tooltip.new(root, {})
  })
);

// Create sub series
// https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Series
var subSeries = subChart.series.push(
  am5percent.PieSeries.new(root, {
    valueField: "value",
    categoryField: "category"
  })
);
subSeries.labels.template.setAll({
  text: "{category}: {value}",
  textType: "circular",
  radius: 4
});

subSeries.data.setAll([
  { category: "A", value: 0 },
  { category: "B", value: 0 },
  { category: "C", value: 0 },
  { category: "D", value: 0 },
  { category: "E", value: 0 },
  { category: "F", value: 0 },
  { category: "G", value: 0 }
]);
subSeries.slices.template.set("toggleKey", "none");

var selectedSlice;

series.on("startAngle", function() {
  updateLines();
});

container.events.on("boundschanged", function() {
  root.events.once("frameended", function() {
    updateLines();
   })
});

function updateLines() {
  if (selectedSlice) {
    var startAngle = selectedSlice.get("startAngle");
    var arc = selectedSlice.get("arc");
    var radius = selectedSlice.get("radius");

    var x00 = radius * am5.math.cos(startAngle);
    var y00 = radius * am5.math.sin(startAngle);

    var x10 = radius * am5.math.cos(startAngle + arc);
    var y10 = radius * am5.math.sin(startAngle + arc);

    var subRadius = subSeries.slices.getIndex(0).get("radius");
    var x01 = 0;
    var y01 = -subRadius;

    var x11 = 0;
    var y11 = subRadius;

    var point00 = series.toGlobal({ x: x00, y: y00 });
    var point10 = series.toGlobal({ x: x10, y: y10 });

    var point01 = subSeries.toGlobal({ x: x01, y: y01 });
    var point11 = subSeries.toGlobal({ x: x11, y: y11 });

    line0.set("points", [point00, point01]);
    line1.set("points", [point10, point11]);
  }
}

// lines
var line0 = container.children.push(
  am5.Line.new(root, {
    position: "absolute",
    stroke: root.interfaceColors.get("text"),
    strokeDasharray: [2, 2]
  })
);
var line1 = container.children.push(
  am5.Line.new(root, {
    position: "absolute",
    stroke: root.interfaceColors.get("text"),
    strokeDasharray: [2, 2]
  })
);

// Set data
// https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Setting_data
series.data.setAll([
  {
    category: "Bonds & Surity ",
    value: 1,
    subData: [
      { category: "Bond Portfolio", value: 15 }
    ]
  },
  {
    category: "BOP & FAP",
    value: 4,
    subData: [
        { category: "Sure Power Direct Sales Portal", value: 14 },
      { category: "Sure Power Service Portal", value: 16 },
      { category: "Sure Power Innovation", value: 12 },
      { category: "ACH Uploader", value: 18 }
    ]
  },
  {
    category: "Personal & Commercial",
    value: 4,
    subData: [
        { category: "Personal Auto ISO Stat", value: 22 },
      { category: "Personal Lines ISO Stat", value: 26 },
      { category: "CEP Annual", value: 21 },
      { category: "CEP Quarter", value: 18 }
    ]
  },
  {
    category: "Commercial Auto",
    value: 1,
    subData: [
      { category: "Print VID", value: 4}
    ]
  },
  {
    category: "Hurricane ( Access )",
    value: 1,
    subData: [
      { category: "Argonaut RiskLink Extracts", value: 4}
    ]
  },
  {
    category: "Multiple  's (Commercial Auto, Homeowner, Dwelling Fire, Hurricane, First Select Polices (FSP), Workers Comp)",
    value: 2,
    subData: [
      { category: "First Link", value: 8},
      { category: "PMS On Demand", value: 6}
    ]
  }
]);

function selectSlice(slice) {
  selectedSlice = slice;
  var dataItem = slice.dataItem;
  var dataContext = dataItem.dataContext;

  if (dataContext) {
    var i = 0;
    subSeries.data.each(function(dataObject) {
      var dataObj = dataContext.subData[i];
      if(dataObj){
          if(!subSeries.dataItems[i].get("visible")){
              subSeries.dataItems[i].show();
          }
          subSeries.data.setIndex(i, dataObj);
      }
      else{
          subSeries.dataItems[i].hide();
      }
      
      i++;
    });
  }

  var middleAngle = slice.get("startAngle") + slice.get("arc") / 2;
  var firstAngle = series.dataItems[0].get("slice").get("startAngle");

  series.animate({
    key: "startAngle",
    to: firstAngle - middleAngle,
    duration: 1000,
    easing: am5.ease.out(am5.ease.cubic)
  });
  series.animate({
    key: "endAngle",
    to: firstAngle - middleAngle + 360,
    duration: 1000,
    easing: am5.ease.out(am5.ease.cubic)
  });
}

container.appear(1000, 10);

series.events.on("datavalidated", function() {
  selectSlice(series.slices.getIndex(0));
});

}); // end am5.ready()
</script>
!-- Chart code -->
<script>
am5.ready(function() {

// Create root element
// https://www.amcharts.com/docs/v5/getting-started/#Root_element
var root = am5.Root.new("appCriticality");

// Set themes
// https://www.amcharts.com/docs/v5/concepts/themes/
root.setThemes([
  am5themes_Animated.new(root)
]);

// Create chart
// https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/
// start and end angle must be set both for chart and series
var chart = root.container.children.push(am5percent.PieChart.new(root, {
  startAngle: 180,
  endAngle: 360,
  layout: root.verticalLayout,
  innerRadius: am5.percent(50)
}));

// Create series
// https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Series
// start and end angle must be set both for chart and series
var series = chart.series.push(am5percent.PieSeries.new(root, {
  startAngle: 180,
  endAngle: 360,
  valueField: "value",
  categoryField: "category",
  alignLabels: false
}));

series.states.create("hidden", {
  startAngle: 180,
  endAngle: 180
});

series.slices.template.setAll({
  cornerRadius: 5
});

series.ticks.template.setAll({
  forceHidden: true
});

// Set data
// https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Setting_data
series.data.setAll([
  { value: 1, category: "Very Low" },
  { value: 15, category: "Low" },
  { value: 28, category: "Medium" },
  { value: 18, category: "High" },
  { value: 4, category: "Very High" }
]);

series.appear(1000, 100);

}); // end am5.ready()
</script>


</body>

</html>
<?php
error_reporting(0);
require_once './pages/auth/pageHandler.php';
session_start();
$_SESSION['currentPage'] = 'projectPlan';

//$m = new MongoClient();
require '/var/www/html/vendor/autoload.php';
$m= new MongoDB\Client("mongodb://127.0.0.1/");
$db = $m->nationWide;
$collection = $db->projectPlan;
$collection1 = $collection->findOne();
// Build aggregation: count apps with valid Decom end date per Wave
$pipeline = [
    [
        '$match' => [
            'Decom end date' => [ '$exists' => true, '$ne' => 'NA' ]
        ]
    ],
    [
        '$group' => [
            '_id'   => '$Wave',
            'count' => [ '$sum' => 1 ],
            'apps'  => [ '$push' => '$Application Name' ]   // ✅ collect app names
        ]
    ],
    [
        '$project' => [
            '_id'   => 0,
            'Wave'  => '$_id',
            'count' => 1,
            'apps'  => 1
        ]
    ],
    [ '$sort' => [ 'Wave' => 1 ] ]
];

$waveCounts = $collection->aggregate($pipeline)->toArray();
// $rows = $collection->aggregate($pipeline)->toArray();

// Prepare data for amCharts: [{ date: <ms>, value: <count> }, ...]
$chartData = [];
foreach ($rows as $r) {
    $y = isset($r['year']) ? (int)$r['year'] : null;
    $m = isset($r['month']) ? (int)$r['month'] : null;
    if ($y && $m) {
        // Last day of the month (handles leap years, different month lengths)
        $lastDay = cal_days_in_month(CAL_GREGORIAN, $m, $y);
        // Use **noon UTC** to avoid any DST/offset edge cases pushing it to previous month
        $ms = gmmktime(12, 0, 0, $m, $lastDay, $y) * 1000;
        $count = isset($r['count']) ? (int)$r['count'] : 0;
        $chartData[] = [ 'date' => $ms, 'value' => $count ];
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Decommission Analyzer - Project Plan</title>
    <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/custom-style.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

    <style>
        #chartDiv,
        #chartdiv {
            height: 575px;
        }
        #ProjectPlanChart
        {height: 575px;}
    </style>
    <script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Responsive.js"></script>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include './pages/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include './pages/navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Wave wise - Project Plan</h1>
                    </div>

                    <!-- Content Row -->
                    <div class="row">
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Applications Decommission Plan
                                    </h6>

                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <div id="ProjectPlanChart" class="chart-area">
                                        <!-- <div id="chartdiv"></div>
                                        <div id="balloon"></div> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Application Decommission Dates</h6>

                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped" id="projectPlanTable" width="100%" cellspacing="0">
                                            <thead>
                                                <tr>
												<?php
										foreach($collection1 as $key=>$value)
										{
											if($key == "_id" OR $key == "poa")continue;
											echo '<th scope="col">',trim($key),'</th>';
										}
										?>
                                                    <!--th>Application Name</th>
                                                    <th>Decommission Start Date</th>
                                                    <th>Decommission End Date</th-->
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $results = $collection->find();
                                                // print_r($results);
                                                foreach ($results as $result) {
                                                    echo "<tr>";
                                                    // echo "<td>{$result['appname']}</td>";
                                                    // echo "<td>{$result['Start']}</td>";
                                                    // echo "<td>{$result['End']}</td>";
													foreach($result as $key=>$value)
											{
												if($key == "_id" or $key == "poa")continue;
												echo "<td>",$value,"</td>";
											}
                                                    echo "</tr>";
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div id="dateFormatNote" style="font-size:12px; color:#666; margin: 0 0 8px 0; text-align:right">
        <em> <br>Note: All date values are in MM/DD/YYYY format</em>
    </div>
                            </div>
                        </div>
                    </div>



                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include './pages/footer.php'; ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

    </div>
    <!-- End of Page Wrapper -->

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

    <!-- Buttons Scripts -->
    <script src="js/dataTables.buttons.min.js"></script>
    <script src="js/buttons.flash.min.js"></script>
    <script src="js/buttons.html5.min.js"></script>
    <script src="js/buttons.print.min.js"></script>

<script>
const waveChartData = <?php echo json_encode($waveCounts, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
</script>
    
 

<script>
am5.ready(function() {
// working fine until now 
const waveLabels = {
  "Wave 1": "Jul'26",
  "Wave 2": "Aug'26",
  "Wave 3": "Sep'26",
  "Wave 4": "Nov'26",
  "Wave 5": "Dec'26",
  "Wave 6": "Jan'27",
  "Wave 7": "Feb'27",
  "Wave 8": "Mar'27",
  "Wave 9": "May'27"
};

  var root = am5.Root.new("ProjectPlanChart");

root._logo.dispose();   // ✅ Remove amCharts watermark
  root.setThemes([
    am5themes_Animated.new(root),
    am5themes_Responsive.new(root)
  ]);
  

  var chart = root.container.children.push(am5xy.XYChart.new(root, {
    panX: false,
    panY: false,
    layout: root.verticalLayout
  }));

  // --- Axes ---
  var yAxis = chart.yAxes.push(
    am5xy.CategoryAxis.new(root, {
      categoryField: "Wave",
      renderer: am5xy.AxisRendererY.new(root, { inversed: true }),
    })
  );
  yAxis.get("renderer").labels.template.adapters.add("text", function(text, target) {
  const wave = target.dataItem?.dataContext?.Wave;
  return waveLabels[wave] || text;
});

  var xAxis = chart.xAxes.push(
    am5xy.ValueAxis.new(root, {
      min: 0,
      renderer: am5xy.AxisRendererX.new(root, {})
    })
  );
var cursor = chart.set("cursor", am5xy.XYCursor.new(root, {
  behavior: "zoomY"
}));
cursor.lineX.set("visible", false);
cursor.lineY.set("visible", false);
  // --- Series ---
 var series = chart.series.push(
  am5xy.ColumnSeries.new(root, {
    name: "Apps",
    xAxis: xAxis,
    yAxis: yAxis,
    valueXField: "count",
    categoryYField: "Wave",
    tooltip: am5.Tooltip.new(root, {})
  })
);

// ✅ CORRECT adapter location
series.columns.template.adapters.add("tooltipText", function (text, target) {
  const data = target.dataItem?.dataContext;

  if (!data || !data.apps) {
    return text;
  }

  const appList = data.apps.map(app => "• " + app).join("\n");

  return `${data.Wave}: ${data.count} apps\n\n${appList}`;
});
  series.columns.template.setAll({
    cornerRadiusTR: 5,
    cornerRadiusBR: 5,
    strokeOpacity: 0
  });

  // ✅ Set Data
  yAxis.data.setAll(waveChartData);
  series.data.setAll(waveChartData);

  series.appear(1000);
  chart.appear(1000, 100);

});
</script>

</body>



</html>
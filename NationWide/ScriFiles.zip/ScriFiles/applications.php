<?php
error_reporting(0);
require_once './pages/auth/pageHandler.php';
session_start();
$_SESSION['currentPage'] = 'applications';

//$m = new MongoClient();
require '/var/www/html/vendor/autoload.php';
$m= new MongoDB\Client("mongodb://127.0.0.1/");
$db = $m->nationWide;
$collection = $db->Questionnaire;
$results = $collection->find();
$collection1 = $collection->findOne();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Decommission Analyzer - Applications</title>
    <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/custom-style.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>
<style>
    /* Keep table layout flexible, let columns size naturally */
#dataTable {
  table-layout: auto; /* or 'fixed' if you want evenly distributed columns */
}

/* Cell defaults */
#dataTable th, 
#dataTable td {
  vertical-align: top;
  padding: 0.5rem;
  /* Optional: give cells a reasonable max width so gigantic strings don’t break layout */
  max-width: 420px;         /* adjust if needed */
  word-break: break-word;   /* handle long unbroken strings */
}
#dataTable th:nth-child(1),
#dataTable td:nth-child(1) {
  display: none;
}

/* This wrapper will control the scroll behavior and keep row height fixed */
.cell-scroll {
  display: block;
  max-height: 125px;         /* 👈 desired fixed row content height */
  overflow: auto;           /* scroll if content exceeds height/width */
  /* Optional: keep horizontal scroll if a single long token appears */
  overflow-x: auto;
  overflow-y: auto;
}

/* Optional: a subtle inset to hint scrollability */
.cell-scroll {
  background-clip: padding-box;
}

/* Optional: tighten header height if needed */
#dataTable thead th {
  white-space: nowrap;
}
/* Scroll container for the whole table */
.table-wrapper {
    max-height: 650px;          /* adjust table height */
    overflow-y: auto;
    overflow-x: auto;
    border-radius: 6px;
    border: 1px solid #e2e5ec;
    padding: 0;
}

/* Minimalist Scrollbar (Chrome, Edge, Safari) */
.table-wrapper::-webkit-scrollbar,
.cell-scroll::-webkit-scrollbar {
    width: 6px;
    height: 6px;
}

.table-wrapper::-webkit-scrollbar-track,
.cell-scroll::-webkit-scrollbar-track {
    background: transparent;
}

.table-wrapper::-webkit-scrollbar-thumb,
.cell-scroll::-webkit-scrollbar-thumb {
    background: #c7ccdb;
    border-radius: 10px;
}

.table-wrapper::-webkit-scrollbar-thumb:hover,
.cell-scroll::-webkit-scrollbar-thumb:hover {
    background: #aab1c7;
}

/* Firefox Scrollbar */
.table-wrapper,
.cell-scroll {
    scrollbar-width: thin;
    scrollbar-color: #c7ccdb transparent;
}

/* Fix cell layout */
#dataTable th, 
#dataTable td {
    vertical-align: top;
    padding: 0.5rem;
    max-width: 420px;
    word-break: break-word;
}

/* Scrollable cell wrapper */
.cell-scroll {
    display: block;
    max-height: 125px;
    overflow: auto;
    padding-right: 5px;  /* prevents text touching scrollbar */
}


    </style>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include './pages/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include './pages/navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Applications Inventory</h1>
                    </div>

                    <!-- Content Row -->
                    <div class="card shadow mb-4">
                        <!-- <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
                        </div> -->
                        <div class="card-body">
                            <div class="table-wrapper">
                                <?php
                               $customHeaders = [
    "Number",
    "Application ID",
    "Application Name",
    "Application Description",
    "Line of Business",
    "Legacy Suite Context",
    "Application Owner Name",
    "Business Owner / SME",
    "Application SME",
    "Application Source Type",
    "Application Type Category",
    "Application Type",
    "Application Category",
    "Access UI",
    "Decommission Scope",
    "Decommission End Date",
    "Decommission Reason",
    "Application Tech Stack",
    "Application Criticality",
    "Application Size Value",
    "Database Type",
    "Target Application (POA)",
    "POA Ready By",
    "Application Status",
    "Application Age",
    "Expected Life",
    "Legal Compliance Value",
    "Regulatory Interface",
    "Revenue / User Impact",
    "Single or Group Application",
    "Batch / Bulk Access",
    "External Connectivity Value",
    "Data Gateway Value",
    "Incoming Dependencies",
    "Inbound Interface Count",
    "Interface Methods",
    "Outgoing Dependencies",
    "Outbound Interface Count",
    "Outgoing Interface Type",
    "Application Suite Dependency",
    "Application Level Dependency",
    "Report Count & Frequency",
    "Database Size",
    "Database Description & Type",
    "Application Data Owner",
    "Pre‑Archived Data Exists",
    "Historical Data Retention Period",
    "Database Backup Frequency",
    "Data Purge Policy Defined",
    "Preferred Data Treatment Post‑Decommission",
    "Archived Data Retrieval SLA",
    "Historical Data Retrieval SLA",
    "Source Code Archival Policy",
    "Shutdown Notice Period",
    "Release Procedure & Communication Model",
    "Internal User Count",
    "External User Count",
    "External User Migration Timeframe",
    "Ongoing Enhancement Projects",
    "Documentation Level",
    "Team Knowledge Level",
    "Support Level",
    "Application Stability",
    "Application Server Type",
    "Application Server Count",
    "Data Server Count",
    "Shared Server Application Count",
    "Third‑Party Tools & Vendors",
    "License Renewal Period",
    "Vendor Legal Agreements",
    "Application Run Cost (Yearly)",
    "Planning Guide Document",
    "Planning Guide Document Lead",
    "Next Step",
    "Archive Pattern",
    "Archive Storage",
    "Archive Data Access",
    "Technology Complexity",
    "Application Complexity Level",
    "Process Level Complexity"

];
                                ?>
                                <table class="table table-bordered table-striped table-wrapper align-items-center" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
										<?php
										foreach ($customHeaders as $header) {
    echo "<th scope='col'>{$header}</th>";
}
										?>
                                        <!--th scope="col">Application Name</th>
                                        <th scope="col">Type of Application</th>
                                        <th scope="col">Application Category</th>
                                        <th scope="col">LOB</th>
                                        <th scope="col">Deputy Owner</th>
                                        <th scope="col">Application Age</th>
                                        <th scope="col">Minimum expected life</th>
                                        <th scope="col">Revenue/ User impact</th>
                                        <th scope="col">Legal Compliances</th>
                                        <th scope="col">Single/ Group of Applications</th>
                                        <th scope="col">Application Interface</th>
                                        <th scope="col">Added New Dependencies</th>
                                        <th scope="col">Implementation</th>
                                        <th scope="col">Source code archival</th>
                                        <th scope="col">Incoming</th>
                                        <th scope="col">Outgoing</th>
                                        <th scope="col">No of Reports/ Frequencies</th>
                                        <th scope="col">Other applications</th>
                                        <th scope="col">Physical servers</th>
                                        <th scope="col">Third party tools</th>
                                        <th scope="col">FTE count</th>
                                        <th scope="col">Historical data</th>
                                        <th scope="col">Support Level</th>
                                        <th scope="col">Level of Documentation</th>
                                        <th scope="col">Ongoing enhancement</th>
                                        <th scope="col">Team's Knowledge</th>
                                        <th scope="col">Business Criticality</th>
                                        <th scope="col">Technologies</th>
                                        <th scope="col">Application Size</th>
                                        <th scope="col">Application Complexity</th>
                                        <th scope="col">Current DatabaseSize</th>
                                        <th scope="col">No of Users</th-->
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
										  foreach ($results as $result) {
											echo "<tr>";
                                            // if(count($collection->find(array("appname"=>$result['ApplicationName']))->toArray())==0)continue;
											   // echo "<tr><td>" . $result['ApplicationName'] . "</td><td>" . $result['Type of Application'] . "</td><td>" . $result['Application Category'] . "</td><td>" . $result['LOB'] . "</td><td>" . $result['DeputyOwner'] . "</td><td>" . $result['Age'] . "</td><td>" . $result['Minimum expected life'] . "</td><td>" . $result['user impact'] . "</td><td>" . $result['Legal compliance'] . "</td><td>" . $result['Single/ Group of Applications'] . "</td><td>" . $result['Appinterface'] . "</td><td>" . $result['Dependencies'] . "</td><td>" . $result['Implementation'] . "</td><td>" . $result['Source code archival'] . "</td><td>" . $result['Incoming'] . "</td><td>" . $result['Outgoing'] . "</td><td>" . $result['No of reports/frequency'] . "</td><td>" . $result['Other applications'] . "</td><td>" . $result['Physical servers'] . "</td><td>" . $result['Third party tools'] . "</td><td>" . $result['FTE count'] . "</td><td>" . $result['Historical data'] . "</td><td>" . $result['Support level'] . "</td><td>" . $result['Level of documentation'] . "</td><td>" . $result['Ongoing enhancement'] . "</td><td>" . $result['Teams knowledge'] . "</td><td>" . $result['Business Criticality'] . "</td><td>" . $result['Technologies'] . "</td><td>" . $result['AppSize'] . "</td><td>" . $result['AppComplexity'] . "</td><td>" . $result['DatabaseSize'] . "</td><td>" . $result['No of Users'] . "</td></tr>";
								foreach ($result as $key => $value) {
    if ($key == "_id") continue;
    if (is_array($value) || is_object($value)) {
        $value = json_encode($value, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    }
    echo '<td><div class="cell-scroll">' . htmlspecialchars((string)$value) . '</div></td>';
}
											echo "</tr>";
										  }
										?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include './pages/footer.php'; ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

    </div>
    <!-- End of Page Wrapper -->

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

    <!-- Buttons Scripts -->
    <script src="js/dataTables.buttons.min.js"></script>
    <script src="js/buttons.flash.min.js"></script>
    <script src="js/buttons.html5.min.js"></script>
    <script src="js/buttons.print.min.js"></script>
    

</body>



</html>
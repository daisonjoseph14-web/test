<?php
error_reporting(0);
require_once './pages/auth/pageHandler.php';

ob_start();
session_start();
// echo "Hello from PHP!";
$_SESSION['currentPage'] = 'jobCards';

//$m = new MongoClient();
require '/var/www/html/vendor/autoload.php';
$m= new MongoDB\Client("mongodb://127.0.0.1/");
$db = $m->nationWide;
$collection = $db->jobCards;
$jobCards = $collection->distinct('application_name', []);
sort($jobCards);

?>

<?php
// Build app data from Mongo and match your UI keys
$appSetAssoc = [];
try {
    $cursor = $collection->find([], ['sort' => ['application_name' => 1]]);
    foreach ($cursor as $doc) {
        $arr = json_decode(json_encode($doc, JSON_PARTIAL_OUTPUT_ON_ERROR), true);
        if (!$arr) continue;

        $appName = $arr['application_name'] ?? '';
        if ($appName === '') continue;

        // Map your schema to the UI keys used by your JS
        $row = [
            'Application Name'                   => (string)($arr['application_name'] ?? ''),
            'Application Category'               => (string)($arr['App_Category'] ?? ''),
            'Application Suite'                   => (string)($arr['App_Suite'] ?? ''),
            'Application Ownership'              => (string)($arr['App_Owner'] ?? ''),
            'Technology Stack'                   => (string)($arr['Tech_Stack'] ?? ''),
            'Application Status'                 => (isset($arr['App_Status']) && $arr['App_Status'] === 'Active') ? 'Yes' : 'No',
            'Business Criticality'               => (string)($arr['Business_Criticality'] ?? ''),
            'Application Functionality'          => (string)($arr['App_Functionality'] ?? ''),

            
            'Cost'                               => '',
            

            'Data for Compliance'                => '',
            'GapAnalysis'                        => 'No',
            'DataMigration'                      => 'No',
            'DataArchival'                       => (string)($arr['Data_Archival'] ?? ''),
            'Data Migration2'                    => 'No',
            'User Migration'                     => 'No',

            'Switch-Off'                         => (string)($arr['App_Removal'] ?? ''),
            'Big Bang'                           => '',


            'POA Ready'                          => (string)($arr['POA_Readiness'] ?? ''),
            'Point Of Arrival'                   => (string)($arr['Point_Of_Arrival'] ?? ''),
            'Total no of days to decommission'   => isset($arr['Decom_Days']) ? (string)$arr['Decom_Days'] : '',
            'Decommission Start Date'            => (string)($arr['Decom_Start'] ?? ''),
            'Decommission End Date'              => (string)($arr['Decom_End'] ?? ''),
            'Decommission Wave'              => (string)($arr['Decom_Wave'] ?? ''),
            'Data Archival Start Date'            => (string)($arr['Archival_Start'] ?? ''),
            'Data Archival End Date'              => (string)($arr['Arichival_End'] ?? ''),
            'Decommission Sequence'              => (string)($arr['Decom_Seq'] ?? ''),
        ];

        if (!isset($appSetAssoc[$appName])) $appSetAssoc[$appName] = [];
        $appSetAssoc[$appName][] = $row;
    }
} catch (Throwable $e) {
    // keep UI alive even if data fetch fails
}

$appSet = [$appSetAssoc];
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Decommission Analyzer - Job Cards</title>
    <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/custom-style.css" rel="stylesheet">

    <style>
        .job-card-row {
            margin-top: px;

        }

        .job-card-content {
            background-color: #342668;
            color: white;
            padding: 4px;
            margin-bottom: 10px;
            border-radius: .35rem;
        }

        .job-card-header {
            margin-bottom: 10px;
            font-weight: bold;
        }

        .green{
        
    background-color: #11af11f3; /* light green */

        }

        /* burst div */
        /* .burst-12 {
        background: red;
        width: 80px;
        height: 80px;
        position: relative;
        text-align: center;
        left: 90px;
        top: 10px;
        z-index: -1;
    }

    .burst-12:before,
    .burst-12:after {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        height: 80px;
        width: 80px;
        background: red;
    }

    .burst-12:before {
        transform: rotate(30deg);
    }

    .burst-12:after {
        transform: rotate(60deg);
    } */

        .dpd-td {
            background-color: #342668;
            color: #FFFFFF;
            padding: 7px !important;
            border-radius: .35rem;
        }

        .circle {
            background: #342668;
            border-radius: 50%;
            width: 100px;
            height: 100px;
            color: white;
            padding: 4px;
            margin-bottom: 27px;
            margin-top: 30px;
            margin-left: 90px;
            display: flex;
            align-items: center;
            align-content: center;
            justify-content: center;
        }
        /* Circle utility */
.circle {
 
  border-radius: 50%;       /* Makes it a circle */
  


  /* Center the content */
  display: grid;
  place-items: center;
  text-align: center;
  padding: 12px;            /* for some breathing room */
  margin-inline: auto;      /* center horizontally in the column */

  /* If content overflows, keep it tidy */
  overflow: hidden;
}

/* Optional: make the header align nicely */
#decomSeq .job-card-header {
  margin-bottom: 12px;
  font-weight: 600;
}
/* Fixed-size box + centered text for Application Name */
.appname-box {
  width: 100%;           /* keep the Bootstrap column width */
  min-height: 33px;      /* choose the height you want */
  max-height: 33px;      /* same as min to keep height fixed */

  display: grid;
  place-items: center;   /* vertical + horizontal centering */
  text-align: center;

  line-height: 1.2;
  overflow: hidden;        /* hide spillover while we shrink text */
  word-break: break-word;  /* break very long ids/names */
  hyphens: auto;

  /* starting font size; JS will shrink from here if needed */
  font-size: 20px;
}

    </style>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include './pages/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include './pages/navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <!-- <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Job Cards</h1>
                      
                        <div role="alert" aria-live="assertive" aria-atomic="true" class="toast" style="border-radius: .5rem; background-color: yellow; color: black;" data-delay=2000>
                            <div class="toast-body">
                                <p style="display: contents;">Hello, world! This is a toast message.</p>
                                <button type="button" class="close" style="margin-top: -2px;" data-dismiss="toast" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        </div>
                    </div> -->


                    <!-- Content Row -->
                    <div class="row">
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-around">
                                    <button class="btn btn-primary" data-toggle="modal" data-target="#criteriaModal">
                                        <i class="fas fa-filter"></i> Select Criteria
                                    </button>
                                    <!-- Modal -->
                                    <div class="modal fade" id="criteriaModal" tabindex="-1" role="dialog" aria-labelledby="criteriaModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="criteriaModalLabel">Select the Job Card
                                                        Criteria</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" value="Select All" id="selectAllCheck">
                                                        <label class="form-check-label" for="selectAllCheck">Select
                                                            All</label>
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" value="Application General" id="appGeneralCheck">
                                                        <label class="form-check-label" for="appGeneralCheck">Application General</label>
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" value="Decommission Details" id="decommCheck">
                                                        <label class="form-check-label" for="decommCheck">Decommission Details</label>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-danger" id="clearModal">Clear</button>
                                                    <button type="button" class="btn btn-primary" id="saveModal" data-dismiss="modal">Save changes</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                  <div class="dropdown no-arrow">
  <select class="form-control" name="jobCards" id="selJobCards">
    <option selected disabled>Choose Job Card</option>
    <?php foreach ($jobCards as $jobCard): ?>
      <option
        value="<?= htmlspecialchars($jobCard, ENT_QUOTES, 'UTF-8'); ?>"
        data-key="<?= htmlspecialchars($jobCard, ENT_QUOTES, 'UTF-8'); ?>"
      >
        <?= htmlspecialchars($jobCard, ENT_QUOTES, 'UTF-8'); ?>
      </option>
    <?php endforeach; ?>
  </select>
</div>
                                    <button onclick="CreatePDFfromHTML()" type="button" class="btn btn-primary" id="download"><i class="fas fa-download"></i></button>
                                </div>
                                <!-- Card Body -->
                                <!-- Job Card -->
                                <div class="card-body text-center html-content" style="display:none" id="jobCardBody">
                                    <div id="appGeneral">
										<div class="row job-card-row">
											<!--div class="col-sm-12" style="padding-right: 218px;padding-left: 217px;" id="appName"-->
											<div class="col-sm-3" id="appName" >
												<div class="job-card-header">Application Name</div>
												<div class="job-card-content green appname-box" id="appNameText">XXXxx</div>
                                               
											</div>
                                            <div class="col-sm-3" id="appCategory">
                                                <div class="job-card-header">Appplication Category</div>
                                                <div class="job-card-content green" id="appCategoryText">XXXX</div>
                                            </div>
                                            <div class="col-sm-3" id="appSuite">
                                                <div class="job-card-header">Application Suite</div>
                                                <div class="job-card-content mb-4  green" id="appSuiteText">> 20 Years</div>
                                            </div>
                                            <div class="col-sm-3" id="appOwner">
                                                <div class="job-card-header">Application Owner</div>
                                                <div class="job-card-content mb-4  green" id="appOwnerText">XXXX</div>
                                            </div>
										</div>
                                        <div class="row job-card-row">
                                            <div class="col-sm-4" id="techStack">
                                                <div class="job-card-header">Tech Stack</div>
                                                <div class="job-card-content  green" id="techStackText">XXXX</div>
                                            </div>
                                            <div class="col-sm-4" id="appStatus">
                                                <div class="job-card-header">Application Status</div>
                                                <div class="job-card-content mb-4 green" id="appStatusText">XXXX</div>
                                            </div>
                                            <div class="col-sm-4" id="busCriticality">
                                                <div class="job-card-header">Business Criticality
                                                </div>
                                                <div class="job-card-content mb-4  green" id="busCriticalityText">XXXX</div>
                                            </div>
                                        </div>
                                        <div class="row job-card-row">
                                            <div class="col-sm-12" id="appFunc">
                                                <div class="job-card-header">Application Functionality
                                                </div>
                                                <div class="job-card-content green" id="appFuncText">
                                                    Application Functionality is...
                                                </div>
                                            </div>                                            
                                        </div>
                                    </div>
                                    <div id="decomm">
                                        <div class="row job-card-row">

                                            <div class="col-sm-3" id="decomPatternDetail">
                                                <div class="job-card-header">Decommission Pattern Details
                                                </div>
                                                <table id="myTable" class="table table-striped">
                                                    <tbody>
                                                        <tr id="AppRemovalInterfaces">
                                                            <td class="dpd-td">App removal Interfaces</td>
                                                            <td class="dpd-td" id="AppRemovalInterfacesText">Yes</td>
                                                        </tr>
                                                        <tr id="GapAnalysis">
                                                            <td class="dpd-td">
                                                            App Archive </td>
                                                            <td class="dpd-td" id="GapAnalysisText">Yes</td>
                                                        </tr>
                                                        <tr id="DataMigration">
                                                            <td class="dpd-td">
                                                            App Removal </td>
                                                            <td class="dpd-td" id="DataMigrationText">Yes</td>
                                                        </tr>
                                                        <tr id="dataArchival">
                                                            <td class="dpd-td">
                                                            Environment Clean-up </td>
                                                            <td class="dpd-td" id="dataArchivalText1">Yes</td>
                                                        </tr>
                                                        <tr id="dataMigration">
                                                            <td class="dpd-td">
                                                            Infra Release </td>
                                                            <td class="dpd-td" id="dataMigrationText2">Yes</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>

                                            <div class="col-sm-3" id="decomPatternDataDetail">
                                                <div class="job-card-header">Decommission Data Pattern Details
                                                </div>
                                                <table id="myTableData" class="table table-striped">
                                                    <tbody>
                                                        <tr id="DataScream">
                                                            <td class="dpd-td">Data Scream Test</td>
                                                            <td class="dpd-td" id="DataScreamText">No</td>
                                                        </tr>
                                                        <tr id="GapAnalysis">
                                                            <td class="dpd-td">
                                                            Data Archival </td>
                                                            <td class="dpd-td" id="GapAnalysisText">Yes</td>
                                                        </tr>
                                                        <tr id="DataMigration">
                                                            <td class="dpd-td">
                                                            Data Backup </td>
                                                            <td class="dpd-td" id="DataMigrationText">Yes</td>
                                                        </tr>
                                                        <tr id="dataArchival">
                                                            <td class="dpd-td">
                                                            Data Purge </td>
                                                            <td class="dpd-td" id="dataArchivalText1">Yes</td>
                                                        </tr>
                                                        <tr id="dataMigration">
                                                            <td class="dpd-td">
                                                            Data Retain </td>
                                                            <td class="dpd-td" id="dataMigrationText2">Yes</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
<!-- RIGHT SECTION (replace the three col-sm-2 blocks with this single col-sm-6) -->
<div class="col-sm-6" id="rightInfoPanel">
    <!-- Row 1: Point of Arrival (2) -->
    <div class="row g-3 mb-3">
        <div class="col-12 col-md-6">
            <div id="POAReadiness">
                <div class="job-card-header">Point Of Arrival Readiness</div>
                <div class="job-card-content" id="POAReadinessText">XXXX</div>
            </div>
        </div>
        <div class="col-12 col-md-6">
            <div id="pointOfArrival">
                <div class="job-card-header">Point Of Arrival - App</div>
                <div class="job-card-content" id="pointOfArrivalText">DD-MM-YYYY</div>
            </div>
        </div>
    </div>

    <!-- Row 2: Data Archival (2) -->
    <div class="row g-3 mb-3">
        <div class="col-12 col-md-6">
            <div id="archivalStart">
                <div class="job-card-header">Data Archival Start Date</div>
                <div class="job-card-content" id="archivalStartText">XXXX</div>
            </div>
        </div>
        <div class="col-12 col-md-6">
            <div id="archivalEnds">
                <div class="job-card-header">Data Archival End Date</div>
                <div class="job-card-content" id="archivalEndText">XXXX</div>
            </div>
        </div>
    </div>

    <!-- Row 3: Decomm (2) -->
    <div class="row g-3 mb-3">
        <div class="col-12 col-md-6">
            <div id="legalCompHandle">
                <div class="job-card-header">Decom Start Date</div>
                <div class="job-card-content" id="decomStartText">XXXX</div>
            </div>
        </div>
        <div class="col-12 col-md-6">
            <div id="decomEnd">
                <div class="job-card-header">Decomm End Date</div>
                <div class="job-card-content" id="decomEndText">DD-MM-YYYY</div>
            </div>
        </div>
    </div>
    </div>
    <div class="col-sm-12">
    <!-- Row 4: Operational (3) -->
    <div class="row g-3">
        <div class="col-12 col-md-3">
            <div id="decomDays">
                <div class="job-card-header">No.of Days to Decomm</div>
                <div class="job-card-content" id="decomDaysText">XXXX</div>
            </div>
        </div>
        <div class="col-12 col-md-3">
            <div id="decomWave">
                <div class="job-card-header">Decomm Wave</div>
                <div class="job-card-content" id="decomWaveText">XXXX</div>
            </div>
        </div>
        <div class="col-12 col-md-6">
            <div id="decomSeq">
                <div class="job-card-header">Decommission Sequence</div>
                <div class="job-card-content circle" id="decomSeqText">XXXX</div>
            </div>
        </div>
    </div>
</div>

                                            <!-- <div class="col-sm-3">
                                                <div id="decomSeq">
                                                    <div class="job-card-header">Decommission Sequence</div>
                                                    <div class="circle" style="font-size: 25px;" id="decomSeqText">N</div>
                                                </div>
                                                <div id="resReq">
                                                    <div class="job-card-header">Resources required</div>
                                                    <div class="job-card-content mb-4" id="resReqText">N</div>
                                                </div>
                                            </div> -->
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include './pages/footer.php'; ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <!-- <script src="vendor/chart.js/Chart.min.js"></script> -->

    <!-- Page level custom scripts -->
    <!-- <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script> -->

   <script>
  // appData from PHP
  var appData = <?=
    json_encode($appSet, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
  ?>;

  // Flatten: appMap = { "<AppName>": [ { ..row.. } ], ... }
  var appMap = (appData && appData[0]) ? appData[0] : {};

  // Debug: make sure keys are visible in console
  console.log('appMap keys:', Object.keys(appMap));
</script>
    <script>
        // Select All 
        $('#selectAllCheck').click(function() {
            if ($("#selectAllCheck").is(':checked')) {
                $(".form-check-input").prop('checked', true);
            } else {
                $(".form-check-input").prop('checked', false);
            }
        });

        // Clear All
        $("#clearModal").click(function() {
            $(".form-check-input").prop('checked', false);
        });

        // Hiding JobCard section by default
        $('#aappGeneral').hide();

        // Show Job Card based on Criteria Selected
        $('#selJobCards').change(function() 
        {
            $('#jobCardBody').show();

            // App General Section
            if ($('#appGeneralCheck').is(':checked')) {
                $('#appGeneral').show();
            } else {
                $('#appGeneral').hide();
            }

            // Decomm Details Section
            if ($('#decommCheck').is(':checked')) {
                $('#decomm').show();
            } else {
                $('#decomm').hide();
            }

            // Condition if both aren't selected - show both
            if ($('#appGeneralCheck').is(':checked') === false && $('#decommCheck').is(':checked') === false) {
                $('#appGeneral').show();
                $('#decomm').show();
            }

            // Colour change based on Yes/No -----  to  be uncommented late ----
        //     if ($('#DataforComplianceText').text() == "No") {
        //         $('#DataforComplianceText').css('background-color', 'red');
        //     } else if ($('#DataforComplianceText').text() == "Yes") {
        //         $('#DataforComplianceText').css('background-color', 'green');
        //     }
		// 	if ($('#GapAnalysisText').text() == "No") {
        //         $('#GapAnalysisText').css('background-color', 'red');
        //     } else if ($('#GapAnalysisText').text() == "Yes") {
        //         $('#GapAnalysisText').css('background-color', 'green');
        //     }
        //     if ($('#DataMigrationText').text() == "No") {
        //         $('#DataMigrationText').css('background-color', 'red');
        //     } else if ($('#DataMigrationText').text() == "Yes") {
        //         $('#DataMigrationText').css('background-color', 'green');
        //     }
		// 	if ($('#dataArchivalText1').text() == "No") {
        //         $('#dataArchivalText1').css('background-color', 'red');
        //     } else if ($('#dataArchivalText1').text() == "Yes") {
        //         $('#dataArchivalText1').css('background-color', 'green');
        //     }
		// 	if ($('#dataMigrationText2').text() == "No") {
        //         $('#dataMigrationText2').css('background-color', 'red');
        //     } else if ($('#dataMigrationText2').text() == "Yes") {
        //         $('#dataMigrationText2').css('background-color', 'green');
        //     }
        //     if ($('#userMigrationText').text() == "No") {
        //         $('#userMigrationText').css('background-color', 'red');
        //     } else if ($('#userMigrationText').text() == "Yes") {
        //         $('#userMigrationText').css('background-color', 'green');
        //     }
        //     if ($('#switchOffText').text() == "No") {
        //         $('#switchOffText').css('background-color', 'red');
        //     } else if ($('#switchOffText').text() == "Yes") {
        //         $('#switchOffText').css('background-color', 'green');
        //     }
        //     if ($('#bigBangText').text() == "No") {
        //         $('#bigBangText').css('background-color', 'red');
        //     } else if ($('#bigBangText').text() == "Yes") {
        //         $('#bigBangText').css('background-color', 'green');
        //     }

        //     // Application active colour change
        //     if ($('#appActiveText').text() == "No") {
        //         $('#appActiveText').css('background-color', 'red');
        //     } else if ($('#appActiveText').text() == "Yes") {
        //         $('#appActiveText').css('background-color', 'green');
        //     }

        // });

        // On Clicking Save Changes, reflect the criteria selection
        $("#saveModal").click(function() {
            // App General Section
            if ($('#appGeneralCheck').is(':checked')) {
                $('#appGeneral').show();
            } else {
                $('#appGeneral').hide();
            }

            // Decomm Details Section
            if ($('#decommCheck').is(':checked')) {
                $('#decomm').show();

            } else {
                $('#decomm').hide();
            }

            // Condition if both aren't selected - show both
            if ($('#appGeneralCheck').is(':checked') === false && $('#decommCheck').is(':checked') === false) {
                $('#appGeneral').show();
                $('#decomm').show();
            }

            // Showing Toast based on selected criteria
            if ($('#appGeneralCheck').is(':checked') === true && $('#decommCheck').is(':checked') === true) {
                $('.toast-body p').text('Both criteria will be shown');
                $('.toast').toast('show');
            } else if ($('#appGeneralCheck').is(':checked') === true && $('#decommCheck').is(':checked') === false) {
                $('.toast-body p').text('Application General Criteria Selected');
                $('.toast').toast('show');
            } else if ($('#appGeneralCheck').is(':checked') === false && $('#decommCheck').is(':checked') === true) {
                $('.toast-body p').text('Decommission Details Criteria Selected');
                $('.toast').toast('show');
            }
        });
    </script>

<script>
// Shrinks element's font-size so its content fits its box (no overflow)
function fitTextToBox(el, { minSize = 10, startSize = 20, step = 1 } = {}) {
  if (!el) return;

  let size = startSize;
  el.style.fontSize = size + 'px';

  // Fits if no vertical/ horizontal overflow
  const fits = () => el.scrollHeight <= el.clientHeight && el.scrollWidth <= el.clientWidth;

  // Reduce until fits or we hit minimum
  while (!fits() && size > minSize) {
    size -= step;
    el.style.fontSize = size + 'px';
  }
}

// Runs fitTextToBox now, and re-runs when the element/parent resizes
function autoFitAppName() {
  const el = document.getElementById('appNameText');
  if (!el) return;

  // initial fit (start size should match your CSS)
  fitTextToBox(el, { minSize: 10, startSize: 20, step: 1 });

  // observe size changes so it stays correct on layout changes
  if (window.ResizeObserver) {
    const ro = new ResizeObserver(() => {
      fitTextToBox(el, { minSize: 10, startSize: 20, step: 1 });
    });
    ro.observe(el);

    const col = document.getElementById('appName');
    if (col) ro.observe(col);
  }
}
</script>
    <!-- Scripts For download  -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>
    <script type="text/javascript" src="https://html2canvas.hertzen.com/dist/html2canvas.js"></script>

    <script>
        //download
        function CreatePDFfromHTML() {
            var app = $("#selJobCards").val();
            var HTML_Width = $(".html-content").width();
            var HTML_Height = $(".html-content").height();
            var top_left_margin = 40;
            var PDF_Width = HTML_Width + (top_left_margin * 2);
            var PDF_Height = (PDF_Width * 1.5) + (top_left_margin * 2);
            var canvas_image_width = HTML_Width;
            var canvas_image_height = HTML_Height;

            var totalPDFPages = Math.ceil(HTML_Height / PDF_Height) - 1;

            html2canvas($(".html-content")[0]).then(function(canvas) {
                var imgData = canvas.toDataURL("image/jpeg", 1.0);
                var pdf = new jsPDF('p', 'pt', [PDF_Width, PDF_Height]);
                   // Add application name as text at the top
                   // Set font and style
        pdf.setFont("helvetica", "bold");
        pdf.setFontSize(16);

        // Prepare text
        var text = "Application: " + app;
        var textWidth = pdf.getTextWidth(text);
        var xPosition = (PDF_Width - textWidth) / 2;
        var yPosition = top_left_margin + 20;

        // Add centered text at the top
        pdf.text(text, xPosition, yPosition);

        // Add image below the text
        var imageYPosition = yPosition + 10; // slight spacing below text
        pdf.addImage(imgData, 'JPG', top_left_margin, imageYPosition, canvas_image_width, canvas_image_height);

                for (var i = 1; i <= totalPDFPages; i++) {
                    pdf.addPage(PDF_Width, PDF_Height);
                    pdf.addImage(imgData, 'JPG', top_left_margin, -(PDF_Height * i) + (top_left_margin * 4), canvas_image_width, canvas_image_height);
                }

                pdf.save(app + ".pdf");
                //$(".html-content").hide();
            });
        }

        //addPage: To add a new page to PDF, addPage is used.
        //jsPDF -> p=portrait; l=landscape; pt/mm/cm/in = Units
        /*  addImage will write image to pdf and convert images to Base64. Following parameters are required to add an image. 
        			addImage(imageData, format, x, y, width, height);				
        			
        			imageData: Pass image
        			format: extension of image
        			x-axis: position of image from left
        			y-axis: position of image from top
        			width: width of image
        			height: height of image
        		*/
    </script>
    
  <script>
  $('#selJobCards').on('change', function () {
    // Use the exact key we emitted
    var selectedKey = $('#selJobCards option:selected').data('key');

    // Debug: confirm selected value and presence in appMap
    console.log('Selected key:', JSON.stringify(selectedKey));
    console.log('Has key?', Object.prototype.hasOwnProperty.call(appMap, selectedKey));

    // Show container
    $('#jobCardBody').show();

    if (!selectedKey || !appMap[selectedKey] || !appMap[selectedKey][0]) {
      console.warn('No record found for:', selectedKey);
      return;
    }

    var row = appMap[selectedKey][0];

    // Populate fields
    $('#appNameText').text(row['Application Name'] || '');
    autoFitAppName();
    $('#appCategoryText').text(row['Application Category'] || '');
    $('#appSuiteText').text(row['Application Suite'] || '');
     $('#appOwnerText').text(row['Application Ownership'] || '');
$('#techStackText').text(row['Technology Stack'] || '');
 $('#appStatusText').text(row['Application Status'] || '');
  $('#busCriticalityText').text(row['Business Criticality'] || '');

    $('#lobText').text(row['Line of Business'] || '');
    
    $('#appFuncText').text(row['Application Functionality'] || '');
   
   
    $('#costText').text(row['Cost'] || '');
   
    $('#DataforComplianceText').text(row['Data for Compliance'] || '');
    $('#GapAnalysisText').text(row['GapAnalysis'] || '');
    $('#DataMigrationText').text(row['DataMigration'] || '');
    $('#dataArchivalText1').text(row['DataArchival'] || '');
    $('#dataMigrationText2').text(row['Data Migration2'] || '');
    $('#userMigrationText').text(row['User Migration'] || '');
    $('#switchOffText').text(row['Switch-Off'] || '');
    $('#bigBangText').text(row['Big Bang'] || '');

 $('#POAReadinessText').text(row['POA Ready'] || '');
  $('#pointOfArrivalText').text(row['Point Of Arrival'] || '');
   $('#decomDaysText').text(row['Total no of days to decommission'] || '');
   $('#decomStartText').text(row['Decommission Start Date'] || '');
    $('#decomEndText').text(row['Decommission End Date'] || '');
     $('#decomWaveText').text(row['Decommission Wave'] || '');

     $('#archivalStartText').text(row['Data Archival Start Date'] || '');
    $('#archivalEndText').text(row['Data Archival End Date'] || '');
    $('#decomSeqText').text(row['Decommission Sequence'] || '');


    $('#docLevelText').text(row['Level of Documentation'] || '');
   
    $('#resReqText').text(row['Resources Required to Decommission'] || '');
    $('#supLevelText').text(row['Support Level'] || '');
    $('#ageText').text(row['Age of Application'] || '');
   
    $('#legalCompHandleText').text(row['Legal Compliance Handled'] || '');
  });

</script>

</body>

</html>
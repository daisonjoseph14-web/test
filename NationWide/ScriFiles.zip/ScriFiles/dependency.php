<?php
error_reporting(E_ALL);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
$_SESSION['currentPage'] = 'dependency'; // <-- set to this page’s key before including sidebar
?>

<?php
require '/var/www/html/vendor/autoload.php';

$m = new MongoDB\Client("mongodb://127.0.0.1/");
$db = $m->nationWide;

?>
<?php
$incomingNodes = [];

foreach ($incomingCol->find() as $doc) {
    $from = (string)$doc['Incoming_App_Name'];
    $to   = (string)$doc['App_Name'];
    $suite = (string)$doc['Suite'];

    if ($from === '' || $to === '') continue;

    ensureNode($incomingNodes, $from, $suite);
    ensureNode($incomingNodes, $to, $suite);

    $incomingNodes[$from]['linkWith'][] = $to;
}
foreach ($incomingNodes as &$n) {
    $n['linkWith'] = array_values(array_unique($n['linkWith']));
    $n['value'] = max(1, count($n['linkWith']));
}

$incomingGraphData = json_encode(array_values($incomingNodes));

$outgoingNodes = [];

foreach ($outgoingCol->find() as $doc) {
    $from = (string)$doc['App_Name'];
    $to   = (string)$doc['Outgoing_App_Name'];
    $suite = (string)$doc['Suite'];

    if ($from === '' || $to === '') continue;

    ensureNode($outgoingNodes, $from, $suite);
    ensureNode($outgoingNodes, $to, $suite);

    $outgoingNodes[$from]['linkWith'][] = $to;
}

foreach ($outgoingNodes as &$na) {
    $na['linkWith'] = array_values(array_unique($na['linkWith']));
    $na['value'] = max(1, count($na['linkWith']));
}

$incomingGraphData = json_encode(array_values($incomingNodes));


$incomingCol = $db->Incoming;
$outgoingCol = $db->Outgoing;

$nodes = [];
$links = [];

$suiteSet = [];
$appSet = [];

/* Helper to ensure nodes exist */
function ensureNode(&$nodes, $id, $suite = null) {
    if (!isset($nodes[$id])) {
        $nodes[$id] = [
            "id" => $id,
            "value" => 0,
            "linkWith" => [],
            "suite" => $suite
        ];
    }
}
``

/* ✅ INCOMING: Incoming_App_Name → App_Name */
foreach ($incomingCol->find() as $doc) {
    $from = (string)$doc['Incoming_App_Name'];
    $to   = (string)$doc['App_Name'];
    $suite = (string)$doc['Suite'];

    if ($from === '' || $to === '') continue;

  ensureNode($nodes, $from, $suite);
ensureNode($nodes, $to, $suite);

    $nodes[$from]['linkWith'][] = $to;

    $suiteSet[$suite] = true;
    $appSet[$to] = true;
}

/* ✅ OUTGOING: App_Name → Outgoing_App_Name */
foreach ($outgoingCol->find() as $doc) {
    $from = (string)$doc['App_Name'];
    $to   = (string)$doc['Outgoing_App_Name'];
    $suite = (string)$doc['Suite'];

    if ($from === '' || $to === '') continue;

    ensureNode($nodes, $from);
    ensureNode($nodes, $to);

    $nodes[$from]['linkWith'][] = $to;

    $suiteSet[$suite] = true;
    $appSet[$from] = true;
}

/* Make linkWith unique */
foreach ($nodes as &$n) {
    $n['linkWith'] = array_values(array_unique($n['linkWith']));
    $n['value'] = max(1, count($n['linkWith']));
}

/* Dropdown options */
$suiteOptions = array_keys($suiteSet);
sort($suiteOptions, SORT_NATURAL | SORT_FLAG_CASE);

$appOptions = array_keys($appSet);
sort($appOptions, SORT_NATURAL | SORT_FLAG_CASE);

/* JSON for JS */
$graphData = json_encode(array_values($nodes), JSON_UNESCAPED_UNICODE);
?>

<!-- Styles -->
<style>
#incomingChart,#outgoingChart {
    width: 100%;
    height: 100%;

}

#applyFilter {
    max-width: 250px;
}
</style>

<!-- Resources -->
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/flow.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
<script src="https://cdn.amcharts.com/lib/5/hierarchy.js"></script>
<script>
const incomingGraphData = <?= $graphData ?>;
</script>

<script>
am5.ready(function() {

  var root = am5.Root.new("incomingChart");

  root.setThemes([
    am5themes_Animated.new(root)
  ]);

  var zoomableContainer = root.container.children.push(
    am5.ZoomableContainer.new(root, {
      width: am5.p100,
      height: am5.p100,
      wheelable: true,
      pinchZoom: true
    })
  );

  zoomableContainer.children.push(
    am5.ZoomTools.new(root, { target: zoomableContainer })
  );

 var series = zoomableContainer.contents.children.push(
  am5hierarchy.ForceDirected.new(root, {
    idField: "id",
    valueField: "value",
    linkWithField: "linkWith",

    manyBodyStrength: -2,
    centerStrength: 0.4,
    nodePadding: 8,
    minRadius: 6,
    maxRadius: 22
  })
);

  series.links.template.setAll({
  strokeOpacity: 0.6,
  strength: 1
});

series.nodes.template.set("tooltipText", "{id}\nSuite: {suite}");

  /* Animated bullets on links */
  series.linkBullets.push(function(root, source, target) {
    var bullet = am5.Bullet.new(root, {
      locationX: 0.5,
      autoRotate: true,
      sprite: am5.Graphics.new(root, {
        fill: source.get("fill"),
        draw: function(display) {
          display.moveTo(0, -4);
          display.lineTo(10, 0);
          display.lineTo(0, 4);
          display.lineTo(2, 0);
          display.lineTo(0, -4);
        }
      })
    });

    bullet.animate({
      key: "locationX",
      from: 1,
      to: 0,
      duration: 1200,
      loops: Infinity
    });

    return bullet;
  });

series.nodes.template.adapters.add("fill", function(fill, target) {
  const suite = target.dataItem.dataContext.suite;
  if (suite === "PCIO") return am5.color(0x3b82f6);
  return fill;
});

  /* ✅ Set DB-driven data */
  series.data.setAll(incomingGraphData);

  series.appear(1000, 100);

});
</script>

<script>
am5.ready(function() {

// Create root element
// https://www.amcharts.com/docs/v5/getting-started/#Root_element
var root = am5.Root.new("outgoingChart");

// Set themes
// https://www.amcharts.com/docs/v5/concepts/themes/
root.setThemes([
  am5themes_Animated.new(root)
]);

var data = {
  value: 0,
  children: [
    {
      name: "Flora",
      children: [
        {
          name: "Black Tea",
          value: 1
        },
        {
          name: "Floral",
          children: [
            {
              name: "Chamomile",
              value: 1
            },
            {
              name: "Rose",
              value: 1
            },
            {
              name: "Jasmine",
              value: 1
            }
          ]
        }
      ]
    },
    {
      name: "Fruity",
      children: [
        {
          name: "Berry",
          children: [
            {
              name: "Blackberry",
              value: 1
            },
            {
              name: "Raspberry",
              value: 1
            },
            {
              name: "Blueberry",
              value: 1
            },
            {
              name: "Strawberry",
              value: 1
            }
          ]
        },
        {
          name: "Dried Fruit",
          children: [
            {
              name: "Raisin",
              value: 1
            },
            {
              name: "Prune",
              value: 1
            }
          ]
        },
        {
          name: "Other Fruit",
          children: [
            {
              name: "Coconut",
              value: 1
            },
            {
              name: "Cherry",
              value: 1
            },
            {
              name: "Pomegranate",
              value: 1
            },
            {
              name: "Pineapple",
              value: 1
            },
            {
              name: "Grape",
              value: 1
            },
            {
              name: "Apple",
              value: 1
            },
            {
              name: "Peach",
              value: 1
            },
            {
              name: "Pear",
              value: 1
            }
          ]
        },
        {
          name: "Citrus Fruit",
          children: [
            {
              name: "Grapefruit",
              value: 1
            },
            {
              name: "Orange",
              value: 1
            },
            {
              name: "Lemon",
              value: 1
            },
            {
              name: "Lime",
              value: 1
            }
          ]
        }
      ]
    },
    {
      name: "Sour/Fermented",
      children: [
        {
          name: "Sour",
          children: [
            {
              name: "Sour Aromatics",
              value: 1
            },
            {
              name: "Acetic Acid",
              value: 1
            },
            {
              name: "Butyric Acid",
              value: 1
            },
            {
              name: "Isovaleric Acid",
              value: 1
            },
            {
              name: "Citric Acid",
              value: 1
            },
            {
              name: "Malic Acid",
              value: 1
            }
          ]
        },
        {
          name: "Alcohol/Fremented",
          children: [
            {
              name: "Winey",
              value: 1
            },
            {
              name: "Whiskey",
              value: 1
            },
            {
              name: "Fremented",
              value: 1
            },
            {
              name: "Overripe",
              value: 1
            }
          ]
        }
      ]
    },
    {
      name: "Green/Vegetative",
      children: [
        {
          name: "Olive Oil",
          value: 1
        },
        {
          name: "Raw",
          value: 1
        },
        {
          name: "Green/Vegetative",
          children: [
            {
              name: "Under-ripe",
              value: 1
            },
            {
              name: "Peapod",
              value: 1
            },
            {
              name: "Fresh",
              value: 1
            },
            {
              name: "Dark Green",
              value: 1
            },
            {
              name: "Vegetative",
              value: 1
            },
            {
              name: "Hay-like",
              value: 1
            },
            {
              name: "Herb-like",
              value: 1
            }
          ]
        },
        {
          name: "Beany",
          value: 1
        }
      ]
    },
    {
      name: "Other",
      children: [
        {
          name: "Papery/Musty",
          children: [
            {
              name: "Stale",
              value: 1
            },
            {
              name: "Cardboard",
              value: 1
            },
            {
              name: "Papery",
              value: 1
            },
            {
              name: "Woody",
              value: 1
            },
            {
              name: "Moldy/Damp",
              value: 1
            },
            {
              name: "Musty/Dusty",
              value: 1
            },
            {
              name: "Musty/Earthy",
              value: 1
            },
            {
              name: "Animalic",
              value: 1
            },
            {
              name: "Meaty Brothy",
              value: 1
            },
            {
              name: "Phenolic",
              value: 1
            }
          ]
        },
        {
          name: "Chemical",
          children: [
            {
              name: "Bitter",
              value: 1
            },
            {
              name: "Salty",
              value: 1
            },
            {
              name: "Medicinal",
              value: 1
            },
            {
              name: "Petroleum",
              value: 1
            },
            {
              name: "Skunky",
              value: 1
            },
            {
              name: "Rubber",
              value: 1
            }
          ]
        }
      ]
    },
    {
      name: "Roasted",
      children: [
        {
          name: "Pipe Tobacco",
          value: 1
        },
        {
          name: "Tobacco",
          value: 1
        },
        {
          name: "Burnt",
          children: [
            {
              name: "Acrid",
              value: 1
            },
            {
              name: "Ashy",
              value: 1
            },
            {
              name: "Smoky",
              value: 1
            },
            {
              name: "Brown, Roast",
              value: 1
            }
          ]
        },
        {
          name: "Cereal",
          children: [
            {
              name: "Grain",
              value: 1
            },
            {
              name: "Malt",
              value: 1
            }
          ]
        }
      ]
    },
    {
      name: "Spices",
      children: [
        {
          name: "Pungent",
          value: 1
        },
        {
          name: "Pepper",
          value: 1
        },
        {
          name: "Brown Spice",
          children: [
            {
              name: "Anise",
              value: 1
            },
            {
              name: "Nutmeg",
              value: 1
            },
            {
              name: "Cinnamon",
              value: 1
            },
            {
              name: "Clove",
              value: 1
            }
          ]
        }
      ]
    },
    {
      name: "Nutty/Cocoa",
      children: [
        {
          name: "Nutty",
          children: [
            {
              name: "Peanuts",
              value: 1
            },
            {
              name: "Hazelnut",
              value: 1
            },
            {
              name: "Almond",
              value: 1
            }
          ]
        },
        {
          name: "Cocoa",
          children: [
            {
              name: "Chocolate",
              value: 1
            },
            {
              name: "Dark Chocolate",
              value: 1
            }
          ]
        }
      ]
    },
    {
      name: "Sweet",
      children: [
        {
          name: "Brown Sugar",
          children: [
            {
              name: "Molasses",
              value: 1
            },
            {
              name: "Maple Syrup",
              value: 1
            },
            {
              name: "Caramelized",
              value: 1
            },
            {
              name: "Honey",
              value: 1
            }
          ]
        },
        {
          name: "Vanilla",
          value: 1
        },
        {
          name: "Vanillin",
          value: 1
        },
        {
          name: "Overall Sweet",
          value: 1
        },
        {
          name: "Sweet Aromatics",
          value: 1
        }
      ]
    }
  ]
};

// Create wrapper container
var container = root.container.children.push(am5.Container.new(root, {
  width: am5.percent(100),
  height: am5.percent(100),
  layout: root.verticalLayout
}));

// Create series
// https://www.amcharts.com/docs/v5/charts/hierarchy/#Adding
var series = container.children.push(am5hierarchy.ForceDirected.new(root, {
  singleBranchOnly: false,
  downDepth: 2,
  topDepth: 1,
  initialDepth: 1,
  valueField: "value",
  categoryField: "name",
  childDataField: "children",
  idField: "name",
  linkWithField: "linkWith",
  manyBodyStrength: -10,
  centerStrength: 0.8
}));

series.get("colors").setAll({
  step: 2
});

series.links.template.set("strength", 0.5);

series.data.setAll([data]);

series.set("selectedDataItem", series.dataItems[0]);


// Make stuff animate on load
series.appear(1000, 100);

}); // end am5.ready()
</script>


<!-- HTML -->
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Decommission Analyzer - Dependency Chart</title>
    <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/custom-style.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- DataTables JS (place after jQuery) -->
    <link href="vendor/datatables/jquery.dataTables.min.js" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.js" rel="stylesheet">

    <style>
    #chartDiv,
    #chartdiv {
        height: 575px;
    }

    /* Smaller, tighter tables */
    .table.table-sm,
    .table-sm th,
    .table-sm td {
        font-size: 12px;
        /* 11–13px range works well */
        line-height: 1.1;
        /* reduce vertical spacing */
        padding: .35rem .5rem;
    }

    /* Optional: wrap long text and allow column width to adjust */
    table.dataTable tbody td {
        white-space: nowrap;
        /* set to normal to wrap; keep nowrap to reduce height */
        text-overflow: ellipsis;
        /* visually indicates truncation */
        overflow: hidden;
        max-width: 320px;
        /* keep huge names under control */
    }

    /* Make header a bit compact too */
    table.dataTable thead th {
        font-size: 12px;
    }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include './pages/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include './pages/navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <!-- <h1 class="h3 mb-0 text-gray-800">Dependency Chart</h1> -->
                    </div>

                    <!-- Content Row -->



                    <div class="row">
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Dependency Chart for all apps
                                    </h6> <!-- Suite Filter -->
                                    <div class="d-flex align-items-center">
                                        <label for="suiteFilter" class="mr-2 mb-0 text-muted"
                                            style="font-size:0.9rem;">App Suite</label>
                                        <select id="suiteFilter" class="form-control form-control-sm">
                                            <option value="Both" selected>Both</option>
                                            <?php foreach ($suiteOptions as $suite): ?>
                                            <option value="<?= htmlspecialchars($suite, ENT_QUOTES, 'UTF-8') ?>">
                                                <?= htmlspecialchars($suite, ENT_QUOTES, 'UTF-8') ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <label for="appFilter" class="mr-2 mb-0 text-muted"
                                            style="font-size:0.9rem;">Application</label>
                                        <select id="appFilter" class="form-control form-control-sm">
                                            <option value="All" selected>All</option>
                                            <?php foreach ($appOptions as $app): ?>
                                            <option><?= htmlspecialchars($app, ENT_QUOTES, 'UTF-8') ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <!-- Card Body -->
                            <div class="card-body">
                                <div id="chartDiv" class="chart-area">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <h6 class="text-primary font-weight-bold mb-2">Incoming Interfaces</h6>
                                            <div id="incomingChart" style="height:600px;"></div>
                                        </div>

                                        <div class="col-lg-12">
                                            <h6 class="text-primary font-weight-bold mb-2">Outgoing Interfaces</h6>
                                            <div id="outgoingChart" style="height:600px;"></div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <?php include './pages/footer.php'; ?>
</body>

</html>
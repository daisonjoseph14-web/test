<?php
// Basic web test using the low-level driver (no Composer library needed)
if (!extension_loaded('mongodb')) {
    echo "<p><strong>ERROR:</strong> PHP extension 'mongodb' not loaded.</p>";
    phpinfo(INFO_MODULES);
    exit;
}

try {
    $manager = new MongoDB\Driver\Manager("mongodb://localhost:27017");

    // Ping
    $cursor = $manager->executeCommand('admin', new MongoDB\Driver\Command(['ping' => 1]));
    $result = current($cursor->toArray());

    echo "<h3>Ping Result</h3><pre>" . htmlspecialchars(json_encode($result, JSON_PRETTY_PRINT)) . "</pre>";

    // List databases
    $dbs = $manager->executeCommand('admin', new MongoDB\Driver\Command(['listDatabases' => 1]));
    $dbsResult = current($dbs->toArray());
    echo "<h3>Databases</h3><ul>";
    foreach ($dbsResult->databases ?? [] as $db) {
        echo "<li>" . htmlspecialchars($db->name) . "</li>";
    }
    echo "</ul>";

    echo "<p>Low-level web test completed successfully.</p>";
} catch (Throwable $e) {
    echo "<p><strong>MongoDB test failed:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
}
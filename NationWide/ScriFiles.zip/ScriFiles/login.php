<?php
session_start();
session_destroy();

date_default_timezone_set("Asia/Calcutta");
ob_start();
session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Decommission Analyzer</title>
    <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/custom-style.css" rel="stylesheet">

</head>

<body class="bg-decomm">

    <div class="container" style="opacity: 0.87">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg mb-5" style="margin-top: 7rem;">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row mt-2">
                            <div class="col-lg-6 d-none d-lg-block" style="text-align: center; margin-top: 60px;">
                                <img src="./img/logo3.png" alt="" style="width: auto; height: 75px; margin-bottom: 2rem;">
                                <h1>CAP360</h1>
                                <h1>DECOMMISSION</h1>
                                <h1>ANALYZER</h1>
                            </div>
                            <div class="col-lg-6 mt-5">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Welcome!</h1>
                                    </div>
                                    <form class="user" action="./pages/auth/loginHandler.php" method="post">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" name="inputUserId" aria-describedby="emailHelp" placeholder="Enter User ID">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control form-control-user" name="inputPassword" placeholder="Password">
                                        </div>
                                        <!-- <div class="form-group">
                                            <div class="custom-control custom-checkbox small">
                                                <input type="checkbox" class="custom-control-input" id="customCheck">
                                                <label class="custom-control-label" for="customCheck">Remember
                                                    Me</label>
                                            </div>
                                        </div> -->
                                        <!-- <a href="index.html" class="btn btn-primary btn-user btn-block">
                                            Login
                                        </a> -->
                                        <button type="submit" class="btn btn-primary btn-user btn-block">Login</button>
                                        <!-- <hr>
                                        <a href="index.html" class="btn btn-google btn-user btn-block">
                                            <i class="fab fa-google fa-fw"></i> Login with Google
                                        </a>
                                        <a href="index.html" class="btn btn-facebook btn-user btn-block">
                                            <i class="fab fa-facebook-f fa-fw"></i> Login with Facebook
                                        </a> -->
                                    </form>
                                    <!-- <hr>
                                    <div class="text-center">
                                        <a class="small" href="forgot-password.html">Forgot Password?</a>
                                    </div>
                                    <div class="text-center">
                                        <a class="small" href="register.html">Create an Account!</a>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr style="margin: 10px 46px 0px 50px;">
                    <div class="bg-blue py-4">
                        <div class="row px-3"> <small class="mb-2 col-md-12 text-center">Copyright &copy;
                                <?php echo date("Y"); ?>&nbsp;All rights reserved.
                            </small><br>
                            <small class="mb-2 col-md-12 text-center">
                                Legacy Revitalization, <a href="https://www.capgemini.com/in-en/">Capgemini.</a>
                            </small>
                        </div>
                    </div>
                    <!-- <div class="bg-blue py-4">
                        <div class="row px-3"> <small class="ml-4 ml-sm-5 mb-2">Copyright &copy;
                                <?php echo date("Y"); ?>.<a href="https://www.capgemini.com/in-en/">Capgemini</a>
                                All rights reserved. Legacy Revitalization</small>
                        </div>
                    </div> -->
                </div>

            </div>

        </div>

    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>
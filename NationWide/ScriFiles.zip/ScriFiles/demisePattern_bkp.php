<?php
require '/var/www/html/vendor/autoload.php';
$m= new MongoDB\Client("mongodb://127.0.0.1/");
$db = $m->nationWide;
$collection = $db->pattern;

?>
<!-- Styles -->
<style>
#chartdiv {
  width: 100%;
  height: 1200px !important;
}
</style>

<!-- Resources -->
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/flow.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>

<!-- Chart code -->
<script>
am5.ready(function() {

// Create root element
// https://www.amcharts.com/docs/v5/getting-started/#Root_element
var root = am5.Root.new("chartdiv");


// Set themes
// https://www.amcharts.com/docs/v5/concepts/themes/
root.setThemes([
  am5themes_Animated.new(root)
]);


// Create series
// https://www.amcharts.com/docs/v5/charts/flow-charts/
var series = root.container.children.push(am5flow.Sankey.new(root, {
  sourceIdField: "from",
  targetIdField: "to",
  valueField: "value",
  paddingRight: 50
}));

series.nodes.get("colors").set("step", 2);


// Set data
// https://www.amcharts.com/docs/v5/charts/flow-charts/#Setting_data
series.data.setAll([
 <?php
$results = $collection->find();
foreach($results as $result)
{
  echo '{ from: "'.$result["application_name"],'", to: "',$result["Pattern"],'", value: 1 },';
}
?> 
]);


// Make stuff animate on load
series.appear(1000, 100);

}); // end am5.ready()
</script>

<!-- HTML -->
 <!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Decommission Analyzer - Demise Pattern Chart</title>
    <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/custom-style.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

    <style>
        #chartDiv,
        #chartdiv {
            height: 575px;
        }

        #balloon {
            position: absolute;
            top: 359px;
            left: 867px;
            border: 2px solid #ccc;
            background: rgba(255, 255, 255, 0.8);
            padding: 6px;
            font-size: 10px;
            color: #000;
            margin: 40px 0 0 20px;
        }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include './pages/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include './pages/navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Demise Pattern Charts</h1>
                    </div>

                    <!-- Content Row -->
                   


                    <div class="row">
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Demise Pattern Data for all apps.
                                    </h6>
                                    <!-- LOB Select Dropdown -->
                                    <!--   <div class="dropdown no-arrow">
                                        <!-- <select class="form-control" name="lob" id="selLob">
                                            <option selected disabled>Choose LOB</option>
                                            <?php
                                            //sort($lobs);
                                           // foreach ($lobs as $lob) {
                                             //   if ($lob == "") continue;
                                            //?>
                                                <option><?php //echo $lob; ?></option>
                                            <?php
                                            //}
                                            ?>
                                        </select> 
                                    </div>-->
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <div id="chartDiv" class="chart-area">
                                        <div id="chartdiv"></div>
                                        <div id="balloon"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                  


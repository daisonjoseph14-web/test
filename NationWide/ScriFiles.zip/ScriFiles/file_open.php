<?php
// file_open.php (hardened)
$csvPath = __DIR__ . "/data/CSV/NW_data.csv";
$results = [];

if (!is_readable($csvPath)) {
    error_log("file_open.php: CSV not readable: {$csvPath}");
    // Optionally: throw new RuntimeException("CSV not readable");
    return;
}

$fopen = @fopen($csvPath, "r");
if ($fopen === false) {
    error_log("file_open.php: fopen failed for {$csvPath}");
    return;
}

// Read header
$header = fgetcsv($fopen);
if ($header === false || !is_array($header)) {
    error_log("file_open.php: Failed to read header row from {$csvPath}");
    fclose($fopen);
    return;
}

// Normalize header: trim cells and strip BOM from first cell if present
$header = array_map(function($h) {
    // Handle nulls from malformed CSV
    $h = (string)($h ?? '');
    // Remove BOM if present (UTF-8)
    $h = preg_replace('/^\xEF\xBB\xBF/', '', $h);
    return trim($h);
}, $header);

// Ensure we have the key we expect
if (!in_array('application_name', $header, true)) {
    error_log("file_open.php: 'application_name' column missing in header: [" . implode(',', $header) . "]");
    // You can choose to return here or proceed with a fallback
    // return;
}

$rowNum = 1; // header consumed
while (($row = fgetcsv($fopen)) !== false) {
    $rowNum++;

    // Skip empty lines
    if ($row === null || $row === [] || (count($row) === 1 && trim((string)$row[0]) === '')) {
        continue;
    }

    // Ensure row is array of strings
    $row = array_map(function($v) {
        return is_null($v) ? '' : (string)$v;
    }, $row);

    // Basic sanity check: column count should match
    if (count($row) !== count($header)) {
        // You may choose to pad/trim instead of skipping:
        // $row = array_pad($row, count($header), '');
        // or:
        error_log("file_open.php: Column mismatch at row {$rowNum}. Expected ".count($header)." got ".count($row).". Skipping row.");
        continue;
    }

    $row_array = @array_combine($header, $row);
    if ($row_array === false) {
        error_log("file_open.php: array_combine failed at row {$rowNum}. Skipping row.");
        continue;
    }

    // Only process non-empty first column (mirroring your original intent)
    // But make it safer by checking index existence via header lookup
    $firstHeader = $header[0] ?? null;
    if ($firstHeader === null) {
        error_log("file_open.php: first header column missing at runtime");
        continue;
    }
    if (trim($row_array[$firstHeader]) === '') {
        continue;
    }

    // Use application_name as key if present and non-empty
    $key = $row_array['application_name'] ?? '';
    if ($key === '') {
        // Option: fall back to a synthetic key or skip
        error_log("file_open.php: Missing application_name at row {$rowNum}. Skipping row.");
        continue;
    }

    $results[$key] = $row_array;
}

fclose($fopen);

// Optionally expose $results as a return value if this file is included
// return $results;

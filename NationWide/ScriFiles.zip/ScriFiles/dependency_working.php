<?php
error_reporting(E_ALL);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
$_SESSION['currentPage'] = 'dependency'; // <-- set to this page’s key before including sidebar
?>

<?php
require '/var/www/html/vendor/autoload.php';
$m= new MongoDB\Client("mongodb://127.0.0.1/");
$db = $m->nationWide;
$collection = $db->dependency;
$collection1 = $db->Incoming;
$collection2 = $db->Outgoing;
// Pull everything you need and encode safely as JSON
$cursor = $collection->find([], ['projection' => ['Source'=>1,'Target'=>1,'Suite'=>1]]);
$data = [];
foreach ($cursor as $doc) {
    // normalize to strings and keep Suite
    $data[] = [
        'from'  => isset($doc['Source']) ? (string)$doc['Source'] : '',
        'to'    => isset($doc['Target']) ? (string)$doc['Target'] : '',
        'suite' => isset($doc['Suite'])  ? (string)$doc['Suite']  : '',
        'value' => 1  // one link per record; you can aggregate later if needed
    ];
}
// This will be embedded into JS below:
$jsonData = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
?>
<?php
// --- Application filter options (distinct Source values) ---
$appOptions = [];
try {
    $raw = $collection->distinct('Source');
    // normalize to strings, trim, drop empties
    foreach ($raw as $v) {
        $name = trim((string)$v);
        if ($name !== '') $appOptions[$name] = true;
    }
    // back to sorted list (natural order, case-insensitive)
    $appOptions = array_keys($appOptions);
    natcasesort($appOptions);
    $appOptions = array_values($appOptions);
} catch (Throwable $e) {
    $appOptions = [];
}
?>
<?php
// --- Incoming table data ---
$incomingRows = [];
try {
    $incomingCursor = $collection1->find(
        [],
        [
            'projection' => [
                'From Application ID'   => 1,
                'From Application Name( AH Column from Questionnaire )' => 1,
                'Interface Type( AJ Column from Questionnaire)'        => 1,
                'To Application Name'   => 1
            ],
            'sort' => ['From Application Name( AH Column from Questionnaire )' => 1] // optional: sort nicely
        ]
    );
    foreach ($incomingCursor as $doc) {
        $incomingRows[] = [
            'id'         => isset($doc['From Application ID'])   ? (string)$doc['From Application ID']   : '',
            'name'       => isset($doc['From Application Name( AH Column from Questionnaire )']) ? (string)$doc['From Application Name( AH Column from Questionnaire )'] : '',
            'type'       => isset($doc['Interface Type( AJ Column from Questionnaire)'])        ? (string)$doc['Interface Type( AJ Column from Questionnaire)']        : '',
            'targetName' => isset($doc['To Application Name'])   ? (string)$doc['To Application Name']   : '',
        ];
    }
} catch (Throwable $e) {
    // Log if you want, but keep UI running
    $incomingRows = [];
}

// --- Outgoing table data ---
$outgoingRows = [];
try {
    $outgoingCursor = $collection2->find(
        [],
        [
            'projection' => [
                'From Application ID'   => 1,
                'From Application Name' => 1,
                'Interface Type'        => 1,
                'Outgoing App Name'   => 1
            ],
            'sort' => ['From Application Name' => 1]
        ]
    );
    foreach ($outgoingCursor as $doc) {
        $outgoingRows[] = [
            'id'         => isset($doc['From Application ID'])   ? (string)$doc['From Application ID']   : '',
            'name'       => isset($doc['From Application Name']) ? (string)$doc['From Application Name'] : '',
            'type'       => isset($doc['Interface Type'])        ? (string)$doc['Interface Type']        : '',
            'targetName' => isset($doc['Outgoing App Name'])   ? (string)$doc['Outgoing App Name']   : '',
        ];
    }
} catch (Throwable $e) {
    $outgoingRows = [];
}
?>
<?php
// --- Suite filter options (distinct Suite values) ---
$suiteOptions = [];
try {
    $rawSuites = $collection->distinct('Suite');
    foreach ($rawSuites as $s) {
        $suite = trim((string)$s);
        if ($suite !== '') $suiteOptions[$suite] = true;
    }
    $suiteOptions = array_keys($suiteOptions);
    natcasesort($suiteOptions);
    $suiteOptions = array_values($suiteOptions);
} catch (Throwable $e) {
    $suiteOptions = [];
}
?>

<!-- Styles -->
<style>
#chartdiv {
    width: 100%;
    height: 1000px !important;

}

#applyFilter {
    max-width: 250px;
}
</style>

<!-- Resources -->
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/flow.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>

<script>
am5.ready(function() {
    // 1) Input data from PHP: [{ from, to, suite, value }]
    const allLinks = <?php echo $jsonData ?: '[]'; ?>;

    // 2) Boot amCharts v5
    var root = am5.Root.new("chartdiv");
    root.setThemes([am5themes_Animated.new(root)]);

    // 3) Directed chord series
    var series = root.container.children.push(am5flow.ChordDirected.new(root, {
        startAngle: 80,
        padAngle: 1,
        linkHeadRadius: undefined,
        sourceIdField: "from",
        targetIdField: "to",
        valueField: "value"
    }));
    series.nodes.labels.template.setAll({
        textType: "radial",
        centerX: 0,
        fontSize: 9
    });
    series.links.template.set("fillStyle", "source");
    // Put the chart a bit inward so outer labels don't clip the card edges
    series.setAll({
        // The defaults are fine, but if labels clip the container edges, reduce the radius a little:
        radius: am5.percent(70), // 95% of the min(containerWidth, containerHeight) / 2
        innerRadius: am5.percent(20)
    });
    // Build application options based on selected suite
    function populateAppDropdown(selectedSuite) {
        const appSel = document.getElementById("appFilter");

        // Clear existing options
        appSel.innerHTML = '<option value="All">All</option>';

        // Filter data by suite (if not Both)
        let filtered = allLinks;
        if (selectedSuite && selectedSuite !== "Both") {
            filtered = allLinks.filter(d =>
                (d.suite || '').toUpperCase() === selectedSuite.toUpperCase()
            );
        }

        // Get unique application names (Source)
        const apps = [...new Set(filtered.map(d => d.from).filter(Boolean))];
        apps.sort((a, b) => a.localeCompare(b));

        // Populate dropdown
        apps.forEach(app => {
            const opt = document.createElement("option");
            opt.value = app;
            opt.textContent = app;
            appSel.appendChild(opt);
        });
    }
    // 4) Filter helper: Suite + Application
    function applyFilter(suiteValue, appValue) {
        let filtered = allLinks;

        // Suite filter: Both -> no filtering, else match suite (case-insensitive)
        if (suiteValue && suiteValue !== "Both") {
            const s = suiteValue.toUpperCase();
            filtered = filtered.filter(d => (d.suite || '').toUpperCase() === s);
        }

        // Application filter: All -> no filtering, else only those with matching Source
        if (appValue && appValue !== "All") {
            filtered = filtered.filter(d => (d.from || '') === appValue);
            // If you want BOTH outgoing + incoming for the app, replace the line above with:
            // filtered = filtered.filter(d => d.from === appValue || d.to === appValue);
        }

        series.data.setAll(filtered);
    }

    // 5) Initial load
    var suiteSel = document.getElementById("suiteFilter");
    var appSel = document.getElementById("appFilter");
    // ✅ Initial population
    populateAppDropdown(suiteSel ? suiteSel.value : "Both");
    applyFilter(suiteSel ? suiteSel.value : "Both", "All");

    // ✅ Suite change → update app dropdown + chart
    suiteSel.addEventListener("change", function() {
        populateAppDropdown(suiteSel.value);
        applyFilter(suiteSel.value, "All");
    });

    // ✅ App change → filter chart
    appSel.addEventListener("change", function() {
        applyFilter(suiteSel.value, appSel.value);
    });
    applyFilter(suiteSel ? suiteSel.value : "Both", appSel ? appSel.value : "All");
    series.appear(1000, 100);

    // 6) Wire both dropdowns
    if (suiteSel) {
        suiteSel.addEventListener("change", function() {
            applyFilter(suiteSel.value, appSel ? appSel.value : "All");
        });
    }
    if (appSel) {
        appSel.addEventListener("change", function() {
            applyFilter(suiteSel ? suiteSel.value : "Both", appSel.value);
        });
    }
});
</script>

<!-- HTML -->
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Decommission Analyzer - Dependency Chart</title>
    <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/custom-style.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- DataTables JS (place after jQuery) -->
    <link href="vendor/datatables/jquery.dataTables.min.js" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.js" rel="stylesheet">

    <style>
    #chartDiv,
    #chartdiv {
        height: 575px;
    }

    #balloon {
        position: absolute;
        top: 359px;
        left: 867px;
        border: 2px solid #ccc;
        background: rgba(255, 255, 255, 0.8);
        padding: 6px;
        font-size: 10px;
        color: #000;
        margin: 40px 0 0 20px;
    }

    /* Smaller, tighter tables */
    .table.table-sm,
    .table-sm th,
    .table-sm td {
        font-size: 12px;
        /* 11–13px range works well */
        line-height: 1.1;
        /* reduce vertical spacing */
        padding: .35rem .5rem;
    }

    /* Optional: wrap long text and allow column width to adjust */
    table.dataTable tbody td {
        white-space: nowrap;
        /* set to normal to wrap; keep nowrap to reduce height */
        text-overflow: ellipsis;
        /* visually indicates truncation */
        overflow: hidden;
        max-width: 320px;
        /* keep huge names under control */
    }

    /* Make header a bit compact too */
    table.dataTable thead th {
        font-size: 12px;
    }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include './pages/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include './pages/navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <!-- <h1 class="h3 mb-0 text-gray-800">Dependency Chart</h1> -->
                    </div>

                    <!-- Content Row -->



                    <div class="row">
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Dependency Chart for all apps
                                    </h6> <!-- Suite Filter -->
                                    <div class="d-flex align-items-center">
                                        <label for="suiteFilter" class="mr-2 mb-0 text-muted"
                                            style="font-size:0.9rem;">App Suite</label>
                                        <select id="suiteFilter" class="form-control form-control-sm">
                                            <option value="Both" selected>Both</option>
                                            <?php foreach ($suiteOptions as $suite): ?>
                                            <option value="<?= htmlspecialchars($suite, ENT_QUOTES, 'UTF-8') ?>">
                                                <?= htmlspecialchars($suite, ENT_QUOTES, 'UTF-8') ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <label for="appFilter" class="mr-2 mb-0 text-muted"
                                            style="font-size:0.9rem;">Application</label>
                                        <select id="appFilter" class="form-control form-control-sm">
                                            <option value="All" selected>All</option>
                                            <?php foreach ($appOptions as $app): ?>
                                            <option><?= htmlspecialchars($app, ENT_QUOTES, 'UTF-8') ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <!-- Card Body -->
                            <div class="card-body">
                                <div id="chartDiv" class="chart-area">
                                    <div id="chartdiv"></div>
                                    <div id="balloon"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
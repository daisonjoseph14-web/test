<?php
error_reporting(E_ALL);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
$_SESSION['currentPage'] = 'dependency'; // <-- set to this page’s key before including sidebar
?>

<?php
require '/var/www/html/vendor/autoload.php';
$m= new MongoDB\Client("mongodb://127.0.0.1/");
$db = $m->nationWide;
$collection = $db->dependency;
$collection1 = $db->Incoming;
$collection2 = $db->Outgoing; 
$raw = $collection->distinct('Source');
$data = [];
foreach ($raw as $v) {


// Pull everything you need and encode safely as JSON
$cursor = $collection->find(['Source'=>$v], ['projection' => ['Source'=>1,'Target'=>1,'Suite'=>1]]);

$data[$v] = [];
$data[$v]["chart1"] = [];
$data[$v]["chart2"] = [];

foreach ($cursor as $doc) {
    // normalize to strings and keep Suite
    $data[$v]["chart1"][] = [
        'from'  => isset($doc['Source']) ? (string)$doc['Source'] : '',
        'to'    => isset($doc['Target']) ? (string)$doc['Target'] : '',
        'suite' => isset($doc['Suite'])  ? (string)$doc['Suite']  : '',
        'value' => 1  // one link per record; you can aggregate later if needed
    ];
}
$cursor = $collection->find(['Target'=>$v], ['projection' => ['Source'=>1,'Target'=>1,'Suite'=>1]]);
foreach ($cursor as $doc) {
    // normalize to strings and keep Suite
    $data[$v]["chart2"][] = [
        'from'  => isset($doc['Source']) ? (string)$doc['Source'] : '',
        'to'    => isset($doc['Target']) ? (string)$doc['Target'] : '',
        'suite' => isset($doc['Suite'])  ? (string)$doc['Suite']  : '',
        'value' => 1  // one link per record; you can aggregate later if needed
    ];
}
}
// This will be embedded into JS below:
$jsonData = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
?>
<?php
// --- Application filter options (distinct Source values) ---
$appOptions = [];
try {
    $raw = $collection->distinct('Source');
    // normalize to strings, trim, drop empties
    foreach ($raw as $v) {
        $name = trim((string)$v);
        if ($name !== '') $appOptions[$name] = true;
    }
    // back to sorted list (natural order, case-insensitive)
    $appOptions = array_keys($appOptions);
    natcasesort($appOptions);
    $appOptions = array_values($appOptions);
} catch (Throwable $e) {
    $appOptions = [];
}
?>
<?php
// --- Incoming table data ---
$incomingRows = [];
try {
    $incomingCursor = $collection1->find(
        [],
        [
            'projection' => [
                'From Application ID'   => 1,
                'From Application Name( AH Column from Questionnaire )' => 1,
                'Interface Type( AJ Column from Questionnaire)'        => 1,
                'To Application Name'   => 1
            ],
            'sort' => ['From Application Name( AH Column from Questionnaire )' => 1] // optional: sort nicely
        ]
    );
    foreach ($incomingCursor as $doc) {
        $incomingRows[] = [
            'id'         => isset($doc['From Application ID'])   ? (string)$doc['From Application ID']   : '',
            'name'       => isset($doc['From Application Name( AH Column from Questionnaire )']) ? (string)$doc['From Application Name( AH Column from Questionnaire )'] : '',
            'type'       => isset($doc['Interface Type( AJ Column from Questionnaire)'])        ? (string)$doc['Interface Type( AJ Column from Questionnaire)']        : '',
            'targetName' => isset($doc['To Application Name'])   ? (string)$doc['To Application Name']   : '',
        ];
    }
} catch (Throwable $e) {
    // Log if you want, but keep UI running
    $incomingRows = [];
}

// --- Outgoing table data ---
$outgoingRows = [];
try {
    $outgoingCursor = $collection2->find(
        [],
        [
            'projection' => [
                'From Application ID'   => 1,
                'From Application Name' => 1,
                'Interface Type'        => 1,
                'Outgoing App Name'   => 1
            ],
            'sort' => ['From Application Name' => 1]
        ]
    );
    foreach ($outgoingCursor as $doc) {
        $outgoingRows[] = [
            'id'         => isset($doc['From Application ID'])   ? (string)$doc['From Application ID']   : '',
            'name'       => isset($doc['From Application Name']) ? (string)$doc['From Application Name'] : '',
            'type'       => isset($doc['Interface Type'])        ? (string)$doc['Interface Type']        : '',
            'targetName' => isset($doc['Outgoing App Name'])   ? (string)$doc['Outgoing App Name']   : '',
        ];
    }
} catch (Throwable $e) {
    $outgoingRows = [];
}
?>
<?php
// --- Suite filter options (distinct Suite values) ---
$suiteOptions = [];
try {
    $rawSuites = $collection->distinct('Suite');
    foreach ($rawSuites as $s) {
        $suite = trim((string)$s);
        if ($suite !== '') $suiteOptions[$suite] = true;
    }
    $suiteOptions = array_keys($suiteOptions);
    natcasesort($suiteOptions);
    $suiteOptions = array_values($suiteOptions);
} catch (Throwable $e) {
    $suiteOptions = [];
}
?>

<!-- Styles -->
<style>


#applyFilter {
    max-width: 250px;
}
</style>

<!-- Resources -->
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/flow.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>


<!-- HTML -->
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Decommission Analyzer - Dependency Chart</title>
    <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/custom-style.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- DataTables JS (place after jQuery) -->
    <link href="vendor/datatables/jquery.dataTables.min.js" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.js" rel="stylesheet">

    <style>
    #chartDiv,
    #chartdiv {
    width: 100%;
    height: 1000px !important;

}
    #balloon {
        position: absolute;
        top: 359px;
        left: 867px;
        border: 2px solid #ccc;
        background: rgba(255, 255, 255, 0.8);
        padding: 6px;
        font-size: 10px;
        color: #000;
        margin: 40px 0 0 20px;
    }

    /* Smaller, tighter tables */
    .table.table-sm,
    .table-sm th,
    .table-sm td {
        font-size: 12px;
        /* 11–13px range works well */
        line-height: 1.1;
        /* reduce vertical spacing */
        padding: .35rem .5rem;
    }

    /* Optional: wrap long text and allow column width to adjust */
    table.dataTable tbody td {
        white-space: nowrap;
        /* set to normal to wrap; keep nowrap to reduce height */
        text-overflow: ellipsis;
        /* visually indicates truncation */
        overflow: hidden;
        max-width: 320px;
        /* keep huge names under control */
    }

    /* Make header a bit compact too */
    table.dataTable thead th {
        font-size: 12px;
    }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include './pages/sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include './pages/navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <!-- <h1 class="h3 mb-0 text-gray-800">Dependency Chart</h1> -->
                    </div>

                    <!-- Content Row -->



                    <div class="row">
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Dependency Chart for all apps
                                    </h6> <!-- Suite Filter -->
                                    <div class="d-flex align-items-center">
                                        <label for="suiteFilter" class="mr-2 mb-0 text-muted"
                                            style="font-size:0.9rem;">App Suite</label>
                                        <select id="suiteFilter" class="form-control form-control-sm">
                                            <option value="Both" selected>Both</option>
                                            <?php foreach ($suiteOptions as $suite): ?>
                                            <option value="<?= htmlspecialchars($suite, ENT_QUOTES, 'UTF-8') ?>">
                                                <?= htmlspecialchars($suite, ENT_QUOTES, 'UTF-8') ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <label for="appFilter" class="mr-2 mb-0 text-muted"
                                            style="font-size:0.9rem;">Application</label>
                                        <select id="appFilter" class="form-control form-control-sm">
                                            <option value="All" selected>All</option>
                                            <?php foreach ($appOptions as $app): ?>
                                            <option><?= htmlspecialchars($app, ENT_QUOTES, 'UTF-8') ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <!-- Card Body -->
                            <div class="card-body">
                                <div id="incomingChart" style="height:500px;"></div>
<hr>
<div id="outgoingChart" style="height:500px;"></div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <!-- Area Chart -->
                        <div class="col-xl-6 col-lg-6">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Incoming Interfaces
                                    </h6>

                                </div>
                                <!-- Card Body -->

                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-sm table-bordered table-striped" id="incomingTable"
                                            width="100%" cellspacing="0">
                                            <thead>
                                                <tr>
                                                    <th>App ID</th>
                                                    <th>App Name</th>
                                                    <th>Interface Type</th>
                                                    <th>Target App</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if (!empty($incomingRows)): ?>
                                                <?php foreach ($incomingRows as $r): ?>
                                                <tr>
                                                    <td><?= htmlspecialchars($r['id'], ENT_QUOTES, 'UTF-8') ?></td>
                                                    <td><?= htmlspecialchars($r['name'], ENT_QUOTES, 'UTF-8') ?>
                                                    </td>
                                                    <td><?= htmlspecialchars($r['type'], ENT_QUOTES, 'UTF-8') ?>
                                                    </td>
                                                    <td><?= htmlspecialchars($r['targetName'], ENT_QUOTES, 'UTF-8') ?>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                                <?php else: ?>
                                                <tr>
                                                    <td colspan="4" class="text-center text-muted">No incoming
                                                        interfaces found.</td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>


                            </div>
                        </div>
                        <!-- Area Chart -->
                        <div class="col-xl-6 col-lg-6">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Outgoing Interfaces
                                    </h6>

                                </div>
                                <!-- Card Body -->

                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-sm table-bordered table-responsive table-striped"
                                            id="outgoingTable" width="100%" cellspacing="0">
                                            <thead>
                                                <tr>
                                                    <th>App ID</th>
                                                    <th>App Name</th>
                                                    <th>Interface Type</th>
                                                    <th>Target App</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if (!empty($outgoingRows)): ?>
                                                <?php foreach ($outgoingRows as $r): ?>
                                                <tr>
                                                    <td><?= htmlspecialchars($r['id'], ENT_QUOTES, 'UTF-8') ?></td>
                                                    <td><?= htmlspecialchars($r['name'], ENT_QUOTES, 'UTF-8') ?></td>
                                                    <td><?= htmlspecialchars($r['type'], ENT_QUOTES, 'UTF-8') ?></td>
                                                    <td><?= htmlspecialchars($r['targetName'], ENT_QUOTES, 'UTF-8') ?>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                                <?php else: ?>
                                                <tr>
                                                    <td colspan="4" class="text-center text-muted">No outgoing
                                                        interfaces found.</td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                   <script>
am5.ready(function () {

  const datasets = <?= $jsonData ?: '{}' ?>;

  // ---------------------------
  // Utility: create Sankey
  // ---------------------------
  function createSankey(rootId) {
    const root = am5.Root.new(rootId);
    root.setThemes([am5themes_Animated.new(root)]);

    const series = root.container.children.push(
      am5flow.Sankey.new(root, {
        sourceIdField: "from",
        targetIdField: "to",
        valueField: "value",
        paddingRight: 40
      })
    );

    return series;
  }

  const incomingSankey = createSankey("incomingChart");
  const outgoingSankey = createSankey("outgoingChart");

  function updateCharts(appName) {
    if (!datasets[appName]) {
      console.warn("No data for app:", appName);
      incomingSankey.data.setAll([]);
      outgoingSankey.data.setAll([]);
      return;
    }

    incomingSankey.data.setAll(datasets[appName].chart1 || []);
    outgoingSankey.data.setAll(datasets[appName].chart2 || []);
  }

  // ✅ Initial load (first app in dropdown)
  const initialApp = document.getElementById("appFilter").value;
  updateCharts(initialApp);

  // ✅ Change handler
  document.getElementById("appFilter").addEventListener("change", function () {
    updateCharts(this.value);
  });

});
</script>
                                                </body>
                                                </html>
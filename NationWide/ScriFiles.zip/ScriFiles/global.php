<?php
function to01($value): int {
    if (is_numeric($value)) {
        return ((float)$value) > 0 ? 1 : 0;
    }
    $s = strtolower(trim((string)$value));
    if ($s === '' || $s === 'no' || $s === 'not known' || $s === 'na' || $s === 'decommissioned' || $s === '0') {
        return 0;
    }
    return 1;
}

/** Coerce to float safely */
function toFloat($value, $default = 0.0): float {
    if (is_numeric($value)) return (float)$value;
    if (is_string($value)) {
        // Extract numeric parts, e.g. "15%" -> "15"
        $num = preg_replace('/[^0-9.\-]/', '', $value);
        return is_numeric($num) ? (float)$num : (float)$default;
    }
    return (float)$default;
}

/** Safe log base (returns 0 for non-positive inputs) */
function safeLogBase(float $x, float $base): float {
    if ($x <= 0 || $base <= 0 || $base == 1.0) return 0.0;
    return log($x) / log($base); // natural logs
}

/** Safe log10 (returns 0 for non-positive inputs) */
function safeLog10(float $x): float {
    if ($x <= 0) return 0.0;
    return log10($x);
}

function safeNum($value) {
    if ($value === null || $value === "" || !is_numeric($value)) {
		$val = 3;
       switch (strtolower(trim($value)))
	   {
		   case "very low":{$val = 1;break;}
		   case "low":{$val =2;break;}
		   case "medium":{$val = 3;break;}
		   case "high":{$val = 4;break;}
		   case "very high":{$val = 5;break;}
	   }
	   return $val;
    }
    return floatval($value);
}

function safeNumRevenue($value) {
    if ($value === null || $value === "" || !is_numeric($value)) {
		$val = 4;
       switch (strtolower(trim($value)))
	   {
		   case "low":{$val =2;break;}
		   case "medium":{$val = 3;break;}
		   case "high":{$val = 4;break;}
		   case "very high":{$val = 5;break;}
	   }
	   return ($val-1);
    }
    return floatval($value);
}

function documentation($value) {
    if ($value === null || $value === "" || !is_numeric($value)) {
		$val = 3;
       switch (strtolower(trim($value)))
	   {
		   case "no documentation":{$val = 1;break;}
		   case "minimal documentation":{$val =2;break;}
		   case "outdated documentation":{$val = 3;break;}
		   case "well documented":
		   case "well documentated":{$val = 4;break;}
	   }
	   return ($val-1);
    }
    return floatval($value);
}

function pageval($value){
    if ($value === null || $value === "" || !is_numeric($value)) {
		$val = 3;
       switch (strtolower(trim($value)))
	   {
		   case "0 to 5 years":{$val = 1;break;}
		   case "5 to 10 years":{$val =2;break;}
		   case "10-15 years":{$val = 3;break;}
		   case "15-20 years":{$val = 4;break;}
		   case ">20 years":{$val = 5;break;}
	   }
	   // echo $val;
	   return $val;
    }
    return floatval($value);
}

function yes_or_no($value){
    if ($value === null || $value === "" || !is_numeric($value)) {
		$val = 0;
       switch (strtolower(trim($value)))
	   {
		   case "yes":{$val = 1;break;}
		   case "no":{$val =0;break;}
	   }
	   // echo $val;
	   return $val;
    }
    return floatval($value);
}

/** Compute the risk criticality index */
function computeRiskIndex(
    float $apprevenueimpact,
    float $appcriticality,
    int   $appdatagatewayvalue,
    int   $applegalvalue,
    int   $appexternalconnectivityvalue
): float {
    // Your given formula:
    // ((2*LOG(1.1*apprevenueimpact,2)+2*LOG10(1.1*appcriticality)+2*LOG(1+appdatagatewayvalue,2))/10
    //  + (LOG10(1+applegalvalue)/2) + (LOG10(1+appexternalconnectivityvalue)/2))
    $term1 = 2 * safeLogBase(1.1 * $apprevenueimpact, 2);
    $term2 = 2 * safeLog10(1.1 * $appcriticality);
    $term3 = 2 * safeLogBase(1 + $appdatagatewayvalue, 2);
    $term4 = safeLog10(1 + $applegalvalue) / 2;
    $term5 = safeLog10(1 + $appexternalconnectivityvalue) / 2;

    $index = ($term1 + $term2 + $term3) / 10 + $term4 + $term5;

    // Cap at 1.0 as per your requirement
    if ($index > 1) $index = 1.0;

    return $index;
}

require_once 'file_open.php';

$lobs = array_unique(array_column($results, 'line_of_business'));
$dataByLob = array_fill_keys($lobs,[]);

$methods = array_column($results, 'interface_methods');

$methods = array_values(array_filter(array_unique(array_map(function ($m) {
	if (is_array($m)) return ''; // distinct could return arrays if schema varies; drop those
	$s = (string)$m;
	return trim($s);
}, $methods)), function ($m) {
	return $m !== '';
}));

sort($methods, SORT_NATURAL | SORT_FLAG_CASE);
$methods_temp = $methods;
$methods = array();
foreach($methods_temp as $method_name)
{
	if(stripos($method_name,",")!== false)
		$methods = array_merge($methods,explode(",",$method_name));
	else
		$methods[] = $method_name;
}
$methods = array_values(array_filter(array_unique(array_map(function ($m) {
	if (is_array($m)) return ''; // distinct could return arrays if schema varies; drop those
	$s = (string)$m;
	return trim($s);
}, $methods)), function ($m) {
	return $m !== '';
}));
sort($methods, SORT_NATURAL | SORT_FLAG_CASE);

$totalApplications = 0;
$lowPortable = 0;
$mediumPortable = 0;
$highPortable = 0;
$lowRisk = 0;
$mediumRisk = 0;
$highRisk = 0;
$lowFeasible = 0;
$mediumFeasible = 0;
$highFeasible = 0;
$maxMaintainabilityIndex = 0;
$minMaintainabilityIndex = 0;

foreach ($results as $result)
{
	$totalApplications++;
	
	$buisness_name = str_replace("'", "",$result["application_name"]);
	$chart_data[$buisness_name] = array("App" => $buisness_name);
	
	$chart_data[$buisness_name]["application_name"] = $result["application_name"];
	$dataByLob[$result["line_of_business"]][] = array("application_name" => $buisness_name);
	$appid = pageval($result["application_id"] ?? null);
	$chart_data[$buisness_name]["application_id"] = $appid;
	$appagevalue = pageval($result["appagevalue"] ?? null);
	$chart_data[$buisness_name]["appagevalue"] = $appagevalue;
	$apptechnologycomplexity = toFloat($result["apptechnologycomplexity"] ?? 0);
	$chart_data[$buisness_name]["apptechnologycomplexity"] = $apptechnologycomplexity;
	$appcomplexitylevel = toFloat($result["appcomplexitylevel"] ?? 0);
	$chart_data[$buisness_name]["appcomplexitylevel"] = $appcomplexitylevel;
	$processlevelcomplexitylog = toFloat($result["processlevelcomplexitylog"] ?? 0);
	$chart_data[$buisness_name]["processlevelcomplexitylog"] = $processlevelcomplexitylog;
	$apprevenueimpact = safeNumRevenue($result['apprevenueimpact'] ?? null);
	$chart_data[$buisness_name]["apprevenueimpact"] = $apprevenueimpact;
	$appcriticality = safeNum($result['Appcriticality'] ?? null);
	$chart_data[$buisness_name]["appcriticality"] = $appcriticality;
	$appdatagatewayvalue = yes_or_no($result['appdatagatewayvalue'] ?? null);
	$chart_data[$buisness_name]["appdatagatewayvalue"] = $appdatagatewayvalue;
    $appexternalconnectivityvalue = yes_or_no($result['appexternalconnectivityvalue'] ?? null);
	$chart_data[$buisness_name]["appexternalconnectivityvalue"] = $appexternalconnectivityvalue;
	$applegalvalue = yes_or_no($result['applegalvalue'] ?? null);
	$chart_data[$buisness_name]["applegalvalue"] = $applegalvalue;
	$appdocumentationvalue = documentation($result["appdocumentationvalue"]?? null);
	$chart_data[$buisness_name]["appdocumentationvalue"] = $appdocumentationvalue;
	
	$chart_data[$buisness_name]["cyclomaticscore"] = round(((5 * $appagevalue + $apptechnologycomplexity + $appcomplexitylevel)/7),2);
	
	$chart_data[$buisness_name]["maintainabilityindex"] = round(171 - $processlevelcomplexitylog + 50 * (sin(sqrt(2.4* $appdocumentationvalue))),2);
	if($minMaintainabilityIndex == 0 and $maxMaintainabilityIndex == 0)
	{
		$minMaintainabilityIndex = $chart_data[$buisness_name]["maintainabilityindex"];
		$maxMaintainabilityIndex = $chart_data[$buisness_name]["maintainabilityindex"];
	}
	else
	{
		if($minMaintainabilityIndex > $chart_data[$buisness_name]["maintainabilityindex"])
			$minMaintainabilityIndex = $chart_data[$buisness_name]["maintainabilityindex"];
		
		if($maxMaintainabilityIndex < $chart_data[$buisness_name]["maintainabilityindex"])
			$maxMaintainabilityIndex = $chart_data[$buisness_name]["maintainabilityindex"];
	}
	
	// appsizevalue normalized
$appsizevalue = to01($result["appsizevalue"] ?? null);
$chart_data[$buisness_name]["appsizevalue"] = $appsizevalue;

	$chart_data[$buisness_name]["outbounds"] = $result["outbound_interface_count"];
	if(trim($chart_data[$buisness_name]["outbounds"]) == "" or !is_numeric($chart_data[$buisness_name]["outbounds"]))
		$chart_data[$buisness_name]["outbounds"] = 0;
	$chart_data[$buisness_name]["inbounds"] = $result["inbound_interface_count"];
	if(trim($chart_data[$buisness_name]["inbounds"]) == "" or !is_numeric($chart_data[$buisness_name]["inbounds"]))
		$chart_data[$buisness_name]["inbounds"] = 0;
	$chart_data[$buisness_name]["stabilityscore"] = to01($result["appstability"]?? null);
	
// languagecomplexityscore uses normalized numeric values
$chart_data[$buisness_name]["languagecomplexityscore"] =
    ((2 * $apptechnologycomplexity) + (2 * $appcomplexitylevel) + (3 * $appsizevalue)) / 7;

	
	if($chart_data[$buisness_name]["languagecomplexityscore"] >= 0.5)
		$highFeasible++;
	elseif($chart_data[$buisness_name]["languagecomplexityscore"] <= 0.3)
		$lowFeasible++;
	else
		$mediumFeasible++;
	
	$interfaces_count = round((($chart_data[$buisness_name]["inbounds"] + $chart_data[$buisness_name]["outbounds"]) / 1.5),2);
	
	$total1 = 0;
	$bf = isset($result['application_name']) ? trim((string)$result['application_name']) : '(Unknown)';
	if ($bf === '') $bf = '(Unknown)';

	// outbound count; default 0 if missing
	$out = isset($result['outbound_interface_count']) ? (int)$result['outbound_interface_count'] : 0;

	// interface_methods can be a string or an array
	$docMethods = [];
	if (array_key_exists('interface_methods', $result)) {
		if (is_array($result['interface_methods'])) {
			$docMethods = $result['interface_methods'];
		} else {
			if(stripos($result['interface_methods'],",")!== false)
				$docMethods = explode(",",$result['interface_methods']);
			else
				$docMethods = [$result['interface_methods']];
		}
	}

	foreach ($docMethods as $m) {
		if ($m === null) continue;
		$m = trim((string)$m);
		if ($m === '') continue;
		
		$total1 += $out;
	}
	
	$chart_data[$buisness_name]["portabilityindex"] = (2*(1/(2*$chart_data[$buisness_name]["cyclomaticscore"]+2*1/$chart_data[$buisness_name]["maintainabilityindex"]+1/5*(($chart_data[$buisness_name]["appsizevalue"])+0)+(2*$total1)+(3*$chart_data[$buisness_name]["appcriticality"])+0.667*$chart_data[$buisness_name]["stabilityscore"]+4*($interfaces_count)+(2 * $chart_data[$buisness_name]["languagecomplexityscore"]))*10));
	$chart_data[$buisness_name]["portabilityindex"] = round($chart_data[$buisness_name]["portabilityindex"],2);
	if($chart_data[$buisness_name]["portabilityindex"] > 0.8)
		$highPortable++;
	elseif($chart_data[$buisness_name]["portabilityindex"] < 0.4)
		$lowPortable++;
	else
		$mediumPortable++;
	
	$riskcriticalityindex = computeRiskIndex($apprevenueimpact,$appcriticality,$appdatagatewayvalue,$applegalvalue,$appexternalconnectivityvalue);
    $chart_data[$buisness_name]["riskcriticalityindex"] = $riskcriticalityindex;
	$riskcriticalityscore = round($riskcriticalityindex, 2);
    $chart_data[$buisness_name]["riskcriticalityscore"] = $riskcriticalityscore;
	
	if($chart_data[$buisness_name]["riskcriticalityscore"] > 0.8)
		$highRisk++;
	elseif($chart_data[$buisness_name]["riskcriticalityscore"] < 0.4)
		$lowRisk++;
	else
		$mediumRisk++;

}
?>